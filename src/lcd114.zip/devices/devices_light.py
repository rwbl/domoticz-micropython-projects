devices=[
  {
    "n": "TV",
    "i": 185
  },
  {
    "n": "Rob",
    "i": 113
  },
  {
    "n": "MakeLab",
    "i": 118
  },
  {
    "n": "Wohnen Indikator",
    "i": 355
  },
  {
    "n": "MakeLab Power Sonos",
    "i": 403
  }
]