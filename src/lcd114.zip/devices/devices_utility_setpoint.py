devices=[
  {
    "n": "Thermostat MakeLab",
    "i": 32
  }
]