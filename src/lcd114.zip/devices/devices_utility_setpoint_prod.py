devices=[
  {
    "n": "Wohnen-1",
    "i": 338
  },
  {
    "n": "Wohnen-2",
    "i": 339
  },
  {
    "n": "Flur",
    "i": 340
  },
  {
    "n": "Essen",
    "i": 337
  },
  {
    "n": "Bad",
    "i": 341
  },
  {
    "n": "Dusche",
    "i": 342
  },
  {
    "n": "MakeLab",
    "i": 336
  }
]