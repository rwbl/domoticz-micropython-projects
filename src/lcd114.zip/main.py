"""
File: main.py
Date: 20240130
Author: Robert W.B. Linn
Description:
Start a LCD114 demo.
"""

# Comment out for autostart at boot
# import demos.minicontroller
