# minicontroller.py,rwbl,20240129
# Demo script for the for the Waveshare Pico-LCD-1.14 connected to the Raspberry Pi Pico WH.
# https://www.waveshare.com/wiki/Pico-LCD-1.14
# Control the devices Setpoint & Light.
# The device data is PULLED via Domoticz HTTP API GET request and received as JSON object.
# LCD Screen Layout:
# [Menu item 1][Menu item N]
# [Domoticz Device Name]
# [Device Value]
# [Device Value Last Updated] [Network Connection Indicator]
# Joystick: L+R = select control (menu items, input), U+D = In/Decrease value
# Userkey A: select device, B=Set new device value

# NOTES
# Tested with MicroPython v1.22.1 on 2024-01-05; Raspberry Pi Pico W with RP2040
# Network and device configuration in config.py.
# Check out the avialable memory. See log like Free RAM 32736 (defined in ugui.py garbage_collect).
# IMPORTANT: Thonny Stop/Restart backend (CTRL+F2) prior running the script (F5).
# This might be done twice in case MemoryError: memory allocation failed, allocating NNNN bytes.

# DEPENDENCIES
# micropython-micro-gui library.

# TODO: HTTP get request use async and as tasks.

# Released under the GNU GENERAL PUBLIC LICENSE v3.0. See LICENSE.
# Copyright (c) 2024 Robert W.B. Linn

_VERSION = 'v20240129'
_CAPTION = 'Domoticz Mini Controller'
print(f'{_CAPTION} {_VERSION}')

# Imports
# Hardware setup must be imported before other modules because of RAM use.
import hardware_setup as hw

# Create SSD instance. Must be done first because of RAM use.
from gui.core.ugui import Screen, ssd, display

from gui.widgets import Menu, Label, Button, LED, Adjuster

# CWriter with font(s) - be careful high memory usage
from gui.core.writer import CWriter
import gui.fonts.font10 as fonts       # small
import gui.fonts.freesans20 as fontn   # normal
import gui.fonts.arial35 as fontb      # big

from gui.core.colors import *

import uasyncio as asyncio
import time
import json

# Userkey widget for the LCD-1.14 Keys A & B
from demos.userkey import UserKey

# Import the Domoticz devices as a list with JSON object
# Example: devices=[{"n": "Thermostat MakeLab","i": 32}, ...]
# Setpoint devices = thermostats
# import devices.devices_utility_setpoint as thermostats
import devices.devices_utility_setpoint_prod as thermostats
# Light/Switch
import devices.devices_light as lights

# Network
from web.server import Server

# Configuration with secrets
import config

# Debug flag to log detailed info
_DEBUG = True

# Domoticz
# URL API call with placeholder for param (the command) & command arguments
_URL_BASE = "http://"+config.DOMOTICZ_IP+"/json.htm?type=command&"

# Domoticz API request get device status
_URL_GET_DEVICES = _URL_BASE + 'param=getdevices&rid={IDX}'

# Delay ms to give time for the screen to build
_SCREEN_BUILD_DELAY = 250

# Adjuster value = DO NOT CHANGE
_ADJUSTER_VALUE = 0.5

# Define the groups with the devices.
# Groups contain a menu item at top row of the screen.
# Properties:
# text - text displayed on the menu item
# id - unique id. must start with 0 and increase by 1
# devices - list of devices (with keys n (=name) and i (=domoticz index) to be controlled
# step: value change step for in- or decrease
# valueattribute - Domoticz attribvute used to show or change
# valuemin, valuemax - Min / max value to be set
# setcmd - Domoticz HTTP API call param,idx & device specific setting to change the value
# The devices are imported from the devices folder with list named devices.
# It is also possible to define direct in this script:
# The id is used to select the device from this groups list.
groups = [
    # Thermostats
    {'text':'Thermos',
     'id':0,
     'devices':thermostats.devices,
     'step':1,
     'valueattribute':'SetPoint', 'valuemin':5, 'valuemax':21,
     'setcmd':'param=setsetpoint&idx={IDX}&setpoint={VALUE}'},
    # Lights controlled by setting the level
    {'text':'Lights',
     'id':1,
     'devices':lights.devices,
     'step':10,
     'valueattribute':'LevelInt', 'valuemin':0, 'valuemax':100,
     'setcmd':'param=switchlight&idx={IDX}&switchcmd=Set%20Level&level={VALUE}'}
        # param=switchlight&idx=99&switchcmd=<On|Off|Toggle|Stop>
]

# KeyA & B unique IDs. Must be negative.
KEYA_ID = -1
KEYB_ID = -2

def LogDebug(s):
    if _DEBUG:
        print(f'[DEBUG] {s}')

# Base screen for the demo
class DemoScreen(Screen):

    def __init__(self):

        def menu_callback(button, n):
            """Handle menu item button press"""
            LogDebug('menu_callback: button={button}, n={n}')
            button_callback(button, n)

        def button_callback(button, arg):
            """Handle pressing a button or userkey."""
            # Get the id from the arg - must be unique
            id = arg
            LogDebug('button_callback: button={button}, arg={arg}')

            # Select the button/key according id
            # Devices - select new group
            if id >= 0:
                # Get the group from the id
                self._group = groups[id]
                print(f"Selected group={self._group['text']}")
                # Get the devices list for the selected group
                self._devices = self._group['devices']
                # print(f'{self._devices}, {type(self._devices)}')
                # Check if there are devices
                if len(self._devices) > 0:
                    # Set the step value to value in/decrease
                    self._adj_step = self._group['step']
                    # Init the device & adjuster value
                    self._device_value = 0
                    self._adj_value_prev = _ADJUSTER_VALUE
                    self.adjvalue.value(_ADJUSTER_VALUE)
                    # Select the first device
                    self._device_selected_index = 0
                    self._device_selected = self._devices[self._device_selected_index]
                    # Update the device label from the devices json list key n
                    self.lbldevice.value(self._device_selected['n'])
                    # Get the device value from the domoticz & update the label value
                    self.get_device_value()

            # USERKEY A - Loop over the devices for the selected group
            if id == KEYA_ID:
                # Check first if there are devices
                if self._devices == None:
                    return
                self._device_selected_index = self._device_selected_index + 1
                # Set first index if end of list reached
                if self._device_selected_index > len(self._devices) - 1:
                    self._device_selected_index = 0
                
                self._device_selected = self._devices[self._device_selected_index]
                LogDebug('button_callback: KEYA device_selected={self._device_selected_index}')
                self.lbldevice.value(self._device_selected['n'])
                self.get_device_value()

            # USERKEY B - Set new value for the device by submitting get request to domoticz
            if id == KEYB_ID:
                LogDebug('button_callback: KEYB set_device_value={self._device_selected}')
                self.set_device_value()
        # Init
        super().__init__()
        
        # Selected group
        self._group = None
        # List of devices set by the group button selection
        self._devices = None
        # Hold the device index selected from the devices list
        self._device_selected_index = -1
        # Selected device properties
        self._device_selected = None
        # Devices value
        self._device_value = 0
        self._adj_value_prev = 0
        self._adj_step = 0
        # Network state
        self._connected = False
        
        # Label properties for the caption at top row & value
        labelcaptionproperties = {
            'bdcolor' : False,
            'fgcolor' : GREEN,
            'bgcolor' : BLACK,
            'justify' : Label.CENTRE
        }
        labelvalueproperties = {
            'bdcolor' : BLUE,          #RED
            'fgcolor' : BLACK,         #WHITE
            'bgcolor' : WHITE,         #DARKGREEN
            'justify' : Label.CENTRE
        }

        # Create the writers with small, normal & big font
        # The font width is used for initial text ssizes
        wris = CWriter(ssd, fonts, GREEN, WHITE, verbose=False)
        self._wris_charwidth = wris.font.get_ch("A")[2]
        wrin = CWriter(ssd, fontn, GREEN, WHITE, verbose=False)
        self._wrin_charwidth = wrin.font.get_ch("A")[2]
        wrib = CWriter(ssd, fontb, GREEN, WHITE, verbose=False)
        self._wrib_charwidth = wrib.font.get_ch("A")[2]
        LogDebug(f'writers: charwidth s={self._wris_charwidth},n={self._wrin_charwidth}, b={self._wrib_charwidth}')

        # Top level menu - uses groups settings as defined previous
        mnu = (
                (groups[0]['text'], menu_callback, (groups[0]['id'],)),
                (groups[1]['text'], menu_callback, (groups[1]['id'],)),
        )
        self.menu = Menu(wris, bgcolor=BLUE, textcolor=WHITE, args = mnu)

        # Label Device name below the top level menu
        row = wris.height * 2
        col = 2
        self.lbldevice = Label(wrin, row, col, 'Domoticz Device Name', bdcolor=False, fgcolor=WHITE)

        # Label Value middle of the screen
        row = int(ssd.height / 2)
        col = 10 # int(ssd.width / 2) - int(wrib.height / 2)
        # Max len data big font is NNNN.NNNN
        self.lblvalue = Label(wrib, row, col, ssd.width - 20, **labelvalueproperties)
        self.adjvalue = Adjuster(wrib, row, col,
                                 fgcolor=BLUE,
                                 value=_ADJUSTER_VALUE,
                                 callback=self.adjvalue_callback)

        # Label Last update at bottom left
        row = ssd.height - wris.height - 4
        # row = row + wrin.height + 4
        col = 10
        self.lbllastupdate = Label(wris, row, col, 'YYYY-MM-DD hh:mm:ss', fgcolor=WHITE)

        # LED Network indicator top right for connection state: RED=offline, GREEN=Connected
        ledindicator_height = 14
        row = ssd.height - ledindicator_height - 4
        col = ssd.width - (self._wrin_charwidth * 2)
        self.lednwindicator = LED(wrin, row, col, height=ledindicator_height, color=RED, fgcolor=RED)

        # Define the two user keys A & B which are white pushbuttons at the right side of the display
        # Keys A & B must arg index -1,-2.
        keya = UserKey(hw.keya, callback=button_callback, args=(KEYA_ID,))
        keyb = UserKey(hw.keyb, callback=button_callback, args=(KEYB_ID,))
        
        LogDebug('demoscreen: OK')

    def after_open(self):
        """Framebuffer methods run after_open"""
        display.usegrey(False)

        # Show the network indicator - RED if not connected
        self.lednwindicator.value(True)
        
        # Start the task to connect to the network
        self.reg_task(self.connect_network())
        LogDebug('after_open: OK')

    def adjvalue_callback(self, adj):
        """Set the new value depending new adjuster value set by the up/down buttons"""

        # Get the new value rounded 1 digit
        self._adj_value_new = round(adj.value(),1)
        
        # Factor 0,1,-1 used to set the new value
        n = 0
        if self._adj_value_new < self._adj_value_prev: n = -1
        if self._adj_value_new > self._adj_value_prev: n = 1
        LogDebug(f'adj_value new={self._adj_value_new},prev={self._adj_value_prev},factor={n}')
        self._adj_value_prev = self._adj_value_new
        
        # New device value calculated using factor * step
        self._device_value = self._device_value + (n * self._adj_step)
        self._device_value = round(self._device_value, 1)
        
        # Check if the new value is in group range valuemin/max
        if self._group is not None:
            if self._device_value > self._group['valuemax']:
                self._device_value = self._group['valuemax']
            if self._device_value < self._group['valuemin']:
                self._device_value = self._group['valuemin']
        
        # Update the lavel
        self.lblvalue.value(f"{self._device_value:.1f}")

    async def connect_network(self):
        """Connect to the network using the secrets defined in config.py"""
        
        # Let the screen get ready first
        await asyncio.sleep_ms(_SCREEN_BUILD_DELAY)

        # Network connect
        LogDebug('network: connecting...')
        # Create network object
        self.network = Server(config.WIFI_SSID, config.WIFI_PASSWORD, DEBUG=False)
        # Connect to the network and get the server object
        self.server = self.network.connect2()
        
        # Set the flag connected and show green LED indicator
        self._connected = True
        self.lednwindicator.color(color=GREEN)
        LogDebug('network: OK')

    def get_device_value(self):
        """Get device value. Watch the case for the attribute names."""
        if not self._connected:
            print(f'[ERROR] Not connected to the network.')
            return

        # Set the url api request
        url = _URL_GET_DEVICES.replace('{IDX}', str(self._device_selected['i']))

        # Send Domoticz API call as get request
        LogDebug(f'get_device_value: Send GET request url={url}')
        
        try:
            status, response = self.network.send_get_request(url)
            # print(f'Response GET request: status={status}, response={response}')

            # Check the property result (which is an array) & get the first array entry
            if not (response.get('result') is None):
                result = response['result']
                data = result[0]
                # print the response to analyse the device attributes
                LogDebug(f'Response GET request: status={status}, data={data}')

                # Get the device attributes using the right case for the keys
                lastupdate = data['LastUpdate']
                data = data[self._group['valueattribute']]
                self._device_value = float(data)
                LogDebug(f'get_device_value: value={self._device_value}')
                # Update the labels
                self.lbllastupdate.value('{:s}'.format(lastupdate))
                self.lblvalue.value(f"{self._device_value:.1f}")
                
            else:
                self.lbllastupdate.value('{}'.format('ERROR: No device data.'))
                print(f'[ERROR get_device] Response GET request: No device data.')
        except:
            self.lbllastupdate.value('{}'.format('ERROR: HTTP request failed.'))
            print(f'[ERROR get_device] HTTP request failed.')
            raise Exception('[ERROR get_device] HTTP request failed.')

    def set_device_value(self):
        """Set a new device value by sending HTTP API request to Domoticz."""
        if not self._connected:
            print(f'[ERROR] Not connected to the network.')
            return
        if self._device_selected is None:
            print(f'[ERROR] No device selected.')
            return
            
        # Set the url api request
        idx = str(self._device_selected['i'])
        cmd = self._group['setcmd']
        value = self.lblvalue.value().strip()
        url = _URL_BASE + cmd
        url = url.replace('{IDX}', idx)
        url = url.replace('{VALUE}', value)
        # Send Domoticz API call as get request
        LogDebug(f'set_device_value: Send GET request url={url}')            
        try:
            status, response = self.network.send_get_request(url)
            LogDebug(f'set_device_value: Response GET request status={status}, response={response}')
            # Check the property status {"status" : "OK" or "ERR", "title" : "command"}
            if status == 1:
                self.lbllastupdate.value('{:s}'.format(response['title'] + ':' + response['status']))
            else:
                self.lbllastupdate.value('{:s}'.format('ERROR: Command failed'))
                print(f'[ERROR get_device] Response GET request: Command failed.')
        except:
            self.lbllastupdate.value('{:s}'.format('ERROR: HTTP request failed.'))
            print(f'[ERROR get_device] HTTP request failed.')
            # raise Exception('[ERROR get_device] HTTP request failed.')
def demo():
    """Demo running on lcd display with dimensions 240x135"""
    if ssd.width < 240 or ssd.height < 135:
        print("This demo requires a display of 240x135 pixels.")
    else:
        # A class is passed here, not an instance.
        Screen.change(DemoScreen)

# Start the demo
demo()
