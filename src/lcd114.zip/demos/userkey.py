# userkey.py,rwbl,20240125
# Handle the userkey A, B for the LCD 1.14 display.
# Class is derived from the Pushbutton widget.
# Define the userkey in hardware_setup.py:
# keya = Pin(15, Pin.IN, Pin.PULL_UP)
# keyb = Pin(17, Pin.IN, Pin.PULL_UP)
# Usage:
# import hardware_setup as hw
# from demos.userkey import UserKey
# keya = UserKey(hw.keya, callback=my_callback, args=('keya',))
# def my_callback(button, arg):
#   print('Button pressed', arg)

import uasyncio as asyncio
import utime as time
from gui.primitives import Delay_ms

dolittle = lambda *_ : None

class UserKey:
    debounce_ms = 50
    def __init__(self,
                 pin, suppress=False, sense=None,
                 callback=dolittle, args=[]):
        self.pin = pin # Initialise for input
        self.sense = pin.value() if sense is None else sense  # Convert from electrical to logical value
        self.state = self.rawstate()  # Initial state
        self.callback = callback
        self.callback_args = args
        self._run = asyncio.create_task(self._go())  # Thread runs forever
        # print(f'UserKey Init {pin}')

    # Current non-debounced logical button state: True == pressed
    def rawstate(self):
        return bool(self.pin.value() ^ self.sense)

    # Current debounced state of button (True == pressed)
    def __call__(self):
        return self.state

    def _check(self, state):
        if state == self.state:
            return
        # State has changed: act on it now.
        self.state = state
        if state:  # Button pressed: launch pressed func
            # print(f'UserKey _check {state}')
            self.callback(self, *self.callback_args) # CB takes self as 1st arg.

    async def _go(self):
        while True:
            self._check(self.rawstate())
            # Ignore state changes until switch has settled. Also avoid hogging CPU.
            # See https://github.com/peterhinch/micropython-async/issues/69
            await asyncio.sleep_ms(UserKey.debounce_ms)

    def deinit(self):
        self._run.cancel()
