# dom_simple.py Minimal micro-gui demo for Domoticz.
# rwbl,20240112
#
# micropython-micro-gui:
# Released under the MIT License (MIT). See LICENSE.
# Copyright (c) 2021 Peter Hinch
# Based upon https://github.com/peterhinch/micropython-micro-gui

# Hardware_setup must be imported before other modules because of RAM use.

# Create a display instance
import hardware_setup as hw
from gui.core.ugui import Screen, Window, ssd, display

from gui.widgets import Label, Button, CloseButton
from gui.core.writer import CWriter

# Font for CWriter
import gui.fonts.arial10 as arial10
import gui.fonts.freesans20 as freesans20

from gui.core.colors import *

import uasyncio as asyncio
import time
import json

# Network
from web.server import Server
# Configuration with secrets
import config

# Network connect
# Create network object
network = Server(config.WIFI_SSID, config.WIFI_PASSWORD, DEBUG=True)
# Connect to the network and get the server object
server = network.connect()
# URL API call
URL_REQUEST = "http://"+config.DOMOTICZ_IP+"/json.htm?type=command&param=getdevices&rid={IDX}"
# Set the idx of the domoticz device type ligh/switch, subtype switch on/off
IDX_DEVICE = 2

# Set the url api request
url = URL_REQUEST.replace('{IDX}', str(IDX_DEVICE))
print(url)

# Get weather device temperature & humidity
async def get_weather(lbldevice, lbltimestamp, lbltemperature, lblhumidity):
    while True:
        # Send Domoticz API call as get request
        print(f'Send GET request: url={url}')
        status, response = network.send_get_request(url)

        # Print the Domoticz API call response
        # print(f'Response GET request: status={status}, message={response}')
        result = response['result']
        data = result[0]
        print(f'Response GET request: status={status}, data={data}')

        d = data['Name']
        ts = data['LastUpdate']
        t = data['Temp']
        h = data['Humidity']
        
        lbldevice.value('{}'.format(d))
        lbltemperature.value('T={:02.1f}'.format(t))
        # lbltemperature.value('T={:02f}'.format(t))
        lblhumidity.value('H={:02.0f}'.format(h))
        lbltimestamp.value('TS:{}'.format(ts))
        
        # Sleep 10 seconds
        await asyncio.sleep(10 * 6)

# Base screen
# Hint label: writer, row, col, text, invert=False, fgcolor=None, bgcolor=BLACK, bdcolor=False, justify=0
class BaseScreen(Screen):

    def __init__(self):

        def my_callback(button, arg):
            print('Button pressed', arg)

        super().__init__()
        
        # Label properties
        labelproperties = {
            'bdcolor' : False,
            'fgcolor' : WHITE,
            'bgcolor' : DARKGREEN,
            'justify' : Label.LEFT}
        
        # verbose default indicates if fast rendering is enabled

        # Create the writers
        wris = CWriter(ssd, arial10, GREEN, WHITE)
        wrim = CWriter(ssd, freesans20, GREEN, WHITE)
        
        col = 2
        row = 2
        # Demo of relative positioning.
        # Vertical gap between widgets
        gap = 20

        Label(wrim, row, col, 'Domoticz Simple Demo', bdcolor=False, fgcolor=GREEN)

        row = row + gap * 2
        lbldevice = Label(wrim, row, 2, 'Domoticz Device Name', bdcolor=False, fgcolor=WHITE)

        row = lbldevice.mrow + gap
        lbltemperature = Label(wrim, row, 2, 'no data', **labelproperties)

        row = lbltemperature.mrow + gap
        lblhumidity = Label(wrim, row, 2, 'no data', **labelproperties)

        lbltimestamp = Label(wris, 300, 2, 'TS: YYYY-MM-DD hh:mm:ss', fgcolor=GREEN)

        self.reg_task(get_weather(lbldevice, lbltimestamp, lbltemperature, lblhumidity))
        
        CloseButton(wris)

    def after_open(self):
        display.usegrey(False)
        # Coordinates are x, y as per framebuf
        # circle method is in Display class only
        #display.circle(70, 70, 30, RED)
        # These methods exist in framebuf, so also in SSD and Display
        #ssd.hline(0, 127, 128, BLUE)
        #ssd.vline(127, 0, 128, BLUE)
        # x,y,w,c
        ssd.hline(0, 28, 480, GREEN)

def test():
    print('Domoticz Simple Demo: button presses print to REPL.')

    # A class is passed here, not an instance.
    Screen.change(BaseScreen) 

test()
