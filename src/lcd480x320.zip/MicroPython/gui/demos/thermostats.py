# thermostats.py,rwbl,20240114
# Domoticz example for a device type Temp+Humidity+Baro.
# Requires the micropython-micro-gui.
# Network and device configuration in config.py.
# Check out the avialable memory. See log like Free RAM 34416 (defined in ugui.py garbage_collect).
# IMPORTANT: Thonny Stop/Restart backend (CTRL+F2) prior running the script (F5).

# Hardware setup must be imported before other modules because of RAM use.
import hardware_setup as hw

from gui.core.ugui import Screen, ssd, display

from gui.widgets import Grid, Label, Button
from gui.core.writer import CWriter

# Fonts for CWriter - be carefull as taken up memory
import gui.fonts.font10 as fonts     # small
import gui.fonts.freesans20 as fontd # default

from gui.core.colors import *

import uasyncio as asyncio
import time
import json

# Network
from web.server import Server
# Configuration with secrets
import config

VERSION = '20240114'
CAPTION = 'Domoticz Demo Thermostats'
print(f'{CAPTION} {VERSION}')

# Network connect
# Create network object
network = Server(config.WIFI_SSID, config.WIFI_PASSWORD, DEBUG=False)
# Connect to the network and get the server object
server = network.connect2()

# Domoticz
# URL API call to get all device attributes
URL_REQUEST = "http://"+config.DOMOTICZ_IP+"/json.htm?type=command&param=getdevices&rid={IDX}"

# Domoticz device refresh interval (seconds)
REFRESH_INTERVAL = 120

# Get the device attributes using the right case for the keys
# Example thermostat: Name, SetPoint
def get_device(idx,name,value):
    
    # Set the url api request        
    url = URL_REQUEST.replace('{IDX}', str(idx))
    print(f'Send GET request: url={url}, name={name}, value={value}')
    try:
        status, response = network.send_get_request(url)
        if not (response.get('result') is None):
            result = response['result']
            data = result[0]
            name = data[name]
            value = data[value]
            print(f'[get_device] {name},{value}')
            return name, value
        else:
            print(f'[ERROR get_device] Response GET request: No device data.')
    except:
        print(f'[ERROR get_device] HTTP request failed.')
        raise Exception('[ERROR get_device] HTTP request failed.')

# Update the grid with thermostat & temperature data
# Grid has 4 cols: Name (0), Setpoint (1), Temperature (2), Deviation (3)
# Grid has 8 rows: row 0 is title.
# The col name is set from the setpoint device name
# Thermostat attributes idx=338, Name, SetPoint
# Temperature idx=361, Temp
# Set value in a cell row, col: self.grid[0,0]='Thermostat'
# Uses asyncio.sleep between get requests to allow these to complete
# sp=setpoint, pv=actual temp
async def update_grid(grid):
    colname = 0
    colsp = 1
    colpv = 2
    coldev = 3

    # List of devices displayed in the grid
    # Key id can be used to do device specific
    devices = [
        {'id':1,'row':1, 'colname':0, 'colsp':1, 'colpv':2, 'idxsp':338, 'idxpv':361}, #w1
        {'id':2,'row':2, 'colname':0, 'colsp':1, 'colpv':2, 'idxsp':339, 'idxpv':362}, #w2
        {'id':3,'row':3, 'colname':0, 'colsp':1, 'colpv':2, 'idxsp':337, 'idxpv':363}, #e
        {'id':4,'row':4, 'colname':0, 'colsp':1, 'colpv':2, 'idxsp':340, 'idxpv':366}, #f
        {'id':5,'row':5, 'colname':0, 'colsp':1, 'colpv':2, 'idxsp':341, 'idxpv':365}, #b
        {'id':6,'row':6, 'colname':0, 'colsp':1, 'colpv':2, 'idxsp':342, 'idxpv':364}, #d
        {'id':7,'row':7, 'colname':0, 'colsp':1, 'colpv':2, 'idxsp':336, 'idxpv':360}, #m
    ]
    
    while True:
        # Loop over the devices
        for device in devices:
            # Device Setpoint
            name, valuesp = get_device(device['idxsp'],'Name','SetPoint')
            grid[device['row'], device['colname']] = name
            grid[device['row'], device['colsp']] = str(valuesp)
            await asyncio.sleep(0.01)

            # Device Temp
            name, valuepv = get_device(device['idxpv'],'Name','Temp')
            grid[device['row'], device['colpv']] = str(valuepv)
            await asyncio.sleep(0.01)
            
            # Temp deviation
            valuedev = float(valuepv) - float(valuesp)
            # Indiviual control of cell appearance deviation
            d = {}  
            if valuedev < 0:
                d["fgcolor"] = RED
            d["text"] = str(round(valuedev,1))
            grid[device['row'], coldev] = d
            await asyncio.sleep(0.01)

        # Sleep NN seconds
        await asyncio.sleep(REFRESH_INTERVAL)

# Base screen
# Hint label: writer, row, col, text, invert=False, fgcolor=None, bgcolor=BLACK, bdcolor=False, justify=0
class BaseScreen(Screen):

    def __init__(self):

        # Init
        super().__init__()
        
        # Label properties
        labelcaptionproperties = {
            'bdcolor' : False,
            'fgcolor' : GREEN,
            'bgcolor' : BLACK,
            'justify' : Label.CENTRE
        }
        labelvalueproperties = {
            'bdcolor' : RED,
            'fgcolor' : WHITE,
            'bgcolor' : DARKGREEN,
            'justify' : Label.CENTRE
        }

        # Create the writers with small and default fonts
        wris = CWriter(ssd, fonts, GREEN, WHITE)
        wrid = CWriter(ssd, fontd, GREEN, WHITE)
        
        col = 2
        row = 2
        # Vertical gap between widgets
        gap = 30

        # Caption
        Label(wrid, row, col, CAPTION, bdcolor=False, fgcolor=GREEN)

        # Screen dimension = 480x320; Grid = 4 cols, 8 rows
        # Initial pos & size
        cols = 4
        rows = 8
        col = 5
        row = row + gap * 2
        colwidth = int(460 / cols)

        
        #self.ncells = cols * (rows - 1)
        #self.last_cell = cols * rows
        #self.lbl = Label(wrid, row, col, text = (colwidth + 4) * cols, justify=Label.CENTRE)
        #row = self.lbl.mrow

        self.grid = Grid(wrid, row, col, colwidth, rows, cols, justify=Label.CENTRE, bdcolor=WHITE)

        # Set headers value in a cell row 0, col 0-3
        self.grid[0,0]='Thermostat'
        self.grid[0,1]='Setpoint'
        self.grid[0,2]='Temperature'
        self.grid[0,3]='Deviation'

        # Register the task to update the grid in regular intervals
        self.reg_task(update_grid(self.grid))
        
        # Screen must at least one active widget - using a dummy button at bottom left of the sceen.
        btn = Button(wris,300,10,height=10, width=10,fgcolor=WHITE,bdcolor=BLACK,bgcolor=BLACK,text=VERSION)
        # CloseButton(wrid)

    def after_open(self):
        """framebuffer methods run after_open"""
        display.usegrey(False)
        # horz line x,y,w,c below the caption
        ssd.hline(0, 28, 480, GREEN)

def test():
    # A class is passed here, not an instance.
    Screen.change(BaseScreen) 

test()
