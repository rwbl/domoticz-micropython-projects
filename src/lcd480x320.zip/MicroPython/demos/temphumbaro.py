# temphumbaro.py,rwbl,20240119
# Demo script for the for the Waveshare Pico-ResTouch-LCD-3.5 connected to the Raspberry Pi Pico WH.
# Domoticz device type Temp+Humidity+Baro data displayed in label widgets.
# The device data is PULLED via Domoticz HTTP API GET request and received as JSON object.

# NOTES
# Tested with MicroPython v1.22.1 on 2024-01-05; Raspberry Pi Pico W with RP2040
# Network and device configuration in config.py.
# Check out the avialable memory. See log like Free RAM 32736 (defined in ugui.py garbage_collect).
# IMPORTANT: Thonny Stop/Restart backend (CTRL+F2) prior running the script (F5).
# This might be done twice in case MemoryError: memory allocation failed, allocating NNNN bytes.

# DEPENDENCIES
# micropython-micro-gui library.

# TODO: HTTP get request use async and as tasks.

# Released under the GNU GENERAL PUBLIC LICENSE v3.0. See LICENSE.
# Copyright (c) 2024 Robert W.B. Linn

# Imports
# Hardware setup must be imported before other modules because of RAM use.
import hardware_setup as hw

# Create SSD instance. Must be done first because of RAM use.
from gui.core.ugui import Screen, ssd, display

from gui.widgets import Label, Button

# CWriter with font(s) - be careful high memory usage
from gui.core.writer import CWriter
import gui.fonts.font10 as fonts     # small
import gui.fonts.freesans20 as fontd # default

from gui.core.colors import *

import uasyncio as asyncio
import time
import json

# Network
from web.server import Server
# Configuration with secrets
import config

VERSION = 'v20240119'
CAPTION = 'Domoticz Demo Temp+Hum+Baro Device'
print(f'{CAPTION} {VERSION}')

# Domoticz
# URL API call to get all device attributes
URL_REQUEST = "http://"+config.DOMOTICZ_IP+"/json.htm?type=command&param=getdevices&rid={IDX}"

# Set the idx of the domoticz device type Temp+Humidity+Baro
# IDX_DEVICE = 2 # Test system
IDX_DEVICE = 115 # Production

# Set the url api request
url = URL_REQUEST.replace('{IDX}', str(IDX_DEVICE))
# print(url)

# Domoticz device refresh interval (seconds)
REFRESH_INTERVAL = 60

# Delay ms to give time for the screen to build
_SCREEN_BUILD_DELAY = 250

# Get device temp+hum+baro. Watch the case for the attribute names.
async def get_device(lbldevice, lbllastupdate, lbltemperature, lblhumidity, lblbarometer):
    
    await asyncio.sleep_ms(_SCREEN_BUILD_DELAY)

    # Network connect
    print('network: connecting...')
    # Create network object
    network = Server(config.WIFI_SSID, config.WIFI_PASSWORD, DEBUG=False)
    # Connect to the network and get the server object
    server = network.connect2()
    print('network: OK')

    while True:
        # Send Domoticz API call as get request
        # print(f'Send GET request: url={url}')
        try:
            status, response = network.send_get_request(url)
            # print(f'Response GET request: status={status}, response={response}')

            # Check the property result
            if not (response.get('result') is None):
                result = response['result']
                data = result[0]
                # print the response to analyse the device attributes
                # print(f'Response GET request: status={status}, data={data}')

                # Get the device attributes using the right case for the keys
                name = data['Name']
                lastupdate = data['LastUpdate']
                temp = data['Temp']
                hum = data['Humidity']
                baro = data['Barometer']

                # Update the labels
                lbldevice.value('{} ({})'.format(data['Name'], data['idx']))
                lbllastupdate.value('{:s}'.format(lastupdate))
                lbltemperature.value('{:02.1f} C'.format(temp))
                lblhumidity.value('{:02.0f} %RH'.format(hum))
                lblbarometer.value('{:04.0f} hPa'.format(baro))
            else:
                lbldevice.value('{}'.format('ERROR: No device data.'))
                print(f'[ERROR get_device] Response GET request: No device data.')
        except:
            lbldevice.value('{}'.format('ERROR: HTTP request failed.'))
            lbllastupdate.value('{}'.format('Check Domoticz server.'))
            print(f'[ERROR get_device] HTTP request failed.')
            raise Exception('[ERROR get_device] HTTP request failed.')
        # Sleep NN seconds
        await asyncio.sleep(REFRESH_INTERVAL)

# Base screen for the demo
class DemoScreen(Screen):

    def __init__(self):

        # Init
        super().__init__()
        print('super init: OK')
        
        # Label properties
        labelcaptionproperties = {
            'bdcolor' : False,
            'fgcolor' : GREEN,
            'bgcolor' : BLACK,
            'justify' : Label.CENTRE
        }
        labelvalueproperties = {
            'bdcolor' : RED,
            'fgcolor' : WHITE,
            'bgcolor' : DARKGREEN,
            'justify' : Label.CENTRE
        }

        # Device temp+hum+baro attributes with defaults
        attributes = [
            {'id':1,'row':100, 'col':50, 'caption':'Temperature', 'value':'000.00 C'},
            {'id':2,'row':100, 'col':190, 'caption':'Humidity', 'value':'000 %RH'},
            {'id':3,'row':100, 'col':310, 'caption':'Barometer', 'value':'0000 hPa'}
        ]

        # Create the writers with small and default fonts
        wris = CWriter(ssd, fonts, GREEN, WHITE, verbose=False)
        wrid = CWriter(ssd, fontd, GREEN, WHITE, verbose=False)
        print('writers: OK')

        # Vertical gap between widgets
        gap = 30
        
        # Initial position for screen col & row
        col = 2
        row = 2

        # Caption
        self.lblcaption = Label(wrid, row, col, CAPTION, bdcolor=False, fgcolor=GREEN)

        # Device name
        row = row + gap
        lbldevice = Label(wrid, row, col, 'Domoticz Device Name (Idx=Idx)     ', bdcolor=False, fgcolor=WHITE)

        # Last update
        row = row + gap
        lbllastupdate = Label(wris, row, col, 'YYYY-MM-DD hh:mm:ss', fgcolor=GREEN)

        # Device attributes temp+humidity+baro
        for attribute in attributes:
            if attribute['id'] == 1:
                lbltemperaturecaption = Label(wrid, attribute['row'], attribute['col'], attribute['caption'], **labelcaptionproperties)
                lbltemperature = Label(wrid, attribute['row']+gap, attribute['col'], attribute['value'], **labelvalueproperties)
            if attribute['id'] == 2:
                lblhumiditycaption = Label(wrid, attribute['row'], attribute['col'], attribute['caption'], **labelcaptionproperties)
                lblhumidity = Label(wrid, attribute['row']+gap, attribute['col'], attribute['value'], **labelvalueproperties)
            if attribute['id'] == 3:
                lblbarometercaption = Label(wrid, attribute['row'], attribute['col'], attribute['caption'], **labelcaptionproperties)
                lblbarometer = Label(wrid, attribute['row']+gap, attribute['col'], attribute['value'], **labelvalueproperties)

        print('demoscreen: OK')

        # Screen must at least one active widget - using a dummy button at bottom left of the sceen.
        Button(wris, ssd.height - 20, 10, height=10, width=10, fgcolor=WHITE, bdcolor=BLACK, bgcolor=BLACK, text=VERSION)

        # Register the task to get & update the labels with Domoticz data
        self.reg_task(asyncio.create_task(get_device(lbldevice, lbllastupdate, lbltemperature, lblhumidity, lblbarometer)))
        print('reg_task: OK')

    def after_open(self):
        """Framebuffer methods run after_open"""
        print('after_open: start')
        display.usegrey(False)
        # horz line x,y,w,c below the caption
        ssd.hline(0, self.lblcaption.height, ssd.width, GREEN)
        
        print('after_open: OK')

def demo():
    """Demo running on lcd display with dimensions 480x320"""
    if ssd.width < 480 or ssd.height < 320:
        print("This demo requires a display of 480x320 pixels.")
    else:
        # A class is passed here, not an instance.
        Screen.change(DemoScreen)

demo()
