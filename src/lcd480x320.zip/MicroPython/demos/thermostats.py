# thermostats.py,rwbl,20240119
# Demo script for the for the Waveshare Pico-ResTouch-LCD-3.5 connected to the Raspberry Pi Pico WH.
# Domoticz example for a grid with up-to 7 room thermostat setpoint (sp) & temperature (pv).
# The grid has the dimensions 8 rows x 4 columns name,setpoint,temperature,deviation (=pv-sp, text color red if < 0).
# Row 1 (index 0) is used to display the column headers. Rows 2-8 (0-7) for the thermostats.
# Each row contains a thermostat + temperature - max 7 thermostat devices.
# The device data is PULLED via Domoticz HTTP API GET requests.
# Per thermostat there are 2 HTTP requests for the setpoint & temperature device.
# The themostat data is defined in a list.

# NOTES
# Tested with MicroPython v1.22.1 on 2024-01-05; Raspberry Pi Pico W with RP2040

# First run slow grid built.
# Network and device configuration in config.py.
# Check out the avialable memory. See log like Free RAM 24752 - 24784 (defined in ugui.py garbage_collect).
# IMPORTANT:
# Thonny Stop/Restart backend (CTRL+F2) prior running the script (F5).
# This might be done twice in case MemoryError: memory allocation failed, allocating NNNN bytes.

# DEPENDENCIES
# micropython-micro-gui library.

# TODO: HTTP get requests use async and as tasks.
# TODO: Faster first time grid build.

# Released under the GNU GENERAL PUBLIC LICENSE v3.0. See LICENSE.
# Copyright (c) 2024 Robert W.B. Linn

# Imports
# Hardware setup must be imported before other modules because of RAM use.
import hardware_setup as hw

from gui.core.ugui import Screen, ssd, display

from gui.widgets import Grid, Label, Button
from gui.core.writer import CWriter

# CWriter with font(s) - be careful high memory usage
import gui.fonts.font10 as fonts     # small
import gui.fonts.freesans20 as fontd # default

from gui.core.colors import *

import uasyncio as asyncio
import time
import json
import gc

# Network
from web.server import Server
# Configuration with secrets
import config

VERSION = '20240119'
CAPTION = 'Domoticz Demo Thermostats'
print(f'{CAPTION} {VERSION}')

# Network
# Create network object
network = Server(config.WIFI_SSID, config.WIFI_PASSWORD, DEBUG=False)
# Connect to the network and get the server object.
# Do not listen to incoming requests because HTTP GET requests are used.
server = network.connect2()

# Domoticz
# HTTP GET request to get for a single device all attributes.
URL_REQUEST = "http://" + config.DOMOTICZ_IP + "/json.htm?type=command&param=getdevices&rid={IDX}"

# Grid refresh interval (seconds).
REFRESH_INTERVAL = 120

# Delay (s) after each Domoticz HTTP request.
# Determined via trial-and-error.
REQUEST_DELAY = 0.5

# List of devices (max 7) displayed in the grid.
# idxsp = Domoticz idx of the setpoint device.
# idxpv = Domoticz idx of the thermostat device.
devices = [
    # row 0: title for the 4 columns (BaseScreen init)
    {'row':1, 'idxsp':338, 'idxpv':361}, #w1
    {'row':2, 'idxsp':339, 'idxpv':362}, #w2
    {'row':3, 'idxsp':337, 'idxpv':363}, #e
    {'row':4, 'idxsp':340, 'idxpv':366}, #f
    {'row':5, 'idxsp':341, 'idxpv':365}, #b
    {'row':6, 'idxsp':342, 'idxpv':364}, #d
    {'row':7, 'idxsp':336, 'idxpv':360}, #m
]

# Get the domoticz system server time via HTTP API GET request.
# Update the label.
def get_servertime(lbl):
    status, servertime = network.get_server_time(config.DOMOTICZ_IP)
    if status == 1:
        lbl.value('{:s}'.format(servertime))

# Get the device attributes using the right case for the attribute keys.
# Example thermostat: Name, SetPoint.
# Returns
# device name and value for the given attribute key names.
# In case of an error return name="ERROR", value=0
def get_device(idx,namekey,valuekey):
    # Set the url api request        
    url = URL_REQUEST.replace('{IDX}', str(idx))
    # print(f'Send GET request: url={url}, name={name}, value={value}')
    try:
        status, response = network.send_get_request(url)
        if not (response.get('result') is None):
            result = response['result']
            data = result[0]
            name = data[namekey]
            value = data[valuekey]
            print(f'[get_device] {namekey}={name},{valuekey}={value}')
            return name, value
        else:
            print(f'[ERROR get_device] Response GET request: No device data.')
            return "ERROR", 0
    except:
        print(f'[ERROR get_device] HTTP request failed.')
        return "ERROR", 0
        # raise Exception('[ERROR get_device] HTTP request failed.')

# Update the grid with thermostat & temperature data
# Grid has 4 cols: Name (0), Setpoint (1), Temperature (2), Deviation (3)
# Grid has 8 rows: row 0 is title.
# The col name is set from the setpoint device name
# Thermostat attributes idx=338, Name, SetPoint
# Temperature idx=361, Temp
# Set value in a cell row, col: self.grid[0,0]='Thermostat'
# Uses asyncio.sleep between get requests to allow these to complete
# sp=setpoint, pv=actual temp
async def update_grid(grid,lbllastupdate):
    # Define the column indices.
    colname = 0
    colsp = 1
    colpv = 2
    coldev = 3

    # Infinite loop updating the grid in regular intervals.
    while True:
        # Loop over the devices
        for device in devices:
            # Get the device row
            row = device['row']
            
            # Device Setpoint - also sets the thermostat name
            name, valuesp = get_device(device['idxsp'],'Name','SetPoint')
            d = {}  
            d["justify"] = Label.LEFT
            d["text"] = name
            grid[row, colname] = d
            grid[row, colsp] = str(valuesp)
            await asyncio.sleep(REQUEST_DELAY)

            # Device Temp - name is not used as set by the setpoint device
            name, valuepv = get_device(device['idxpv'],'Name','Temp')
            grid[row, colpv] = str(valuepv)
            await asyncio.sleep(REQUEST_DELAY)
            
            # Temp deviation
            valuedev = float(valuepv) - float(valuesp)
            # Indiviual control of cell appearance deviation
            d = {}  
            if valuedev < 0:
                d["fgcolor"] = RED
            d["text"] = str(round(valuedev,1))
            grid[row, coldev] = d

            # Update the servertime used as last update
            get_servertime(lbllastupdate)
            await asyncio.sleep(REQUEST_DELAY)

        # Sleep NN seconds
        gc.collect()
        await asyncio.sleep(REFRESH_INTERVAL)

# Base screen
class BaseScreen(Screen):

    def __init__(self):

        # Init
        super().__init__()
    
        # Create the writers with small and default fonts
        wris = CWriter(ssd, fonts, GREEN, WHITE)
        wrid = CWriter(ssd, fontd, GREEN, WHITE)
        
        # Vertical gap between widgets
        gap = 30

        
        # Initial position for screen col & row
        col = 2
        row = 2

        # Caption
        self.lblcaption = Label(wrid, row, col, CAPTION, bdcolor=False, fgcolor=GREEN)

        # Screen dimension = 480x320; Grid = 4 cols, 8 rows
        # Initial pos & size
        cols = 4
        rows = 8
        col = 5
        row = row + gap * 2
        colwidth = int(460 / cols)

        
        #self.ncells = cols * (rows - 1)
        #self.last_cell = cols * rows
        #self.lbl = Label(wrid, row, col, text = (colwidth + 4) * cols, justify=Label.CENTRE)
        #row = self.lbl.mrow

        self.grid = Grid(wrid, row, col, colwidth, rows, cols, justify=Label.CENTRE, bdcolor=WHITE)

        # Set column titles in a cell row 0, col 0-3
        self.grid[0,0]='Thermostat'
        self.grid[0,1]='Setpoint'
        self.grid[0,2]='Temperature'
        self.grid[0,3]='Deviation'

        # Last update - uses Domoticz servertime
        row = 300
        col = 10
        self.lbllastupdate = Label(wris, 300, 10, 'YYYY-MM-DD hh:mm:ss', fgcolor=GREEN)

        # Screen must at least one active widget - using a dummy button at bottom left of the sceen.
        row = 300
        col = 480 - (len(VERSION) * 12)
        Button(wris, ssd.height - 20, col, height=10, width=10, fgcolor=WHITE, bdcolor=BLACK, bgcolor=BLACK, text=VERSION)
        # CloseButton(wrid)

    def after_open(self):
        """Framebuffer methods run after_open"""
        display.usegrey(False)
        # horz line x,y,w,c below the caption
        ssd.hline(0, self.lblcaption.height, ssd.width, GREEN)
        # Register the task to update the grid in regular intervals
        print('Register update task')
        self.reg_task(update_grid(self.grid, self.lbllastupdate))

def demo():
    # A class is passed here, not an instance.
    Screen.change(BaseScreen) 

demo()
