# mywidgets.py,rwbl,20240122
# Custom widgets as an extension to ugui providing the following classes:
# MyTile: label (caption) + label (text) embedded in a rectangle.
# MyTileBox: label (caption) + textbox (content up-to 3 lines) embedded in a rectangle.
# MyLabelledCircle: circle + label caption + separator (hline) + label value

# NOTES
# DEVELOPMENT AT EXPERMENTAL STAGE.
# Tested with MicroPython v1.22.1 on 2024-01-05; Raspberry Pi Pico W with RP2040
# Network and device configuration in config.py.
# Check out the avialable memory. See log like Free RAM 32736 (defined in ugui.py garbage_collect).
# IMPORTANT: Thonny Stop/Restart backend (CTRL+F2) prior running the script (F5).
# This might be done twice in case MemoryError: memory allocation failed, allocating NNNN bytes.

# DEPENDENCIES
# micropython-micro-gui library.

# TODO: Tile & TileBox caption invert over caption len and not string len only.
# TODO: TileBox property set different writers caption & content.
# TODO: TileBox warning row + width <= ssd.height. Need to fix in ugui because width is used for the height.

# Released under the GNU GENERAL PUBLIC LICENSE v3.0. See LICENSE.
# Copyright (c) 2024 Robert W.B. Linn

# Imports
from gui.core.ugui import Widget, display, ssd
from gui.widgets import Label, Button, Textbox
from gui.core.colors import *
import uasyncio as asyncio

dolittle = lambda *_ : None

#
# MyTile
#

class MyTile(Widget):
    """Tile displaying label caption + label text."""
    def __init__(self, writer,
                 row, col, width=100, height=50,
                 fillcolor=None,
                 fgcolor=None, bgcolor=None, bdcolor=RED,
                 callback=dolittle, args=[],
                 value=False, active=True,
                 caption="caption",
                 captionfgcolor=None,
                 captioninvert=False,
                 text="text",
                 textfgcolor=None,):
        
        super().__init__(writer, row, col, width, height, fgcolor,
                         bgcolor, bdcolor, value, active)
        super()._set_callbacks(callback, args)

        # Properties
        self.row = row
        self.col = col
        self.width = width
        self.height = height
        self.bdcolor = bdcolor
        self.fillcolor = fillcolor
        self.caption = caption
        self.text = text
        self.captionfgcolor=captionfgcolor
        self.captioninvert=captioninvert

        # Label Caption
        row = self.row
        col = self.col
        strlen = self.width
        self.lblcaption = Label(writer, row, col, strlen, justify=Label.CENTRE, fgcolor=captionfgcolor)
        
        # Label Text
        row = row + int(writer.height) + 6
        strlen = self.width - int(self.writer.height / 2)
        self.lbltext = Label(writer, row, col, strlen, fgcolor=textfgcolor)

    def show(self):
        """Show the widget."""
        if super().show():
            
            # Display the hline below the caption
            x1 = self.col
            y1 = self.row + int(self.writer.height) + 2
            x2 = x1 + self.width
            y2 = y1
            display.line(x1, y1, x2, y2, WHITE)

            # Update the text of the caption and text
            self.lblcaption.value(text=self.caption, fgcolor=self.captionfgcolor, invert=self.captioninvert)
            self.lbltext.value(self.text)

    def newcaption(self, text=None):
        """Set the new caption"""
        if text is not None:
            self.lblcaption.value(text)
            return text

    def newtext(self, text=None):
        """Set the new text"""
        if text is not None:
            self.lbltext.value(text)
            return text

#
# MyTileBox
#

class MyTileBox(Widget):
    """TileBox displaying a rectangle with caption and up-to 3 lines.

    Example change caption & text tilebox
    mytilebox.newcaption("New Caption")
    text = mytilebox.newtext(["New Line1","New Line2"])
    print(text)
    """
    def __init__(self, writer,
                 row, col, width=100, height=100,
                 fillcolor=None,
                 fgcolor=None, bgcolor=None, bdcolor=WHITE,
                 callback=dolittle, args=[],
                 value=False, active=True,
                 caption="caption",
                 captionfgcolor=None,
                 captioninvert=False,
                 text=["Line 1", "Line 2", "Line 3"],
                 textfgcolor=None):
        
        super().__init__(writer, row, col, width, height, fgcolor,
                         bgcolor, bdcolor, value, active)
        super()._set_callbacks(callback, args)

        self.writer = writer
        _, _, self.char_width = self.writer.font.get_ch("A")
        self.row = row
        self.col = col
        self.height = height
        self.width = width
        self.fillcolor = fillcolor
        self.caption = caption
        self.text = text
        self.captionfgcolor = captionfgcolor
        self.captioninvert = captioninvert

        # Caption starting at top left row, col
        row = self.row
        col = self.col
        strlen = self.width # - int(self.writer.height / 2)
        self.lblcaption = Label(writer, row, col, strlen, justify=Label.CENTRE, fgcolor=captionfgcolor)
        
        # TextBox with up-to 3 lines
        row = row + int(writer.height) + 6
        nlines = 3
        pargs = (row, col, self.width - 4, nlines) 
        tbargs = {'fgcolor': textfgcolor,'bdcolor':False,'bgcolor':self.bgcolor,}
        # tbargs = {'fgcolor' : YELLOW,'bdcolor' : RED,'bgcolor' : BLACK,}
        self.textbox = Textbox(writer, *pargs, clip=False, **tbargs)

    def show(self):
        """Show the widget."""
        if super().show():
            # Display the hline below the caption
            x1 = self.col
            y1 = self.row + int(self.writer.height) + 2
            x2 = x1 + self.width
            y2 = y1
            display.line(x1, y1, x2, y2, WHITE)

            # Update the values of the caption and textbox
            # wristrlen = len(self.caption) * self.char_width
            self.lblcaption.value(text=self.caption,fgcolor=self.captionfgcolor, invert=self.captioninvert)
            self.textbox.clear()
            for line in self.text:
                self.textbox.append(str(line), ntrim=None)

    def newcaption(self, text=None):
        """Set the new caption.
            mtb.newcaption("New Caption")
        """
        if text is not None:
            self.lblcaption.value(text)
            return text

    def newtext(self, text=None):
        """Set the new text.
        text = mtb.newtext(["New Line1","New Line2"])
        """
        self.textbox.clear()
        if text is not None:
            for line in text:
                self.textbox.append(str(line), ntrim=None)
                # await asyncio.sleep(1)
            return text

#
# MyCircleLabel
#

class MyLabelledCircle(Widget):
    """Circle with label caption + separator hline + label value.

    row,col are the top left positions of the rect containing the circle at center position.
    Example: LabelledCircle
    col = int(ssd.width / 2)
    row = 100
    self.lc_solar = MyLabelledCircle(wri,
                                     row, col, height=90,
                                     circlebdcolor=RED, circlebgcolor=BLUE,
                                     caption="Solar", captionbgcolor=BLUE,
                                     value="2.3", valuebgcolor=BLUE,
                                     sep=True, sepcolor=WHITE,
                                     unit="KWH", unitwriter=wris, unitbgcolor=BLUE)
                                        
    Examples setting labelledcircle attributes
    labelledcircle.newcaption("Sol1")
    labelledcircle.newvalue(-0.11)
    labelledcircle.newunit("kwh")
    """
    def __init__(self,
                 writer,
                 row, col,
                 *, height=90,
                 fgcolor=None, bgcolor=None, bdcolor=False, color=BLACK,
                 # Use the attributes below
                 circlebdcolor=WHITE,
                 circlebgcolor=BLACK,
                 caption="caption",
                 captionfgcolor=None,
                 captionbgcolor=False,
                 captioninvert=False,
                 value="value",
                 valuefgcolor=None,
                 valuebgcolor=False,
                 valueinvert=False,
                 unit=None,
                 unitfgcolor=None,
                 unitbgcolor=False,
                 unitinvert=False,
                 unitwriter=None,
                 sep=True,
                 sepcolor=WHITE):
        super().__init__(writer, row, col, height, height, fgcolor, bgcolor, bdcolor, False)

        # Circle
        self._row = row
        self._col = col
        self.height = height
        self.width = height
        self.radius = int(self.height / 2)
        # Circle center position
        self.x = int(col + self.radius)
        self.y = int(row + self.radius)
        self.writer = writer
        self.circlebdcolor = circlebdcolor
        self.circlebgcolor = circlebgcolor
        # Connection points
        self.top = {"x":self.x, "y":self.y - self.radius}
        self.left = {"x":self.x - self.radius, "y":self.y}
        self.bottom = {"x":self.x, "y":self.y + self.radius}
        self.right = {"x":self.x + self.radius, "y":self.y}
        # Labels
        self.caption = caption
        self.captionfgcolor=captionfgcolor
        self.captionbgcolor=captionbgcolor
        self.captioninvert=captioninvert
        self.value = str(value)
        self.valuefgcolor=valuefgcolor
        self.valuebgcolor=valuebgcolor
        self.valueinvert=valueinvert
        self.unit = unit
        self.unitfgcolor=unitfgcolor
        self.unitbgcolor=unitbgcolor
        self.unitinvert=unitinvert
        self.unitwriter=unitwriter
        if self.unitwriter == None:
            self.unitwriter = writer
        # Separator hline
        self.sep=sep
        self.sepcolor=sepcolor

        # Create the labels
        # The labels are centre justified with an initial width
        # calculated from the circle radius and writer height.
        # The text of a label in set in function show.

        # Caption
        row = self.y - int(writer.height)
        strlen = (self.radius * 2) - int(writer.height)
        col = self.x - int(strlen / 2)
        self.lblcaption = Label(writer, row, col, strlen, justify=Label.CENTRE)
        
        # Value
        row = self.y + 2
        strlen = (self.radius * 2) - int(writer.height)
        col = self.x - int(strlen / 2)
        self.lblvalue = Label(writer, row, col, strlen, justify=Label.CENTRE)
        
        # Unit
        # If the unit has the same writer as the value then use same col
        if unit is not None:
            row = self.y + self.lblvalue.height + 2
            strlen = (self.radius * 2) - int(self.unitwriter.height * 2) - 4
            col = self.x - int(strlen / 2)
            self.lblunit = Label(self.unitwriter, row, col, strlen, justify=Label.CENTRE)

        # self.draw = True

    def show(self):
        """Show the widget"""
        if super().show():
            # Draw the circle
            display.fillcircle(int(self.x), int(self.y), int(self.radius), self.circlebgcolor)
            display.circle(int(self.x), int(self.y), int(self.radius), self.circlebdcolor)
            
            # Draw the separator
            if self.sep:
                x = self.x - self.radius
                y = self.y
                l = int(self.radius * 2)
                display.hline(x,y,l,color=self.sepcolor)

            # Set the value of the 3 labels caption,value,unit.
            # The attributes must be set.
            self.lblcaption.value(text=self.caption,
                                  fgcolor=self.captionfgcolor,
                                  bgcolor=self.captionbgcolor,
                                  invert=self.captioninvert)
            
            self.lblvalue.value(text=self.value,
                                fgcolor=self.valuefgcolor,
                                bgcolor=self.valuebgcolor,
                                invert=self.valueinvert)
            
            if self.unit is not None:
                self.lblunit.value(text=self.unit,
                                   fgcolor=self.unitfgcolor,
                                   bgcolor=self.unitbgcolor,
                                   invert=self.unitinvert)
            
    def color(self, color):
        """Set the widget color"""
        self._color = color
        self.draw = True

    #@property
    #def valuefgcolor(self):
    #    return self.valuefgcolor

    def newcaption(self, caption=None):
        """Set the new caption with attributes"""
        if caption is not None:
            self.lblcaption.value(
                text=str(caption),
                fgcolor=self.captionfgcolor,
                bgcolor=self.captionbgcolor,
                invert=self.captioninvert)
            return caption

    def newcaptioncolor(self, fgcolor, bgcolor=False):
        """Set the new caption color.

        After function use await asyncio.sleep_ms(_SCREEN_BUILD_DELAY).
        """
        self.captionfgcolor = fgcolor
        self.captionbgcolor = bgcolor
        self.draw = True

    def newvalue(self, value=None, fgcolor=None, bgcolor=None, invert=None):
        """Set the new value with attributes"""
        if value is not None:
            if fgcolor is None:
                fgcolor = self.valuefgcolor
            if fgcolor is None:
                fgcolor = self.valuebgcolor
            if invert is None:
                invert = self.valueinvert
            self.lblvalue.value(
                text=str(value),
                fgcolor=fgcolor,
                bgcolor=bgcolor,
                invert=invert)
            return value

    def newvaluecolor(self, fgcolor, bgcolor=False):
        """Set the new value color.

        After function use await asyncio.sleep_ms(_SCREEN_BUILD_DELAY).
        """
        if self.value is not None:
            self.valuefgcolor = fgcolor
            self.valuebgcolor = bgcolor
            self.draw = True

    def newunit(self, unit=None):
        """Set the new unit with attributes.
        The unit must have been created prior using newunit.
        """
        if unit is not None:
            if self.lblunit is not None:
                self.lblunit.value(
                    text=str(unit),
                    fgcolor=self.unitfgcolor,
                    bgcolor=self.unitbgcolor,
                    invert=self.unitinvert)
            return unit

    def newunitcolor(self, fgcolor, bgcolor=False):
        """Set the new unit color.

        After function use await asyncio.sleep_ms(_SCREEN_BUILD_DELAY).
        """
        if self.unit is not None:
            self.unitfgcolor = fgcolor
            self.unitbgcolor = bgcolor
            self.draw = True

"""
NOT USED
Example of creating a widget LabelledCircle from dict.
labelledcircles = [
    {"id":1, "row":50, "col": 50, "height":90, "circlebdcolor":RED, "circlebgcolor":BLUE,
     "caption":"Solar", "captionbgcolor":BLUE, "value":0, "valuebgcolor":BLUE, "unit":"kWh", "unitwriter":wris, "unitbgcolor":BLUE,
     "sep":True, "sepcolor":WHITE}
]
self.mylc = create_labelled_circle(labelledcircles[0])

def create_labelled_circle(lc):
    # Create a labelled circle from dict. Mandatory keys are writer, row, col.
    _wri = lc["writer"] if "writer" in lc else None
    _row = lc["row"] if "row" in lc else 0
    _col = lc["col"] if "col" in lc else 0
    _caption = lc["caption"] if "caption" in lc else ""
    _value = lc["value"] if "value" in lc else ""
    _unit = lc["unit"] if "unit" in lc else None
    _unitwriter = lc["unitwriter"] if "unitwriter" in lc else None
    _sep = lc["sep"] if "sep" in lc else True
                
    return MyLabelledCircle(_wri, _row, _col, caption=_caption, value=_value, unit=_unit, unitwriter=_unitwriter, sep=_sep)
"""
