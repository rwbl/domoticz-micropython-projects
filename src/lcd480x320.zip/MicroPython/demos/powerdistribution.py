# powerdistribution.py,rwbl,20240122
# Demo script for the Waveshare Pico-ResTouch-LCD-3.5 connected to the Raspberry Pi Pico WH.
# Domoticz power distribution displayed in connected MyLabelledCircle custom widgets.
# The data is received as JSON object from the Domoticz server via Domoticz HTTP POST request from automation script dzVents.
# Domoticz PUSHES the data to the Pico W server.

# NOTES
# Tested with MicroPython v1.22.1 on 2024-01-05; Raspberry Pi Pico W with RP2040
# Network and device configuration in config.py.
# Check out the avialable memory. See log like Free RAM 32736 (defined in ugui.py garbage_collect).
# IMPORTANT: Thonny Stop/Restart backend (CTRL+F2) prior running the script (F5).
# This might be done twice in case MemoryError: memory allocation failed, allocating NNNN bytes.

# DEPENDENCIES
# micropython-micro-gui library.

# Released under the GNU GENERAL PUBLIC LICENSE v3.0. See LICENSE.
# Copyright (c) 2024 Robert W.B. Linn

# Imports
# Initialise hardware and framebuf before importing modules.
import hardware_setup

# Create SSD instance. Must be done first because of RAM use.
from gui.core.ugui import Screen, ssd, display

from gui.widgets import Label, Button

# CWriter with font(s) - be careful high memory usage
from gui.core.writer import CWriter
import gui.fonts.arial10 as arial10
import gui.fonts.courier20 as courier20

from gui.core.colors import *

# Custom Widgets
from demos.mywidgets import (MyLabelledCircle)

import uasyncio as asyncio
import gc
import time
import json

# Network
from web.server import Server
# Configuration with secrets
import config

VERSION = 'v20240122'
CAPTION = 'Domoticz Demo Energy Distribution using Custom Widgets MyLabelledCircle'
print(f'{CAPTION} {VERSION}')

# Delay ms to give time for the screen to build
_SCREEN_BUILD_DELAY = 250

async def request_handler(lblcaption, solar, grid, home, battery):
    """Handle request enabling to change the tiles caption,text"""
    
    await asyncio.sleep_ms(_SCREEN_BUILD_DELAY)

    # Examples setting labelledcircle attributes
    #solar.newcaption("S1")
    #solar.newunit("kwh")
    #solar.newvalue(2.3)

    #grid.newcaptioncolor(WHITE, False)
    #await asyncio.sleep_ms(_SCREEN_BUILD_DELAY)
    #grid.newvalue(-0.11, fgcolor=RED)
    #print(grid.valuefgcolor)

    # Network connect
    print('network: connecting...')
    # Create network object
    network = Server(config.WIFI_SSID, config.WIFI_PASSWORD, DEBUG=True)
    # Connect to the network and get the server object
    server = network.connect()
    print('network: OK')

    while True:
        try:
            # Get client connection and the request data
            cl, request = network.get_client_connection(server)
           
            # Parse the post data. In case of error, the status is 0.
            data, status = network.parse_post_request(request)
            print(data, status)

            # Create the HTTP response JSON object
            response = {}

            # Set the response KEY_TITLE
            # Can be used assign the postdata, but is rather large for this solution
            response[config.KEY_TITLE] = "powerdistribution"

            # If status is 1, then the post response is properly parsed, lets change the led state.
            if status == 1:

                lblcaption.value(f'{data['caption']} {data['lastupdate']}')

                solar.newvalue(data['solar'],data['solarfgcolor'])
                await asyncio.sleep_ms(_SCREEN_BUILD_DELAY)
                grid.newvalue(data['grid'],data['gridfgcolor'])
                await asyncio.sleep_ms(_SCREEN_BUILD_DELAY)
                battery.newvalue(data['battery'],data['batteryfgcolor'])
                await asyncio.sleep_ms(_SCREEN_BUILD_DELAY)
                home.newvalue(data['home'],data['homefgcolor'])
                await asyncio.sleep_ms(_SCREEN_BUILD_DELAY)

                # Response OK
                response[config.KEY_STATE] = config.STATE_OK
                response[config.KEY_MESSAGE] = status
            else:
                # Error with unknown command
                response[config.KEY_STATE] = config.STATE_ERR
                response[config.KEY_MESSAGE] = config.MESSAGE_CMD_UNKNOWN
            
            # Send response to the client and close the connection
            network.send_response(cl, response, False)
            
        except OSError as e:
            network.ledstatus.off()
            cl.close()
            print('[ERROR] Network Connection closed')

class DemoScreen(Screen):

    def __init__(self):

        # self.lca = MyLabelledCircle(wri, row, col, height=90, caption="A", value="1234", sep=True, sepcolor=RED)

        # Define the labelledcircles containing power distribution data

        super().__init__()
        
        # Define the writers - be careful as high mem take-up
        self.wri = CWriter(ssd, courier20, GREEN, BLACK, verbose=False)
        self.wris = CWriter(ssd, arial10, GREEN, BLACK, verbose=False)

        # Create the caption - will be updated by handle_request
        col = 10
        row = 10
        self.lblcaption = Label(self.wri, row, col, "Power Distribution HH:MM:SS")

        # Create the LabelledCircles
        self.circleheight = 90
        self.unitkwh = "kWh"
        
        # Solar
        row = self.lblcaption.row + int(self.wri.height) + 10
        col = int(ssd.width / 2) - int(self.circleheight / 2)
        self.lc_solar = self.create_labelled_circle(row, col, "Solar", YELLOW)
        # Grid
        row = self.lc_solar.bottom["y"]
        col = int(self.circleheight / 2)
        self.lc_grid = self.create_labelled_circle(row, col, "Grid", CYAN)
        # Home
        row = self.lc_solar.bottom["y"]
        col = int(ssd.width) - int(self.circleheight) - int(self.circleheight / 2)
        self.lc_home = self.create_labelled_circle(row, col, "Home", WHITE)
        # Battery
        row = self.lc_grid.bottom["y"]
        col = self.lc_solar.bottom["x"] - int(self.circleheight / 2)
        self.lc_battery = self.create_labelled_circle(row, col, "Bat", MAGENTA)

        # Screen must at least one active widget - using a dummy button at bottom left of the sceen.
        Button(self.wris, ssd.height - 20, 10, height=10, width=10, fgcolor=WHITE, bdcolor=BLACK, bgcolor=BLACK, text=VERSION)

    def after_open(self):
        """Framebuffer methods run after_open
        Called after a screen has been displayed
        """
        display.usegrey(False)

        # Connect solar with home
        x = self.lc_solar.right["x"]
        y = self.lc_solar.right["y"]
        l = abs(self.lc_solar.right["x"] - self.lc_home.top["x"])
        display.hline(x,y,l,color=WHITE)
        x = self.lc_home.top["x"]
        y = self.lc_solar.right["y"]
        l = abs(self.lc_solar.right["y"] - self.lc_home.top["y"])
        display.vline(x,y,l,color=WHITE)

        # Connect grid with solar
        x = self.lc_grid.top["x"]
        y = self.lc_solar.left["y"]
        l = abs(self.lc_grid.top["x"] - self.lc_solar.left["x"])
        display.hline(x,y,l,color=CYAN)
        x = self.lc_grid.top["x"]
        y = self.lc_solar.left["y"]
        l = abs(self.lc_solar.left["y"] - self.lc_grid.top["y"])
        display.vline(x,y,l,color=CYAN)

        # Connect solar with battery
        x = self.lc_solar.bottom["x"]
        y = self.lc_solar.bottom["y"]
        l = abs(self.lc_solar.bottom["y"] - self.lc_battery.top["y"])
        display.vline(x,y,l,color=RED)

        # Connect grid with home
        x = self.lc_grid.right["x"]
        y = self.lc_grid.right["y"]
        l = abs(self.lc_grid.right["x"] - self.lc_home.left["x"])
        display.hline(x,y,l,color=BLUE)

        # Register the task to get the device attributes in regular intervals
        self.reg_task(asyncio.create_task(
            request_handler(self.lblcaption,
                            self.lc_solar,
                            self.lc_grid,
                            self.lc_home,
                            self.lc_battery)))
        print('reg_task: OK')

        print('after_open: OK')

    def create_labelled_circle(self, row, col, caption, color):
        """Create a labelled circle for energy distribution item"""
        txtcolor = WHITE
        return MyLabelledCircle(
            self.wri,
            row, col, height=self.circleheight,
            circlebdcolor=color, # circlebgcolor=YELLOW,
            caption=caption, captionfgcolor=txtcolor,
            value=0, valuefgcolor=txtcolor,
            sep=True, sepcolor=color,
            unit=self.unitkwh, unitwriter=self.wris, unitfgcolor=txtcolor)

def demo():
    """Demo running on lcd display with dimensions 480x320"""
    if ssd.width < 480 or ssd.height < 320:
        print("This demo requires a display of 480x320 pixels.")
    else:
        # A class is passed here, not an instance.
        Screen.change(DemoScreen)

# Run the demo
demo()

