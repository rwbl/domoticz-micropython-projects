# lcdledcontrol.py,rwbl,20240119
# Demo script for the for the Waveshare Pico-ResTouch-LCD-3.5 connected to the Raspberry Pi Pico WH.
# Domoticz to set (PUSH) the state of 3 leds via HTTP POST request from the Domoticz server to the Pico W running as server.
# The state of a Domoticz device type Light/Switch, Switch, Push On Button triggers an automation dzVents script.
# The dzVents script creates the JSON object (Lua table) and submits the JSON object as postdata via openurl to the Pico W server.
# The POST request from Domoticz contains a JSON object, like to set the state of LED with id 3, which is LED C with RED color.
# {'id': 3, 'lastupdate': 'LED=3 @ 10:15:43', 'state': 1}

# NOTES
# Tested with MicroPython v1.22.1 on 2024-01-05; Raspberry Pi Pico W with RP2040
# Network and device configuration in config.py.
# Check out the avialable memory. See log like Free RAM 32736 (defined in ugui.py garbage_collect).
# IMPORTANT: Thonny Stop/Restart backend (CTRL+F2) prior running the script (F5).
# This might be done twice in case MemoryError: memory allocation failed, allocating NNNN bytes.

# DEPENDENCIES
# micropython-micro-gui library.

# TODO: HTTP get request use async and as tasks.
# TODO: Simplify setting LED state using lists.

# Released under the GNU GENERAL PUBLIC LICENSE v3.0. See LICENSE.
# Copyright (c) 2024 Robert W.B. Linn

# Imports
# Hardware setup must be imported before other modules because of RAM use.
import hardware_setup as hw

from gui.core.ugui import Screen, ssd, display

from gui.widgets import Label, LED, Button
from gui.core.writer import CWriter

# CWriter with font(s) - be careful high memory usage
import gui.fonts.font10 as fonts     # small
import gui.fonts.freesans20 as fontd # default

from gui.core.colors import *

import uasyncio as asyncio
import time
import json

# Network
from web.server import Server
# Configuration with secrets
import config

VERSION = 'v20240119'
CAPTION = 'Domoticz Demo LCD LED Control'
print(f'{CAPTION} {VERSION}')

# Delay ms to give time for the screen to build
_SCREEN_BUILD_DELAY = 250

# Wait for client connection to set the LED states
async def request_handler(lbllastupdate, led_a,led_b,led_c):
    
    # Give some time for the screen to build
    await asyncio.sleep_ms(_SCREEN_BUILD_DELAY)

    # Network connect
    print('network: connecting...')
    # Create network object
    network = Server(config.WIFI_SSID, config.WIFI_PASSWORD, DEBUG=True)
    # Connect to the network and get the server object
    server = network.connect()
    print('network: OK')

    while True:
        try:
            # Get client connection and the request data
            cl, request = network.get_client_connection(server)
           
            # Parse the post data. In case of error, the status is 0.
            data, status = network.parse_post_request(request)
            
            # Create the HTTP response JSON object
            response = {}
            # Assign the postdata to the response KEY_TITLE
            response[config.KEY_TITLE] = data

            # If status is 1, then the post response is properly parsed, lets change the led state.
            if status == 1:
                lastupdate = data["lastupdate"]

                lbllastupdate.value('{:s}'.format(lastupdate))

                # Get the JSON key led {"led":1-3}
                id = data["id"]
                # Get the JSON key state {"state":0 or 1}
                state = data["state"]
                # state = True if newstate == 1 else False
                # print(id,newstate,state)
                
                # Set the led state
                led_a.value(False)
                led_b.value(False)
                led_c.value(False)
                await asyncio.sleep_ms(100)

                # Select & set the led
                if id == 1:
                    led_a.value(state)
                if id == 2:
                    led_b.value(state)
                if id == 3:
                    led_c.value(state)

                # Give some time for the screen to rebuild
                await asyncio.sleep_ms(_SCREEN_BUILD_DELAY)

                # Response is OK
                response[config.KEY_STATE] = config.STATE_OK
                response[config.KEY_MESSAGE] = state
            else:
                # Error with unknown command
                response[config.KEY_STATE] = config.STATE_ERR
                response[config.KEY_MESSAGE] = config.MESSAGE_CMD_UNKNOWN
            
            # Send response to the client and close the connection
            network.send_response(cl, response, False)
            
        except OSError as e:
            network.ledstatus.off()
            cl.close()
            print('[ERROR] Network Connection closed')

# Base screen for the demo
class DemoScreen(Screen):
    def __init__(self):

        # Init
        super().__init__()
        print('super init: OK')
        
        # Label properties
        labelcaptionproperties = {
            'bdcolor' : False,
            'fgcolor' : GREEN,
            'bgcolor' : BLACK,
            'justify' : Label.CENTRE
        }

        # LEDs
        leds = [
            {'id':1,'row':100, 'col':50, 'caption':'LED A', 'state':False, 'color':GREEN, 'bdcolor':False, 'fgcolor':GREEN},
            {'id':2,'row':100, 'col':190, 'caption':'LED B', 'state':False, 'color':YELLOW, 'bdcolor':False, 'fgcolor':YELLOW},
            {'id':3,'row':100, 'col':310, 'caption':'LED C', 'state':False, 'color':RED, 'bdcolor':False, 'fgcolor':RED}
        ]

        # Create the writers with small and default fonts
        wris = CWriter(ssd, fonts, GREEN, WHITE, verbose=False)
        wrid = CWriter(ssd, fontd, GREEN, WHITE, verbose=False)
        print('writers: OK')

        # Vertical gap between widgets
        gap = 30
        
        # Initial position for screen col & row
        col = 2
        row = 2

        # Caption
        self.lblcaption = Label(wrid, row, col, CAPTION, bdcolor=False, fgcolor=GREEN)

        # Last update
        row = row + gap
        self.lbllastupdate = Label(wrid, row, col, 'LED=NN @ YYYY-MM-DD hh:mm:ss', fgcolor=WHITE)

        # Device attributes temp+humidity+baro
        for led in leds:
            if led['id'] == 1:
                row = led['row']
                col = led['col']
                lblled_a = Label(wrid, row, col, led['caption'], **labelcaptionproperties)
                self.led_a = LED(wrid, row +  gap, col + 10, color=led['color'], bdcolor=led['bdcolor'], fgcolor=led['fgcolor'])
            if led['id'] == 2:
                row = led['row']
                col = led['col']
                lblled_b = Label(wrid, row, col, led['caption'], **labelcaptionproperties)
                self.led_b = LED(wrid, row + gap, col + 10, color=led['color'], bdcolor=led['bdcolor'], fgcolor=led['fgcolor'])
            if led['id'] == 3:
                row = led['row']
                col = led['col']
                lblled_c = Label(wrid, row, col, led['caption'], **labelcaptionproperties)
                self.led_c = LED(wrid, row +  gap, col + 10, color=led['color'], bdcolor=led['bdcolor'], fgcolor=led['fgcolor'])
        
        # Screen must at least one active widget - using a dummy button at bottom left of the sceen.
        Button(wrid, ssd.height - 20, 10, height=10, width=10, fgcolor=WHITE, bdcolor=BLACK, bgcolor=BLACK, text=VERSION)
        # CloseButton(wrid)

    def after_open(self):
        """Framebuffer methods run after_open
        Called after a screen has been displayed
        """
        display.usegrey(False)
        # horz line x,y,w,c below the caption
        ssd.hline(0, self.lblcaption.height, ssd.width, GREEN)

        # Register the task to get the device attributes in regular intervals
        self.reg_task(asyncio.create_task(request_handler(self.lbllastupdate, self.led_a, self.led_b, self.led_c)))
        print('reg_task: OK')

        print('after_open: OK')

def demo():
    """Demo running on lcd display with dimensions 480x320"""
    if ssd.width < 480 or ssd.height < 320:
        print("This demo requires a display of 480x320 pixels.")
    else:
        # A class is passed here, not an instance.
        Screen.change(DemoScreen)

demo()
