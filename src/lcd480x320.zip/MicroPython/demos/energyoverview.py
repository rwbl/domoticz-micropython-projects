# energyoverview.py,rwbl,20240121
# Demo script for the Waveshare Pico-ResTouch-LCD-3.5 connected to the Raspberry Pi Pico WH.
# Domoticz energy & weather data displayed in 4 TileBox custom widgets.
# The data is received as JSON object from the Domoticz server via Domoticz HTTP POST request from automation script dzVents.
# Domoticz PUSHES the data to the Pico W server.

# NOTES
# Tested with MicroPython v1.22.1 on 2024-01-05; Raspberry Pi Pico W with RP2040
# Network and device configuration in config.py.
# Check out the avialable memory. See log like Free RAM 32736 (defined in ugui.py garbage_collect).
# IMPORTANT: Thonny Stop/Restart backend (CTRL+F2) prior running the script (F5).
# This might be done twice in case MemoryError: memory allocation failed, allocating NNNN bytes.

# DEPENDENCIES
# micropython-micro-gui library.

# Released under the GNU GENERAL PUBLIC LICENSE v3.0. See LICENSE.
# Copyright (c) 2024 Robert W.B. Linn

# Imports
# Initialise hardware and framebuf before importing modules.
import hardware_setup

# Create SSD instance. Must be done first because of RAM use.
from gui.core.ugui import Screen, ssd, display

from gui.widgets import Label

# CWriter with font(s) - be careful high memory usage
from gui.core.writer import CWriter
import gui.fonts.courier20 as courier20

from gui.core.colors import *

# Custom Widgets
from demos.mywidgets import (
    MyTileBox,
)

import uasyncio as asyncio
import gc
import time
import json

# Network
from web.server import Server
# Configuration with secrets
import config

VERSION = 'v20240121'
CAPTION = 'Domoticz Demo Energy Overview using Custom TileBoxes'
print(f'{CAPTION} {VERSION}')

# Delay ms to give time for the screen to build
_SCREEN_BUILD_DELAY = 250

async def request_handler(lblcaption, tiles):
    """Handle request enabling to change the tiles caption,text"""
    
    await asyncio.sleep_ms(_SCREEN_BUILD_DELAY)

    # Network connect
    print('network: connecting...')
    # Create network object
    network = Server(config.WIFI_SSID, config.WIFI_PASSWORD, DEBUG=True)
    # Connect to the network and get the server object
    server = network.connect()
    print('network: OK')

    while True:
        try:
            # Get client connection and the request data
            cl, request = network.get_client_connection(server)
           
            # Parse the post data. In case of error, the status is 0.
            data, status = network.parse_post_request(request)
            print(data, status)

            # Create the HTTP response JSON object
            response = {}

            # Set the response KEY_TITLE
            # Can be used assign the postdata, but is rather large for this solution
            response[config.KEY_TITLE] = "energyoverview"

            # If status is 1, then the post response is properly parsed, lets change the led state.
            if status == 1:

                lblcaption.value(f'{data['caption']} {data['lastupdate']}')

                tilesdata = data['tiles']
                # Update the tiles caption and text
                for item in tilesdata:
                    id = item['id']
                    tiles[id].newcaption(item['caption'])
                    tiles[id].newtext(item['text'])
                    await asyncio.sleep_ms(_SCREEN_BUILD_DELAY)

                # Response OK
                response[config.KEY_STATE] = config.STATE_OK
                response[config.KEY_MESSAGE] = status
            else:
                # Error with unknown command
                response[config.KEY_STATE] = config.STATE_ERR
                response[config.KEY_MESSAGE] = config.MESSAGE_CMD_UNKNOWN
            
            # Send response to the client and close the connection
            network.send_response(cl, response, False)
            
        except OSError as e:
            network.ledstatus.off()
            cl.close()
            print('[ERROR] Network Connection closed')

class DemoScreen(Screen):
    
    def __init__(self):

        tilesdef = [
            {"id":1, "row":50, "col": 50, "width":150, "caption":"Gas kWh","captionfgcolor":MAGENTA,"text":[1,"2","3"]},
            {"id":2, "row":50, "col": 250, "width":150, "caption":"Power kWh","captionfgcolor":RED,"text":["4","5","6"]},
            {"id":3, "row":160, "col": 50, "width":150, "caption":"Water m3","captionfgcolor":BLUE,"text":[1,"2","3"]},
            {"id":4, "row":160, "col": 250, "width":150, "caption":"Weather","captionfgcolor":YELLOW,"text":["4","5","6"]},
        ]

        super().__init__()
        wri = CWriter(ssd, courier20, GREEN, BLACK, verbose=False)

        # Create the caption - will be updated by handle_request
        col = 10
        row = 10
        self.lblcaption = Label(wri, row, col, "Energy Overview HH:MM:SS")

        # Create the 4 tiles 2x2
        self.tiles = []
        for tiledef in tilesdef:
            row = tiledef["row"]
            col = tiledef["col"]
            width = tiledef["width"]
            caption = tiledef["caption"]
            text = tiledef["text"]
            captionfgcolor = tiledef["captionfgcolor"]
            # print(row,col,width,caption)
            # Append a tilebox to the list
            self.tiles.append(
                MyTileBox(wri,
                          row, col, width,
                          caption=caption, captionfgcolor=captionfgcolor, captioninvert=False,
                          text=text))

    def after_open(self):
        """Framebuffer methods run after_open
        Called after a screen has been displayed
        """
        display.usegrey(False)

        # Register the task to get the device attributes in regular intervals
        self.reg_task(asyncio.create_task(request_handler(self.lblcaption, self.tiles)))
        print('reg_task: OK')

        print('after_open: OK')


def demo():
    """Demo running on lcd display with dimensions 480x320"""
    if ssd.width < 480 or ssd.height < 320:
        print("This demo requires a display of 480x320 pixels.")
    else:
        # A class is passed here, not an instance.
        Screen.change(DemoScreen)

# Run the demo
demo()

