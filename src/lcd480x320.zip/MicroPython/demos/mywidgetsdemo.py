# mywidgetsdemo.py,rwbl,20240122
# Demo for the custom widgets extentions.

# NOTES
# Tested with MicroPython v1.22.1 on 2024-01-05; Raspberry Pi Pico W with RP2040
# Network and device configuration in config.py.
# Check out the avialable memory. See log like Free RAM 32736 (defined in ugui.py garbage_collect).
# IMPORTANT: Thonny Stop/Restart backend (CTRL+F2) prior running the script (F5).
# This might be done twice in case MemoryError: memory allocation failed, allocating NNNN bytes.

# DEPENDENCIES
# micropython-micro-gui library.

# Released under the GNU GENERAL PUBLIC LICENSE v3.0. See LICENSE.
# Copyright (c) 2024 Robert W.B. Linn

# Imports
# Initialise hardware and framebuf before importing modules.
import hardware_setup

# Create SSD instance. Must be done first because of RAM use.
from gui.core.ugui import Screen, ssd, display

from gui.widgets import LED, Label	#, Button

# CWriter with font(s) - be careful high memory usage
from gui.core.writer import CWriter
import gui.fonts.courier20 as courier20
import gui.fonts.arial10 as arial10

from gui.core.colors import *

# Widgets
from demos.mywidgets import (
    MyTile,
    MyTileBox,
    MyLabelledCircle
)

import uasyncio as asyncio
import gc
import time

# Delay ms to give time for the screen to build
_SCREEN_BUILD_DELAY = 250

def connector(fromwidget, towidget, offset, color):
    """Connect widgets.
    
    fromwidget = dict[x,y]
    towidget = dict[x,y]
    offset = length of hline/vline
    """
    x1 = fromwidget["x"]
    y1 = fromwidget["y"]
    x2 = towidget["x"]
    y2 = towidget["y"]
    display.vline(x1, y1 - offset, offset, color=color)
    display.vline(x2, y2 - offset, offset, color=color)
    display.hline(x1, y1 - offset, int(x2 - x1), color=color)

async def request_handler(self):
    """Handle request enabling to change the tiles caption,text"""

    # Example change text tile 1
    # self.tiles[0].newcaption("New Caption")
    # text = self.tiles[0].newtext(["New Line1","New Line2"])
    # print(text)

    # Examples setting labelledcircle attributes
    #self.lca.newcaption("Sol1")
    #self.lca.newvalue(-0.11)
    #self.lca.newunit("kwh")

    # await asyncio.sleep_ms(_SCREEN_BUILD_DELAY)

class DemoScreen(Screen):
    
    def __init__(self):

        super().__init__()

        # Define the writers - high mem take-up
        # To get the font char width use wri.font.get_ch("A") See gui.writer.py
        wri = CWriter(ssd, courier20, GREEN, BLACK, verbose=False)
        wris = CWriter(ssd, arial10, GREEN, BLACK, verbose=False)

        # Caption
        row = 10
        col = 10
        self.caption = Label(wri, row, col, "MyWidgets Demo", bdcolor=GREEN)

        # Tile
        row = self.caption.row + int(wri.height) + 20
        col = 10
        self.mt = MyTile(wri,
                         row, col,
                         width=100,
                         bdcolor=GREEN,
                         caption="MyTile", captionfgcolor=RED, captioninvert=True,
                         text="Text")
        
        # TileBox
        # Ensure the row + width < ssd.height.
        # Need to fix in ugui because width is used for the height.
        row = 150
        col = 20
        width = 160
        self.tba = MyTileBox(wri, row, col, width,
                             bdcolor=RED,
                             caption="MyTileBox A", captionfgcolor=WHITE, captioninvert=False,
                             text=[1,2,3])
        #col = col + width + col
        #self.tbb = MyTileBox(wri, row, col, width,
        #          caption="MyTileBox B", captionfgcolor=RED, captioninvert=True,
        #          text=["A","B","C"])

        # LabelledCircle
        # Best height is 100 for a writer with height 20
        row = self.caption.row + int(wri.height) + 1
        col = int(ssd.width / 2) - 30
        self.lca = MyLabelledCircle(wri, row, col, height=100, caption="LC A", captioninvert=True, value="1958", sep=True, sepcolor=RED,unit="unit")

        col = self.lca.col + self.lca.width + 50
        self.lcb = MyLabelledCircle(wri, row, col, height=100,
                                        circlebdcolor=RED, circlebgcolor=BLUE,
                                        caption="LC B", captionbgcolor=BLUE,
                                        value="1958", valuebgcolor=BLUE,
                                        sep=True, sepcolor=WHITE,
                                        unit="myunit", unitwriter=wris, unitbgcolor=BLUE)

    def after_open(self):
        """Framebuffer methods run after_open.
        Called after a screen has been displayed
        """
        display.usegrey(False)

        # Connect the labelledcircles right-to-left
        connector(self.lca.right, self.lcb.left, 0, YELLOW)

        # Connect the labelledcircles top-to-top with offset
        connector(self.lca.top, self.lcb.top, 20, RED)
        
        # Register the task to get the device attributes in regular intervals
        self.reg_task(asyncio.create_task(request_handler(self)))
        print('reg_task: OK')

        print('after_open: OK')


def demo():
    if ssd.height < 320 or ssd.width < 480:
        print(" This test requires a display of at least 480x320 pixels.")
    else:
        print("Testing micro-gui...")
        # A class is passed here, not an instance.
        Screen.change(DemoScreen)

demo()
