# hardware_setup.py,rwbl,20240114

# Hardware setup for the Waveshare Pico-ResTouch-LCD-3.5.
# 3.5inch Touch Display Module for Raspberry Pi Pico, 65K Colors, 480 x 320 Pixels,
# Resistive Touch Controller XPT2046, ILI9488 Driver, SPI Bus. 
# Reference: https://www.waveshare.com/pico-restouch-lcd-3.5.htm
# The built-in controller used by Pico-ResTouch-LCD-3.5 is ILI9488, which is a 480 x 320 pixel RGB LCD controller.
# RGB565 format, LCD 16Bits parallel port screen, hardware uses a parallel port to serial chip.

# The Pico WH is inserted in the built-in Pico socket.
# The solutions are display only, no touch support and no pushbuttons.
# Tested with MicroPython v1.22.1 on 2024-01-05; Raspberry Pi Pico W with RP2040

# Uses the micropython-micro-gui:
# Released under the MIT License (MIT)
# https://github.com/peterhinch/micropython-micro-gui

# Wiring if pushbuttons are used (adjust accordingly).
# Pin  Meaning
# 16   Operate current control
# 17   Decrease value of current control
# 18   Select previous control
# 19   Select next control
# 20   Increase value of current control

from machine import Pin, SPI, freq
import time
import gc

# The ili9486 driver is used for the ILI9488 Driver
from drivers.ili94xx.ili9486 import ILI9486 as SSD
# ILI9488: Fix color inversion
SSD.COLOR_INVERT = 0xFFFF

# RP2 overclock
freq(250_000_000)  

# Define the arbitrary pins - fixed by the supplier
LCD_DC   = 8    # LCD Command/Data. writing command when DC = 0, writing data when DC=1.
LCD_CS   = 9    # LCD chip select. the chip can be enabled when the voltage of CS is low.
LCD_SCK  = 10   # SPLI CLK. SPI communication clock.
LCD_MOSI = 11   # SPI MOSI. transmitted data, that is, RGB data.
LCD_MISO = 12   # SPI MISO.
LCD_BL   = 13   # LCD backlight.
LCD_RST  = 15   # LCD reset. Usually set to 1 and is pulled low when the module is powered on.
TP_CS    = 16   # Touch controller chip select.
TP_IRQ   = 17   # Touch controller interrupt.

# Init the pins
pcs = Pin(LCD_CS, Pin.OUT, value=0)
prst = Pin(LCD_RST, Pin.OUT, value=1)
pdc = Pin(LCD_DC, Pin.OUT, value=1) 
ptp_cs = Pin(TP_CS,Pin.OUT, value=1)
pirq = Pin(TP_IRQ,Pin.IN)

# Create SPI peripheral 1 at frequency of 400kHz.
spi = SPI(1, sck=Pin(LCD_SCK), mosi=Pin(LCD_MOSI), miso=Pin(LCD_MISO), baudrate=40_000_000)

# Precaution before instantiating framebuf
gc.collect()

# Create and export an SSD instance
ssd = SSD(spi, pcs, pdc, prst, usd=True, mirror=False)

# Define control buttons - these are not used.
#nxt = Pin(18, Pin.IN, Pin.PULL_UP)  # Move to next control
#sel = Pin(19, Pin.IN, Pin.PULL_UP)  # Operate current control
#prev = Pin(20, Pin.IN, Pin.PULL_UP)  # Move to previous control
#increase = Pin(21, Pin.IN, Pin.PULL_UP)  # Increase control's value
#decrease = Pin(22, Pin.IN, Pin.PULL_UP)  # Decrease control's value

# Define a dummy pin as a pin is required by the display instance
dummypin = Pin(0, Pin.IN)

# Create and export a Display instance
from gui.core.ugui import Display

# Set the button mode.
# 3-button mode with dummy pins
display = Display(ssd, dummypin, dummypin, dummypin)  
# 3-button mode
# display = Display(ssd, nxt, sel, prev)  
# 5-button mode
# display = Display(ssd, nxt, sel, prev, increase, decrease)  

print('hardware_setup: OK')
