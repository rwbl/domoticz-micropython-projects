"""
File: main.py
Date: 20240122
Author: Robert W.B. Linn
Description:
Start a LCD480x320 demo.
"""

# import demos.lcdledcontrol
# import demos.temphumbaro
# import demos.thermostats
# import demos.energyoverview
# import demos.powerdistribution
