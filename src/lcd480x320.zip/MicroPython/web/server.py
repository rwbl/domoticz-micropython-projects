"""
File:	server.py
Date:	20240114
Author:	Robert W.B. Linn

:description
Class to manage the PicoW RESTful webserver.
Commands set via HTTP GET or POST requests with HTTP response JSON object.

:examples
***HTTP GET***
LED ON: http://picow-ip/led1/on with HTTP response: {"status": "OK", "title": "/led1/on", "message": "On"}
LED OFF: http://picow-ip/led1/off with HTTP response: {"status": "OK", "title": "/led1/off", "message": "Off"}
LED STATE: http://picow-ip/led1/state with HTTP response: {"status": "OK", "title": "/led1/state", "message": "On"}
In case of error, the HTTP response:
{"status": "ERROR", "title": "/led1/x", "message": "Unknown command."}
[Thonny Log]
LEDControl Network GET v20230310
Network connected OK
Network IP picow-ip
Network listening on ('0.0.0.0', 80)
Network client connected from client-ip
HTTP Command /led1/on
HTTP Response {"title": "/led1/on", "message": "On", "status": "OK"}
Network connection closed

***HTTP POST***
LED ON: curl -v -H "Content-Type: application/json" -d "{\"state\":1}" http://192.168.1.108
{"status": "OK", "title": {"state": 1}, "message": 1}
LED OFF: curl -v -H "Content-Type: application/json" -d "{\"state\":0}" http://192.168.1.108
{"status": "OK", "title": {"state": 0}, "message": 0}
In case of error (like JSON object not valid = can be be parsed), the HTTP response:
HTTP Response: {"status": "ERROR", "title": "{state:vvv}", "message": "Unknown command."}
with console log [ERROR] HTTP POST request not valid (ValueError).

:notes
When using curl ensure to escape the " to \" in the JSON object.

:log
LEDControl Network v20230310
Network connected OK
Network IP 192.168.1.108
Network listening on ('0.0.0.0', 80)
Network client connected from 192.168.1.94
HTTP Command {'state': 1}
HTTP Response {"status": "OK", "title": {"state": 1}, "message": 1}
Network connection closed
Network client connected from 192.168.1.94
HTTP Command {'state': 0}
HTTP Response {"status": "OK", "title": {"state": 0}, "message": 0}
Network connection closed
Network client connected from 192.168.1.94
[ERROR] HTTP POST request not valid (ValueError).
HTTP Command {state:vvv}
HTTP Response {"status": "ERROR", "title": "{state:vvv}", "message": "Unknown command."}
Network connection closed
"""

__name__ 	= "server"
__class__	= "Server"
__version__ = '20240114'
__author__	= "Robert W.B. Linn"

# Libraries
import network
import requests
import socket
import time
from machine import Pin
import json

"""
Class Server
"""
class Server:
    # Constants
    _CRLF = chr(13) + chr(10)
    _SPACE = chr(32)

    # Domoticz
    # HTTP response JSON keys
    _KEY_STATE = 'status'
    _KEY_TITLE = 'title'
    _KEY_MESSAGE = 'message'

    # Messages used for HTTP response
    _STATE_OK = 'OK'
    _STATE_ERR = 'ERROR'
    _MESSAGE_EMPTY = ''
    _MESSAGE_UNKNOWN = 'Unknown'
    _MESSAGE_CMD_UNKNOWN = 'Unknown command.'
    _MESSAGE_ON = 'On'
    _MESSAGE_OFF = 'Off'

    def __init__(self, wifi_ssid, wifi_password, STATUS_PIN="LED", DEBUG=False):
        """
        Init the network with defaults.
        
        :param string wifi_ssid
            SSID of the network to connect
            
        :param string wifi_password
            Passord of the network to connect
            
        :param string | int STATUS_PIN
            Pin number of the LED indicating network status connected
            
        :param bool DEBUG
            Flag to set the log for debugging purposes
        """
        self._debug = DEBUG
        self._wifi_ssid = wifi_ssid
        self._wifi_password = wifi_password

        # Create the onboard LED object to indicate controller is up and network connected
        self._ledstatus = Pin(STATUS_PIN, Pin.OUT)
        self._ledstatus.off()

    def log(self, msg):
        """
        Log to the console if debug flag is true.
        
        :param string msg
            Message to print
        """
        if self._debug:
            print(f'[DEBUG] {msg}')

    def connect(self):
        """
        Connect to the network using the class SSID and password.
        If connected start listening for incoming connections.

        :param None

        :return object server
            Server object.
        
        :example
            # Create network object
            network = Server(config.WIFI_SSID, config.WIFI_PASSWORD)
            # Connect to the network and get the server object
            server = network.connect()
        """
        try:
            wlan = network.WLAN(network.STA_IF)
            try :
                if wlan.active() :
                    self.log("[connect] Network disconnecting.")
                    wlan.disconnect()
                    wlan.active(False)
                    time.sleep_ms(150)
            except Exception as e :
                print(str(e))

            # wlan = network.WLAN(network.STA_IF)
            wlan.active(True)
            wlan.connect(self._wifi_ssid, self._wifi_password)

            # Network connection
            self.log(f'[connect] Network waiting for connection...')
            max_wait = 10
            while max_wait > 0:
                if wlan.status() < 0 or wlan.status() >= 3:
                    break
                max_wait -= 1
                time.sleep(1)

            if wlan.status() != 3:
                self._ledstatus.off()
                raise RuntimeError('[ERROR connect] Network connection failed!')
            else:
                self._ledstatus.on()
                self.log(f'[connect] Network connected OK.')
                status = wlan.ifconfig()
                self.log(f'[connect] Network IP ' + status[0] )

            # Network Get address
            addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1]

            # Network Create the server socket
            server = socket.socket()

            # Option to reuse addr to avoid error EADDRINUSE
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            # Bind the address befor starting to listen for icoming client connections
            server.bind(addr)
            server.listen(1)
            self.log(f'[connect] Network listening on {addr}.')
            # self.log(server)
            return server
        except OSError as e:
            self._ledstatus.off()
            raise RuntimeError('[ERROR connect] Network connection closed.')

    def connect2(self):
        """
        Connect to the network using the class SSID and password.
        Do not start listening like for connect().

        :param None

        :return object wlan
            WLAN object
        
        :example
            # Create server object
            server = Server(config.WIFI_SSID, config.WIFI_PASSWORD, DEBUG=True)
            # Connect to the server and get the wlan (station) object
            station = server.connect2()
            # Do something and then disconnect
            server.send_get_request(url)
            station.disconnect()
        """
        try:
            wlan = network.WLAN(network.STA_IF)
            try :
                if wlan.active() :
                    self.log("[connect2] Network disconnecting.")
                    wlan.disconnect()
                    wlan.active(False)
                    time.sleep_ms(150)
            except Exception as e :
                print(str(e))

            wlan.active(True)
            wlan.connect(self._wifi_ssid, self._wifi_password)

            # Network connection
            self.log(f'[connect2] Network waiting for connection...')
            max_wait = 10
            while max_wait > 0:
                if wlan.status() < 0 or wlan.status() >= 3:
                    break
                max_wait -= 1
                time.sleep(1)

            if wlan.status() != 3:
                self._ledstatus.off()
                raise RuntimeError('[ERROR connect2] Network connection failed!')
            else:
                self._ledstatus.on()
                self.log(f'[connect2] Network connected OK.')
                status = wlan.ifconfig()
                self.log(f'[connect2] Network IP ' + status[0] )
            return wlan
        
        except OSError as e:
            self._ledstatus.off()
            cl.close()
            raise RuntimeError('[ERROR connect2] Network connection closed.')

    def get_client_connection(self, server):
        """
        Get the client connection.
        
        :param object server
            Server object which is listening
        
        :return object cl
        
        :return string data
            The requested data format depends on the request

        :example
            cl, request = network.get_client_connection(server)
        """
        # Get client connection
        cl, addr = server.accept()
        self.log(f'Network client connected from {addr[0]}.')
        
        # Get the request data used to extract the command
        request = cl.recv(1024)
        # Return cl and the request data
        return cl, request

    def send_response(self, cl, response, close):
        """
        Send the response to the client, i.e. Domoticz, curl etc. as JSON object.
        
        :param object cl
        
        :param JSON response
        
        :param bool close
        """
        self.log(f'HTTP Response={json.dumps(response)}')

        # Important to have a blank line prior JSON response string
        # Note the use of json.dumps for the response
        cl.send('HTTP/1.1 200 OK'+self._CRLF+'content-type: application/json'+self._CRLF+self._CRLF+json.dumps(response))
        
        # If flag close is set, ensure to close the connection        
        if close == True:
            cl.close()
            self.log(f'Network connection closed')

    def send_get_request(self, url):
        """
        Network submit http get request to the domoticz server.

        :param string url
            URL of the HTTP request
        
        :return int status
            0 = Error, 1 = OK
            
        :return string content
            HTTP response content sent by Domoticz engine
        
        :example
            Update the Domoticz temp+hum device with IDX 15
            http://domoticz-ip:port/json.htm?type=command&param=udevice&idx=15&nvalue=0&svalue=16;55;1
        """
        status = 0
        content = ''
        self.log(f'Send GET request url={url}')
        try:
            # URL encode space
            url = url.replace(' ', '%20')
            r = requests.get(url)
            j = json.loads(r.content)
            content = j
            self.log(f'Send GET request status={j['status']}')
            r.close()
            status = 1
        except OSError as e:
            # print(f'[ERROR] Sending data {e}')
            raise Exception(f'[ERROR send_get_request] Sending data {e}.')
        except ValueError as e:
            # print(f'[ERROR] {e}, {r.content.decode()}')
            raise Exception(f'[ERROR send_get_request] {e}, {r.content.decode()}.')
        return status, content 

    def parse_get_request(self, request):
        """
        Parse the command from the HTTP GET Request.
        The first line of the request contains the command.
        The first line is split and the 2nd item holds the command + data.
        Example first line with the command:
        GET /led1/on HTTP/1.1
        The command is /led1/on.
        
        :param string request
            HTTP GET request
        
        :return string command
            Command, i.e. /led1/on
            
        :return int status
            0 = Error, 1 = OK

        :example
            # Parse the get data. In case of error, the status is 0.
            cmd, status = network.parse_get_request(request)
        """
        status = 0
        cmd = self._MESSAGE_CMD_UNKNOWN
        
        # Split the decoded request string into a list
        data = str(request.decode()).split(self._CRLF)
        
        # Check if there is data to get the first item
        if (len(data) > 0):
            # print(data[0])
            # Split the first item which is the command string into a list with 3 items
            cmds = data[0].split(self._SPACE)
            # Check length and get the 2nd item, i.e. /led1/on
            if len(cmds) == 3:
                cmd = cmds[1]
                status = 1
            else:
                print(f'[ERROR parse_get_request] HTTP GET number of command items invalid. Expect 3, got {len(cmds)}.')
        else:
            print(f'[ERROR parse_get_request] HTTP GET request not valid.')
        self.log(f'[parse_get_request] HTTP Command={cmd}')
        
        # Return the command, i.e. /led1/on etc.
        return cmd, status
    
    def send_post_request(self, url, postdata):
        """
        Network submit http post request to the domoticz server.

        :param string url
            URL of the HTTP request
            
        :param string postdata
            postdata as JSON object
        
        :return int status
            0 = Error, 1 = OK
        
        :example
            Trigger the Domoticz custom event named DHT22 with data JSON object
            http://domoticz-ip:port/json.htm?type=command&param=customevent&event=DHT22&data={"h": 58, "t": 16, "s": 0}
        """
        status = 0
        self.log(f'Send POST request url={url}, postdata={postdata}')
        try:
            r = urequests.post(url, data=json.dumps(postdata))
            j = json.loads(r.content)
            self.log(f'Send POST request status={j['status']}.')
            r.close()
            status = 1
        except OSError as e:
            print(f'[ERROR send_post_request] Sending data {e}.')
            # raise Exception('Network Connection failed.')
        return status 

    def parse_post_request(self, request):
        """
        Parse the command from the HTTP POST Request.
        The last line of the HTTP request contains the command + data.
        The HTTP request is decoded and split as a string list.
        The last line is a JSON object with key:value pair(s).

        :param string request
            HTTP request

        :return string command
            Command as JSON key:value pair(s), i.e. {"led":1}
            
        :return int status
            0 = Error, 1 = OK

        :example
            # Parse the post data. In case of error, the status is 0.
            data, status = network.parse_get_request(request)
        """
        status = 0
        cmd = self._MESSAGE_CMD_UNKNOWN

        # Split the decoded request string into a list
        data = str(request.decode()).split(self._CRLF)
        
        # Check if there is data to get the last item
        # At least 8 items
        if (len(data) > 7):
            # JSON parse the last list item holding the command as JSON string
            # Convert the string to a JSON object
            try:
                cmd = json.loads(data[len(data) - 1])
                status = 1
            except ValueError:
                # In case the JSON data can not be parsed
                cmd = data[len(data) - 1]
                print('[ERROR parse_post_request(] HTTP POST request not valid (ValueError).')            
        else:
            print(f'[ERROR parse_post_request] HTTP POST request not valid (Not enought items, must be 8 or more).')
        self.log(f'[parse_post_request] HTTP Command={cmd}')
        
        # Return the command as JSON object, i.e. HTTP Command: {'state': 'on'}
        return cmd, status

    def get_server_time(self, ip):
        """
        Get the server time.

        :param string ip
            IP address of the Domoticz server

        :return string servertime
            Parsed from HTTP response, like
            {"ServerTime": "2021-01-13 23:10:13","status": "OK","title": "getServerTime"}

        :return int status
            0 = Error, 1 = OK

        :example
            status, servertime = network.get_server_time('NNN.NNN.NNN.NNN')
        """
        url = "http://"+ip+"/json.htm?type=command&param=getServerTime"
        status, response = self.send_get_request(url)
        if status == 1:
            return status, response['ServerTime']
        else:
            return status, None
