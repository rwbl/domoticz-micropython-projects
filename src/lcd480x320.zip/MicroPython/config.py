# config.py,rwbl,20240115
# Global constants.
# Import configuration: import config.py
# Access configuration item: config.DOMOTICZ_IP

# Import the const package
from micropython import const

# Network - set SSID & Password
WIFI_SSID       = const('SSID')
WIFI_PASSWORD   = const('password')

# Set IP of the Pico W running as RESTful server
PICOW_IP = const('NNN.NNN.NNN.NNN')

# Domoticz
# Mode sets the domoticz server ip+port
# 0=test,1=production
_MODE = 1

# Domoticz IP + Port
if _MODE == 0:
    # Test system
    DOMOTICZ_IP = 'NNN.NNN.NNN.NNN:8080'
else:
    # Production system
    DOMOTICZ_IP = 'NNN.NNN.NNN.NNN:8080'

# Domoticz
# HTTP response JSON keys
KEY_STATE		= const('status')
KEY_TITLE		= const('title')
KEY_MESSAGE		= const('message')

# Messages used for HTTP response
STATE_OK			= const('OK')
STATE_WARNING		= const('WARNING')
STATE_ERR			= const('ERROR')
MESSAGE_EMPTY		= const('')
MESSAGE_UNKNOWN		= const('Unknown')
MESSAGE_CMD_UNKNOWN	= const('Unknown command.')
MESSAGE_ON			= const('On')
MESSAGE_OFF			= const('Off')

