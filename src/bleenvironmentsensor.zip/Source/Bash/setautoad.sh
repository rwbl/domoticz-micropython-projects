#!/bin/bash

# File: setautoad.sh
# Date: 20231215
# Author: Robert W.B. Linn
# Description:
# For the PICOES project, create the Domoticz device type Temp+Humidity+Baro, subtype Weather Station using MQTT Autodiscovery (MQTTAD).
# The message is publsihed with the retain flag.
# Read more about MQTTAD on Homeassistant.
# Make Executable:
# sudo chmod +x setautoad.sh
# Run:
# ./setautoad.sh

# Init
# Pause function waiting for enter key.
function pause(){
   read -p "$*"
}

echo 'Creating Domoticz Temp+Humidity+Baro (Weather Station) device'

# Option: delete all retained messages
echo 'Clearing retained messages ...'
mosquitto_sub -h localhost --remove-retained -t '#' -W 1

# Create the Domoticz devices with the goal to create a single Temp+Hum+Baro device.
echo 'Creating Domoticz devices ...'

mosquitto_pub -r -h 127.0.0.1 -p 1883 -t "domoticz/sensor/picoes/temperature/config" -m '{"name": "PICOES","device_class": "temperature","state_topic": "domoticz/sensor/picoes/state","value_template": "{{value_json.temperature}}","unit_of_measurement": "c","unique_id": "PICOEST","device": {"identifiers": "1"}}'

mosquitto_pub -r -h 127.0.0.1 -p 1883 -t "domoticz/sensor/picoes/humidity/config" -m '{"name": "PICOES","device_class": "humidity","state_topic": "domoticz/sensor/picoes/state","value_template": "{{value_json.humidity}}","unit_of_measurement": "%","unique_id": "PICOESH","device": {"identifiers": "1"}}'

mosquitto_pub -r -h 127.0.0.1 -p 1883 -t "domoticz/sensor/picoes/pressure/config" -m '{"name": "PICOES","device_class": "pressure","state_topic": "domoticz/sensor/picoes/state","value_template": "{{value_json.pressure}}","unit_of_measurement": "hpa","unique_id": "PICOESP","device": {"identifiers": "1"}}'

mosquitto_pub -r -h 127.0.0.1 -p 1883 -t "domoticz/sensor/picoes/battery/config" -m '{"name": "PICOES","device_class": "battery","state_topic": "domoticz/sensor/picoes/state","value_template": "{{value_json.battery}}","unit_of_measurement": "%","unique_id": "PICOESB","device": {"identifiers": "1"}}'

echo 'Devices created. Check the Domoticz log and the devices list'
pause 'Done, press [Enter] to continue...'
exit
