"""
File: main.py
Date: 20231212
Author: Robert W.B. Linn
Description:
Start the Pico W as Environment Sensor PICOES.
For details see bleenvsensor.py
"""

import bleenvsensor
