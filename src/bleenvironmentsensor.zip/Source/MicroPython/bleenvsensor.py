# File: bleenvsensor.py
# Date: 20231226
# Author: Robert W.B. Linn
# Description:
# Advertised via BLE simulated data temperature, humidity, airpressure, batterylevel.
#
# Test Advertising Payload:
# t=2557,hex=09FD, h=67,hex=43, p=1032,hex=0408, b=84,hex=54
# The data advertised has 24 bytes
# 02010607095049434F455309FFFFFE09FD4304085403190000 25
# Flags=020106: len=2, type=01, data=06 (02+04)
# Name=07095049434F4553: len=7, type=09, data=5049434F4553 which is the word PICOES
# Custom Data=09FFFFFE09FD43040854: len=9; type=FF; data=FFFE09FD43040854 which contains
# manufacturerid(2bytes)=FFFE, t(2bytes)=09FD(2557), h(1 byte)=43(67), p(2 bytes)=0408(1032), b(1 byte)=54(84)
# Appearance=03190000:len=3;type=19;data=0000
#
# Manufacturer ID:
# The manufacturer id is required for the blescanner to get proper key:value pair for the advertisement data.
# Without manufacturer id, the advertisement data would use the first 2 bytes from the data.
# Example:
# 'advertisementdata': {'manufacturer_data': True, '0X3139': '3538', 'rssi': -62}
# From the temperature data 31393538 the first two bytes are used as the key and the other 2 as value
# With manufacturer id:
# 'advertisementdata': {'manufacturer_data': True, '0XFFFE': '31393538', 'rssi': -62}
# The value contains the 4 bytes as required.
#
# OpenMQTTGateway (OMG):
# The PICOES is not supported by the OMG.
# To publish data, the name is used. Instead PICOES, the data as HEX string is set.
# The name field is parsed for example by Node-RED to publish using MQTT Autodiscover to Domoticz.
# Be aware ther the name is packed as BB (unsigned char).
#
# Notes:
# (1) The UUIDs are not used
# services=[bluetooth.UUID(0x181A), bluetooth.UUID("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")],
# (2) Do NOT use the picozero package:
# If the picozero package is loaded, BLE does not work anymore - ERROR 110, ETIMEDOUT.
# TODO: Explore root cause.

from machine import Pin
import sys
import bluetooth
import random
import struct
import time
from time import sleep
from ble_advertising_customdata import advertising_payload as advertisepayload
import config

# Create the LED as advertising status indicator
led_status = Pin(config.PIN_LED_ONBOARD, Pin.OUT)
led_status.value(config.STATE_OFF)

def sensor_task():
    """Set the random environment data and advertise.
    
    Instead simulated data, add real sensor data here.
    """
    t = 2450
    h = 55
    p = 1000
    b = 85
    while True:
        led_status.value(config.STATE_ON)

        # Create the environment random data
        t = int(random.uniform(1000, 3000))
        h = int(random.uniform(50, 60))
        p = int(random.uniform(900, 1100))
        b = int(random.uniform(20, 90))
        print(f't={t},hex={"{:04X}".format(t)}')
        print(f'h={h},hex={"{:02X}".format(h)}')
        print(f'p={p},hex={"{:04X}".format(p)}')
        print(f'b={b},hex={"{:02X}".format(b)}')

        # Create the custom data as 9 bytes
        # h=short (2 bytes), B=unsigned char (1 byte)
        # Data has 6 bytes = 2 + 1 + 2 +1
        data = struct.pack(">h", t) + struct.pack(">B", h) + struct.pack(">h", p) + struct.pack(">B", b)

        # Set the name of the device
        name = config.NAME
        
        # Use the OpenMQTTExplorer with workaround
        # The sensor name contains the data in HEX format
        if config.OMG:
            name = data.hex().upper()
            print(name, len(name))
        
        # Create the full payload as bytes to be advertised
        payload = advertisepayload(
            # services=[bluetooth.UUID("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")],
            name=name,
            manufacturer_id=config.MANUFACTURER_ID,
            custom_data=data)
        print(payload.hex().upper(), len(payload))

        # Advertise payload interval (ms) and payload as buffer protocol (bytes)
        ble.gap_advertise(config.GAP_ADVERTISE_INTERVAL, adv_data=payload)

        led_status.value(config.STATE_OFF)

        # Short delay prior next advertisement
        sleep(config.ADVERTISING_INTERVAL)

# Print version info
print(f'{config.VERSION}')

# Create ble object
ble = bluetooth.BLE()

# Activate BLE
# Before using any other method of this class, the radio to be at active state.
try:
    ble.active(True)
    # Increase the MTU if data length > 31
    # ble.config(gap_name='test',mtu=100)
    print(f'MAC Address: {ble.config('mac')[1].hex().upper()}, OMG Mode: {config.OMG}')
except OSError as e:
    # Error like etimedout
    print(f'[ERROR] {str(e)}.')
    sys.exit(1)


# Start the sensor task which has an infinite loop
sensor_task()
