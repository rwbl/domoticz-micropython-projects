# File: config.py
# Date: 20231229
# Author: Robert W.B. Linn
# Description:
# Constants for the Raspberry Pi Pico W Actuator (PICOACT).
# Import the configuration file: import config.py
# Access an configuration item: config.NAME

# Import the const package
from micropython import const

# Version Info - comment out if mem limited
VERSION = const('BLE Actuator v20231231')

# States
STATE_OFF = 0
STATE_ON = 1

# Name of the BLE sensor display
# For using the OMG, the name changes to sensor data HEX string (see below OMG)
NAME = const('PICOACT')

# Advertised manufacturer id
MANUFACTURER_ID = const(0xFFFE)

# Gap advertising interval in us
# 1 second = 1000000, but use 0.5 seconds
GAP_ADVERTISE_INTERVAL = 500000

# BLE Advertising Interval in seconds (default 2)
ADVERTISING_INTERVAL = const(2)

# Pico W onboard LED
PIN_LED_ONBOARD = const('LED')
PIN_LED_ONBOARD_NR = const(25)

# OpenMQTTGateway (OMG) to publish data HEX string as sensor name
OMG = False

