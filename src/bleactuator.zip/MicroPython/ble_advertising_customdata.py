# File: ble_advertising_customdata.py
# Date: 20231231
# Author: Robert W.B. Linn
# Description
# Helpers for generating BLE advertising payloads.
# Notes:
# The manufacturer id is required for the blescanner to get proper key:value pair for the advertisement data.
# Without manufacturer id, the advertisement data (just an example with 4 bytes) would be:
# 'advertisementdata': {'manufacturer_data': True, '0X3139': '3538', 'rssi': -62}
# From the temperature data 31393538 the first two bytes are used as the key and the other 2 as value
# With manufacturer id:
# 'advertisementdata': {'manufacturer_data': True, '0XFFFE': '31393538', 'rssi': -62}
# The value contains the 4 bytes.
#
# CREDITS
# Forked from MicroPython example - THANKS for sharing:
# https://github.com/micropython/micropython/tree/master > examples > bluetooth > ble_advertising.py

from micropython import const
import struct
import bluetooth

# Advertising payloads are repeated packets:
#   1 byte data length (N + 1)
#   1 byte type (see constants below)
#   N bytes type-specific data

_ADV_TYPE_FLAGS = const(0x01)
_ADV_TYPE_NAME = const(0x09)
_ADV_TYPE_UUID16_COMPLETE = const(0x3)
_ADV_TYPE_UUID32_COMPLETE = const(0x5)
_ADV_TYPE_UUID128_COMPLETE = const(0x7)
_ADV_TYPE_UUID16_MORE = const(0x2)
_ADV_TYPE_UUID32_MORE = const(0x4)
_ADV_TYPE_UUID128_MORE = const(0x6)
_ADV_TYPE_APPEARANCE = const(0x19)
_ADV_TYPE_CUSTOMDATA = const(0xFF)

# Mandatory manufacturer id to be advertised - value is set as argument
_MANUFACTURER_ID = const(0xFFFE)

# Generate a payload to be passed to gap_advertise(adv_data=...).
def advertising_payload(
    limited_disc=False,
    br_edr=False,
    name=None,
    services=None,
    manufacturer_id=_MANUFACTURER_ID,
    custom_data=None,
    appearance=0):

    # Define the payload
    payload = bytearray()

    def _append(adv_type, value):
        """append to the payload the
        data length (unsigned char 1 byte) + advertised type (unsigned char 1 byte) and
        the value (N bytes)
        """
        nonlocal payload
        payload += struct.pack("BB", len(value) + 1, adv_type) + value

    # Append to the payload the type flags (1 byte) and ???
    _append(
        _ADV_TYPE_FLAGS,
        struct.pack("B", (0x01 if limited_disc else 0x02) + (0x00 if br_edr else 0x04)),
    )

    # Append the name (N bytes)
    if name:
        _append(_ADV_TYPE_NAME, name)

    # Append the services with uuid (2,4 or 16 bytes)
    if services:
        for uuid in services:
            b = bytes(uuid)
            if len(b) == 2:
                _append(_ADV_TYPE_UUID16_COMPLETE, b)
            elif len(b) == 4:
                _append(_ADV_TYPE_UUID32_COMPLETE, b)
            elif len(b) == 16:
                _append(_ADV_TYPE_UUID128_COMPLETE, b)
    
    # Append the custom data containing:
    # manufacturer id (short, 2 bytes, big endian) and custom data (size depends on the data)
    # The data is packed as short with big endian
    if custom_data:
        b = struct.pack(">h", manufacturer_id) + custom_data
        _append(_ADV_TYPE_CUSTOMDATA, b)

    # Append the apperance as short 2 bytes
    # See org.bluetooth.characteristic.gap.appearance.xml
    _append(_ADV_TYPE_APPEARANCE, struct.pack("<h", appearance))

    return payload

def decode_field(payload, adv_type):
    """Decode a field into bytes"""
    i = 0
    result = []
    while i + 1 < len(payload):
        if payload[i + 1] == adv_type:
            result.append(payload[i + 2 : i + payload[i] + 1])
        i += 1 + payload[i]
    return result

def decode_name(payload):
    """Decode the payload field name"""
    n = decode_field(payload, _ADV_TYPE_NAME)
    return str(n[0], "utf-8") if n else ""

def decode_services(payload):
    """Decode the payload field services as array depending UUID type"""
    services = []
    for u in decode_field(payload, _ADV_TYPE_UUID16_COMPLETE):
        services.append(bluetooth.UUID(struct.unpack("<h", u)[0]))
    for u in decode_field(payload, _ADV_TYPE_UUID32_COMPLETE):
        services.append(bluetooth.UUID(struct.unpack("<d", u)[0]))
    for u in decode_field(payload, _ADV_TYPE_UUID128_COMPLETE):
        services.append(bluetooth.UUID(u))
    return services

def decode_custom_data(payload):
    """Decode the payload field customdata as string"""
    n = decode_field(payload, _ADV_TYPE_CUSTOMDATA)
    return str(bytes(n[0]).hex().upper())
    # return str(n[0], "utf-8") if n else ""

#Custom data: int 1958 = HEX 07A6
#Services
#02010603031A1805FF3139353803190000
#Flags=020106=length 2
#Services=03031A18=length 3
#Customdata=05FF31393538=length 5
#No services
#02010605FF3139353803190000
def demo():
    k1 = 1
    k2 = 0
    data = struct.pack(">B", k1) + struct.pack(">B", k2)
    print(data, type(data))

    # Create the payload to be advertised
    payload = advertising_payload(
        name="PICOW",
        custom_data=data,
        manufacturer_id=0xFFFE,
        # services=[bluetooth.UUID(0x181A), bluetooth.UUID("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")],
    )
    print(f'{k1}={"{:02X}".format(k1)}')
    print(f'{k1}={"{:02X}".format(k1)}')
    print(f'payload={payload.hex().upper()}')
    print(f'field name={decode_name(payload)}')
    print(f'field customdata={decode_custom_data(payload)}')
    print(f'field services={decode_services(payload)}')

if __name__ == "__main__":
    demo()
