# File: bleactuator.py
# Date: 20231229
# Author: Robert W.B. Linn
# Description:
# Advertised via BLE the state of 2 buttons (actuators).
# The Pico Breadboard Kit buttons K1-K2 are used.
# NOTE: The buttons K3-K4 are planned next version.
#
# Test Advertising Payload:
# The data advertised has 5 fields with total length of NN bytes
# 02010608095049434F41435406FFFEFF01000103190000 23
# 020106 08095049434F414354 06FFFEFF010001 03190000 23
# Flags=020106: len=2, type=01 + data=06 (02+04)
# Name=07095049434F4553: len=8, type=09 + data=5049434F414354 which is the word PICOACT (length 7 characters)
# Custom Data=06FFFEFF010001: len=6; type=FF + data=FEFF010001 which contains
# manufacturerid(2bytes)=FFFE, changeindicator(1byte)=00 or 01, buttonk1 state(1byte)=00 or 01, buttonk2 state(1byte)=00 or 01 
# Appearance=03190000:len=3; type=19 + data=0000
#

from machine import Pin
import sys
import bluetooth
import random
import struct
import time
from time import sleep
from ble_advertising_customdata import advertising_payload as advertisepayload
import config

# Create the LED as advertising status indicator
led_status = Pin(config.PIN_LED_ONBOARD, Pin.OUT)
led_status.value(config.STATE_OFF)

# Create the Buttons K1 (Yellow), K2 (Green)
BUTTON_K1_PINNR = 18
button_k1 = Pin(BUTTON_K1_PINNR, Pin.IN, Pin.PULL_UP)
BUTTON_K2_PINNR = 19
button_k2 = Pin(BUTTON_K2_PINNR, Pin.IN, Pin.PULL_UP)

# Button globals handling the button interrupt and button debounce time
interrupt_flag = 0
debounce_time = 0

# Global button_data
button_data = None

def callback_button(pin):
    """Callback for the button pressed"""

    global button_data
    global button_k1, button_k2    
    global interrupt_flag, debounce_time
    
    led_status.value(config.STATE_ON)

    # Init the button states
    state_k1 = 0
    state_k2 = 0
    
    # Check debounce
    if (time.ticks_ms()-debounce_time) > 500:
        # Interrupt flag set
        interrupt_flag = 1
        # Get the ticks for handling debounce
        debounce_time = time.ticks_ms()

        print(f'[DEBUG] callback_button: pin={pin}')
        if pin is button_k1:
            state_k1 = 1
        elif pin is button_k2:
            state_k2 = 1
        # and so on
        
        # Set the button data
        button_data = struct.pack(">B", state_k1) + struct.pack(">B", state_k2)
        print(f'[DEBUG] callback_button: data={button_data.hex()}')

    led_status.value(config.STATE_OFF)

# Assign interrupt to the buttons
button_k1.irq(trigger=Pin.IRQ_FALLING, handler=callback_button)
button_k2.irq(trigger=Pin.IRQ_FALLING, handler=callback_button)

# BLE Advertise id
advertise_id = 1

def actuator_task(advertise_id):
    """Set the button state and advertise"""

    # Get the button data set by the button callback
    global button_data

    # Create the custom data as 2 bytes
    # h=short (2 bytes), B=unsigned char (1 byte)
    # Data has 1 byte = 1
    data = struct.pack(">B", advertise_id) + button_data
    # struct.pack(">B", state)

    # Set the name of the device
    name = config.NAME
    
    # Use the OpenMQTTExplorer with workaround
    # The sensor name contains the data in HEX format
    if config.OMG:
        name = data.hex().upper()
            
    # Create the full payload as bytes to be advertised
    payload = advertisepayload(
        # services=[bluetooth.UUID("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")],
        name = name,
        manufacturer_id = config.MANUFACTURER_ID,
        custom_data = data)
    print("[DEBUG]", payload.hex().upper(), len(payload))

    # Advertise the payload with interval (microseconds) and payload as buffer protocol (bytes)
    ble.gap_advertise(config.GAP_ADVERTISE_INTERVAL, adv_data=payload)

# Print version info
print(f'{config.VERSION}')

# Create ble object
ble = bluetooth.BLE()

# Activate BLE = Before using any other method of this class, the radio to be at active state.
try:
    ble.active(True)
    # Increase the MTU if data length > 31
    # ble.config(gap_name='test',mtu=100)
    print(f'MAC Address: {ble.config('mac')[1].hex().upper()}, OMG Mode: {config.OMG}')
except OSError as e:
    print(f'[ERROR] {str(e)}.')
    sys.exit(1)

# if __name__ == "__main__":
while True:
    
    # Handle interrupt detected
    # Trigger: button pressed
    if interrupt_flag is 1:
        print("[DEBUG] Button Interrupt Detected")
        interrupt_flag = 0
        advertise_id = 0 if advertise_id == 1 else 1
        actuator_task(advertise_id)

