"""
File: main.py
Date: 20231230
Author: Robert W.B. Linn
Description:
Start the Pico W as Actuator.
For details see bleactuator.py
"""

import bleactuator
