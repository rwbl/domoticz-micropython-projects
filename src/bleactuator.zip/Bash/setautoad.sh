#!/bin/bash

# File: setautoad.sh
# Date: 20231231
# Author: Robert W.B. Linn
# Description:
# For the PICOACT project, create the Domoticz device type Switch, subtype Switch using MQTT Autodiscovery (MQTTAD).
# The message is published with the retain flag.
# Read more about MQTTAD on Homeassistant.
# Make Executable:
# sudo chmod +x setautoad.sh
# Run from the Domoticz system:
# ./setautoad.sh

# Init
# Pause function waiting for enter key.
function pause(){
   read -p "$*"
}

echo 'Creating Domoticz Switch devices'

# Option: clear the button config retained messages
echo 'Clearing retained messages ...'
mosquitto_sub -h localhost --remove-retained -t 'domoticz/button/picoactk1/config' -W 1
mosquitto_sub -h localhost --remove-retained -t 'domoticz/button/picoactk2/config' -W 1

# Create the Domoticz devices with the goal to create Domoticz push button device.
# Each device is from type Switch, SubType Switch with unique ID KnManufacturerID, i.e. K1FFFE, K2FFFE.
echo 'Creating Domoticz devices ...'

mosquitto_pub -r -h 127.0.0.1 -p 1883 \
-t "domoticz/button/picoactk1/config" \
-m '{"name": "Button K1", "state_topic": "domoticz/button/picoactk1/state", "unique_id": "K1FFFE"}}'
# 2023-12-29 13:18:47.407 Status: OMGGW: discovered: PICOACT/PICOACT (unique_id: K1FFFE)
# 2023-12-29 13:18:47.406 Debug: OMGGW: topic: domoticz/button/picoact/config, message: {"name": "Button K1", "state_topic": "domoticz/button/picoactk1/state", "unique_id": "K1FFFE"} 

mosquitto_pub -r -h 127.0.0.1 -p 1883 \
-t "domoticz/button/picoactk2/config" \
-m '{"name": "Button K2", "state_topic": "domoticz/button/picoactk2/state", "unique_id": "K2FFFE"}}'
# 2023-12-29 13:19:47.407 Status: OMGGW: discovered: PICOACT/PICOACT (unique_id: K2FFFE)
# 2023-12-29 13:18:47.406 Debug: OMGGW: topic: domoticz/button/picoact/config, message: {"name": "Button K2", "state_topic": "domoticz/button/picoactk2/state", "unique_id": "K2FFFE"} 

# ADD MORE like K3, K4

echo 'Devices created. Check the Domoticz log and the devices list'

pause 'Done, press [Enter] to continue...'
exit
