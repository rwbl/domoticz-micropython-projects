# File: booty.py
# Date: 20240208
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# This file is executed on every boot (including wake-boot from deepsleep)
# NOT used - see main.py

# INFO ONLY
# import esp
# esp.osdebug(None)
# import webrepl
# webrepl.start()

# Start BUT better to use main.py.
# STOP using Ctrl-C, Ctrl-A, Ctrl-D, Ctrl-B from the REPL
# import demos.domoticz_little_board
