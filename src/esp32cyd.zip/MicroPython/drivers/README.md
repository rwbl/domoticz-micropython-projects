I do not hold rights overy anthing in this folder. Please contact their authors' for licensing information.
