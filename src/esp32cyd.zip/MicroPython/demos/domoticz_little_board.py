# File: domoticz_little_board.py
# Date: 20240210
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Project Domoticz Little Board (ESP32CYD) to display & control Domoticz selective devices via touch.
# Hardware: Cheap Yellow Display (CYD) OVNSHVN ESP32-2432S028R.
# Firmware: MicroPython v1.22.1 on 2024-01-05; Generic ESP32 module with ESP32.

# Dependencies
# Library CYDR from James Tobin, License: MIT, https://github.com/jtobinart/Micropython_CYDc_ESP32-2432S024C
# MicroPython ILI9341 Display and XPT2046 Touch Screen Drivers, https://github.com/rdagger/micropython-ili9341/
# MicroPython Firmware MicroPython v1.22.1 on 2024-01-05, ESP32_GENERIC-20240105-v1.22.1.bin, https://micropython.org/download/ESP32_GENERIC/

# TODO: FIX Network at boot runtime error: Wifi Unknown Error 0x0101.
#       Status: Reordered module loading. Network & make network connection has to go first!
# TODO: FIX Network [Errno 113] ECONNABORTED when requesting room plan detailed devices info (suspect memory issue, explore using urequests2.py).
#       Status: Improved server get_request function. Since then less 113 errors... but still.
#       Status: Developed Node-RED PreParser for the room plan request to resulting in smaller response (limited device attributes).
#               Running with fewer errors, but still happening every now and then.
#               Suspect also if less power supplied via USB, network issues occur. On Ubuntu device no issues, with Windows device issues.
#
# TODO: UPD Memory usage is a BIG issue. Try to find ways to reduce memory usage. See also next.
# TODO: UPD Review & implement https://docs.micropython.org/en/latest/reference/speed_python.html#maximising-micropython-speed.
# TODO: UPD Simplify concept of set device data.
# TODO: UPD Widgets enhance with property, getter, setter decorator.
# TODO: UPD Improve error handling.
# TODO: UPD Enhance the documentation.
#
# TODO: NEW Widgets Slider, Blinds, InfoBox and other fancy stuff. Ensure to use property, getter, setter decorator.
# TODO: NEW Widget with small images. Thinking about material icon intergration.
# TODO: NEW Device control screen add two buttons to set min/off and max/on as defined in the config device limits.
# TODO: NEW Consider to use double tap to see a log message or make a screenshot (framebuffer to PNG file).
# TODO: NEW Widget LED with traffic light option.
# TODO: NEW LED indicator at top right for WLAN connected (GREEN/RED).
#       Status: Widget LED developed (see folder widgets), but not used yet.
# TODO: NEW SD card for logging.
# TODO: NEW Take screenshots and save to file using double tap.
# TODO: NEW Automatic refresh option for the selected room plan, like every 60s (workaround: touch menu room plan).
# TODO: NEW consider other font (like system, courier new) for the devices screen widget.

# Set the project title (as caption) and the version (as info message)
_VERSION = 'v20240210 - ESP32CYD'
_TITLE = 'Domoticz Little Board'

from micropython import const

# Debug flag to log detailed info
_DEBUG = const(True)

# Garbage collector - is frequently used
import gc

# Network
from web.server import Server

# Network secrets - set SSID, password & IP
import secrets

# Helpers 
def _log_debug(s):
    """
    Print string with debug prefix.
    
    Args:
        s (string): String to log with [DEBUG] prefix.
    """
    if _DEBUG:
        print(f'[DEBUG] {s}')

def garbage_collect():
    """
    Run garbage collection as precaution.
    """
    gc.collect()
    _log_debug(f'[garbage_collect] mem_alloc (heap allocated)={gc.mem_alloc()},mem_free (heap free)={gc.mem_free()}')

# Lets show the script title first
_log_debug(f'{_TITLE}')

###########################################################
# NETWORK
###########################################################

# IMPORTANT
# Connect to the network first - important to avoid esp32 error Wifi Unknown Error 0x0101
network = Server(secrets.WIFI_SSID, secrets.WIFI_PASSWORD, doconnect=True, debug=True)
_log_debug(f'[NETWORK] connected={network.connected}, ip={network.ip}')

# Check memory after network connected like:
# [garbage_collect] mem_alloc (heap allocated)=14640,mem_free (heap free)=139664
garbage_collect()

###########################################################
# IMPORTS
###########################################################

import config
import time

from cydr import CYD
from fonts.xglcd_font import XglcdFont
from drivers.colors import *

# Import the widgets used from folder widgets.
from widgets.label import Label
from widgets.button import Button
from widgets.device import Device
from widgets.devicecontrol import DeviceControl

# Display
# Delay in ms to give the display time to build the screen content.
# Test which value works best.
_SCREEN_BUILD_DELAY = 200

###########################################################
# CONTROLS
###########################################################

# Define the list of controls with id + positions x,y,w,h.
# The id must match the id defined for the control.
controls = []

# Control IDs - DO NOT CHANGE
# Use this if a control is not touchable.
# Is also handled by not adding the control to the controls list.
_NOT_TOUCHABLE_ID = None

# Control IDs for widgets (like buttons) used in the device control screen.
# Do NOT change the numbers. Start with -100.
_BUTTON_DECREASE_ID = const(-100)
_BUTTON_INCREASE_ID = const(-101)
_BUTTON_SET_ID = const(-102)
_BUTTON_ON_ID = const(-103) #NOT IMPLEMENTED
_BUTTON_OFF_ID = const(-104) #NOT IMPLEMENTED
_BUTTON_SLIDER = const(-105) #NOT IMPLEMENTED
# Add next with id -106, -107 etc.

###########################################################
# MENUS
###########################################################
# Id of the menu selected starting with 0.
# The menus are defined in config as a list with json entries.
menu_selected = 0

def _is_menu_item(id):
    """
    Check if the id is a menu id (-1000,-1001...) defined in config.menu_items.
    
    Args:
        id (int): Menu item id
        
    Return:
        found (bool): True is the id is a menu id else false
    """
    for menu in config.menu_items:
        if menu['id'] == id:
            return True
    return False

def _get_menu_item(id):
    """
    Get menu item from its id (-1000,-1001...) defined in config.menu_items.

    Args:
        id (int): Menu item id

    Return:
        menu (Menu): Menu item with properties defined in config.menu_items else None                    
    """
    for menu in config.menu_items:
        if menu['id'] == id:
            return menu
    return None

def _get_roomplan_list():
    """
    Get the room plan idx list from the menu items defined in config.menu_items.

    Return:
        roomplans (list): List of room plan idx
    """
    roomplans = []
    for menu in config.menu_items:
        roomplans.append(menu['idx'])
    return roomplans

###########################################################
# CYD Instance
###########################################################
# Create an instance of CYD (see cydr.py).
# Landscape mode with ESP32CYD power connection right side of the screen.
# x,y = 0,0 = top left (see control_touched).
# DO NOT change the mode and the arguments.
cyd = CYD(rotation=config.DISPLAY_ROTATION,
          width=config.DISPLAY_WIDTH,
          height=config.DISPLAY_HEIGHT)
garbage_collect()

_log_debug(f'w={cyd.display.width}, h={cyd.display.height}')

###########################################################
# FONTS
###########################################################
# Load fonts: path, font width, font height = ensure matches the font definition (see c code).
# BE AWARE that fonts take up high memory.
font_default = XglcdFont('fonts/ArcadePix9x11.c', 9, 11)
_log_debug(f'Loaded font arcadepix9x11, w={font_default.width}, h={font_default.height}')

font_big = XglcdFont('fonts/Unispace12x24.c', 12, 24)
_log_debug(f'Loaded font Unispace12x24, w={font_big.width}, h={font_big.height}')

###########################################################
# MESSAGE LABEL
###########################################################
def _message_label(x, y, text, fgcolor=WHITE):
    """
    Message label with default font. Not touchable.
    
    Args:
        x,y (int): Left prostion of the label.
        text (string): Text to show as one-liner.
        fgcolor (int): Color of the text.
        
    Example:
        _message_label(f'ESP32CYD Demo {_VERSION}')
    """
    Label(cyd.display,
          _NOT_TOUCHABLE_ID,
          x, y,
          text,
          font_default,
          fgcolor)

###########################################################
# BASE SCREEN
###########################################################

def _base_screen(caption):
    """
    Create the base screen used for every page.
    The base screen has a caption at the top and N buttons at the bottom.
    The bottom buttuns are used as menu items for Domoticz room plan.
    If a menu button is touched, the devices screen is shown with up-to
    6 devices for the selected roomplam.

    Args:
        caption (string): screen page caption
    """

    # Clear the screen first
    cyd.display.clear()
    # Clear the controls and give time to complete
    controls.clear()
    time.sleep_ms(_SCREEN_BUILD_DELAY)
    
    # Draw caption at the top of the display, not touchable, label height set by font.height.
    # Truncate caption if not fits display width
    tl = font_big.measure_text(caption)
    tlc = (tl // font_big.width) + 1
    lblcaption = Label(cyd.display, _NOT_TOUCHABLE_ID,
                       0, 0,
                       caption[:tlc],
                       font_big,
                       fgcolor=WHITE)
    cyd.display.draw_hline(0, font_big.height + 2, cyd.display.width, BLUE)

    # Room plan menu buttons at bottom of the screen
    # Button Control with id,x,y,w,h
    # Define the width of a menu_item (=button) depending number of menu_items
    w = cyd.display.width // len(config.menu_items)
    h = 0
    index = 0
    # print(config.menuitems)
    _log_debug(f'[base_screen] display_width={cyd.display.width}, menu_width={w}, menu_items={len(config.menu_items)}')
    
    for menu in config.menu_items:
        menu['x'] = w * index
        menu['y'] = cyd.display.height - font_big.height - 4
        menu['w'] = w
        menu['h'] = 0
        menu_control = Button(cyd.display,
                              menu['id'],
                              menu['x'], menu['y'], menu['w'], menu['h'],
                              menu['text'], font_big,
                              bgcolor=menu['bgcolor'], fgcolor=menu['fgcolor'], bdcolor=None, justify=CENTER)
        controls.append(menu_control)
        index = index + 1
    
    # Give screen time to complete build
    time.sleep_ms(_SCREEN_BUILD_DELAY)
    garbage_collect()

def _menu_items_update(update):
    """
    Update the menu items with the room plan data from Domoticz.
    Redraws the base screen with the updated text of the menu items.
    
    Args:
        update (bool): Update the menu items text & idx from the Domoticz room plans
                        idx defined in config.ROOMPLANS.
                        if false, the defaults are used.
    """    
    # Get the domoticz room plans from http api request
    if update:
        _log_debug(f'set_menu_items {secrets.DOMOTICZ_IP} {_get_roomplan_list()}')
        
        # Get all the room plans defined in Domoticz
        status, roomplans = network.get_plans(secrets.DOMOTICZ_IP)

        # Status ok , lets build the menu items
        if status == 1:
            # Get the key result
            # {"result": [{"Devices": 6,"Name": "Google Calendars","Order": "2","idx": "2"},{}],"status": "OK","title": "Plans"}
            menuroomplans = _get_roomplan_list()
            if menuroomplans is not None:
                # Loop over the config.ROOMPLANS to keep the order
                menuid = 0
                for plan in menuroomplans:
                    for roomplan in roomplans:
                        if int(roomplan['idx']) == plan:
                            # print(int(roomplan['idx']), plan)
                            config.menu_items[menuid]['text'] = roomplan['Name']
                            config.menu_items[menuid]['idx'] = roomplan['idx']
                    menuid = menuid + 1
            # Re-draw the base_screen
            _base_screen(_TITLE)

###########################################################
# DEVICES SCREEN
###########################################################

def _devices_screen(item):
    """
    Add the room plan devices to the base screen.
    The max number of devices is set in config._MAX_ROOMPLAN_DEVICES (default 6).
    If there are memory issues, reduce the number of devices.
    The devices screen builds device widgets with selective device attributes.
    This is done to save memory.
    The device Data attribute is not used to change the device value, but a new attribute datavalue.
    The attribute datavalue contains numeric data for devices like setpoint, dimmer.
    
    Args:
        item (menu_item): Selected menu_item with room plan idx (see config)
    """
    idx = item['idx']

    # Re-draw the base_screen - MUST BE DONE FIRST to rebuild list of controls
    _base_screen(item['text'])
    _message_label(0, 100, f'Please wait, getting room plan devices...')

    # Request the room plan devices with details
    # This takes up memory - reduce number of devices in case error
    status, plandevices = network.get_plan_devices(secrets.DOMOTICZ_IP, idx, config.NODERED_PREPARSER)
    
    # Status ok , lets build the device widgets
    # Set device['LastUpdate'] to None to hide
    if status == 1:
        _log_debug(f'[devices_screen get_plan_devices] OK, room plan idx={idx}, plandevices={len(plandevices)}')

        _base_screen(item['text'])
        # print(plandevices, len(plandevices))
        index = 0
        w = 110
        h = 80
        x = 0
        y = 40
        devcnt = 0
        for plandevice in plandevices:
            # Increase the device counter and check against max prior adding to the screen
            devcnt = devcnt + 1
            if devcnt > config.MAX_PLAN_DEVICES:
                print(f'[WARNING devices_screen] Reached max {config.MAX_PLAN_DEVICES} devices.')
                return
            
            # Set the x-pos of the device widget
            x = index * w

            # Create a new smaller device object with less attributes
            newdevice = {}
            newdevice['name'] = plandevice['Name'] 
            newdevice['idx'] = int(plandevice['idx'])

            # Check if the lastupdate attribute should be displayed
            if not config.SHOW_LAST_UPDATE:
                newdevice['lastupdate'] = None
            else:
                newdevice['lastupdate'] = plandevice['LastUpdate'] 

            # Subtype used to select the device screen to change the device value/state
            newdevice['subtype'] = plandevice['SubType']
            # Handle special subtype cases like switch
            # Set SwitchType (Dimmer, On/Off) as SubType
            if plandevice['SubType'] == config.SWITCH_DEV:
                newdevice['subtype'] = plandevice['SwitchType']

            # Set if the device is controlable based on the subtype (see config)
            newdevice['cancontrol'] = False
            if newdevice['subtype'] in config.CONTROLABLE_DEVICES:
                newdevice['cancontrol'] = True

            # Data, as a string, assigment with some small cosmetic changes
            newdevice['data'] = plandevice['Data'].replace(' %', '%')

            # Assign the data to the datavalue to enable chaning the value on the device control screen
            # The datavalue should be a numeric
            # Dimmer
            newdevice['datavalue'] = plandevice['Data']
            if newdevice['subtype'] == config.DIMMER_DEV:
                # Int = no conversion
                newdevice['datavalue'] = plandevice[config.DIMMER_ATTR]
            # Setpoint
            if newdevice['subtype'] == config.SETPOINT_DEV:
                # Str = convert to float
                newdevice['datavalue'] = float(plandevice[config.SETPOINT_ATTR])

            # Create the device widget
            device = Device(cyd.display,
                            newdevice['idx'],
                            x, y,
                            newdevice,
                            font_default,
                            fgcolor=config.DEVICE_FGCOLOR,
                            bgcolor=config.DEVICE_BGCOLOR,
                            bdcolor=config.DEVICE_BDCOLOR,
                            linecolor=config.DEVICE_BDCOLOR)

            # Append the device widget to the touch controls
            controls.append(device)

            # Index used to show max 3 device widgets per row
            index = index + 1
            if index > 2:
                index = 0
                x = 0
                y = y + h + 4
    
    # Status error: rebuild the screen with error message.
    else:
        # Log error
        _log_debug(f'[ERROR devices_screen get_plan_devices] Network connected: {network.connected}, ip={network.ip}')
        garbage_collect()

        # Rebuild the base screen
        _base_screen(item['text'])

        # Show error message in 3 labels
        _message_label(0, 100, f'[ERROR] Can not get room plan devices.', fgcolor=RED)
        _message_label(0, 120, f'Try again (Tap on selected room plan menu).', fgcolor=WHITE)
        _message_label(0, 140, f'Network connected: {network.connected}')

    # Give screen time to complete build
    time.sleep_ms(_SCREEN_BUILD_DELAY)

###########################################################
# DEVICE CONTROL SCREEN
###########################################################

def _device_control_screen(device):
    """
    Show the device control screen.
    
    Args:
        device (Device): Device selective attributes.
    """

    _log_debug(f'[device_control_screen]: device name={device.name},idx={device.idx},cancontrol={device.cancontrol},data={device.data},datavalue={device.datavalue}')

    # Do nothing if the device is not controlable
    if not device.cancontrol:
        return

    # Re-draw the base_screen - MUST BE DONE FIRST to rebuild list of controls
    _base_screen(_get_menu_item(menu_selected)['text'] + ' ' + device.name)

    # Device Control control ids btn_decrease, btn_increase,lbl_data
    dc = DeviceControl(cyd.display,
                       _BUTTON_DECREASE_ID,
                       _BUTTON_INCREASE_ID,
                       _BUTTON_SET_ID,
                       device,
                       config.PRESENT_VALUE_PREFIX,
                       font_big)
    
    # Add the controls used in the device control screen
    # These are required to handle control touched
    for devcontrol in dc.controls:
        controls.append(devcontrol)

    # Give screen time to complete build
    time.sleep_ms(_SCREEN_BUILD_DELAY)
    garbage_collect()
    
def _get_device_item(id):
    """
    Get device item from its control id = device idx > 0.
    
    Args:
        id (int): Control id depending which kind of Device.
        
    Return:
        Device
    """
    for control in controls:
        # Check if the control is from class Device
        if isinstance(control, Device):
            # print(isinstance(c, Device), c)
            if control.idx == id:
                _log_debug(f'get_device_item: found {control.name}, {control.idx}')
                return control
    return None

def _set_device_data(device, btn):
    """
    Set new device data depending subtype and button pressed.
    Supported devices are:
        On/Off: decrease Off, increase On
        SetPoint: decrease float - step, increase float + step, limits check
        Dimmer: decrease int - step, increase float + step, limits check
        
    The button control id is used to determine the action to take.
    If f.e. the button decrease is touched, the device value is decreased and the
    device control screen is rebuild with the new value.


    Args:
        device (Device): Device attributes
        btn (Button): Button control
    """
    
    def _set_new_value(devicevalue, direction, step, limits):
        """
        Set new device value.
        Args:
            devicevalue (int): Current device value to change
            direction (int): Decrease (-1) or increase (1) the value
            step (int or float): Step to de-/increase the device value
            limits (int or float): Min and max device value. See config.
        """
        if direction < 0: step = step * -1
        devicevalue = devicevalue + step
        # Check limits [0]=min, [1]=max. 
        if devicevalue < limits[0]: devicevalue = limits[0]
        if devicevalue > limits[1]: devicevalue = limits[1]
        return devicevalue

    def _dev_onoff(btn):
        """Switch/On/Off"""
        if btn == _BUTTON_DECREASE_ID:
            device.datavalue = 'Off'
        elif btn == _BUTTON_INCREASE_ID:
            device.datavalue = 'On'
        elif btn == _BUTTON_SET_ID:
            _log_debug(f'[set_device_data dev_onoff]{btn}, data={device.data}, datavalue={device.datavalue}')
            
            # Convert to string On or Off in case datavalue is 1 or 0.
            if isinstance(device.datavalue, int):
                device.datavalue = 'On' if device.datavalue == 1 else 'Off'
                
            # ip, param, idx, args
            status = network.set_new_value(
                secrets.DOMOTICZ_IP,
                config.SWITCH_PARAM,
                device.idx,
                f'switchcmd={device.datavalue}')
            _log_debug(f'[set_device_data dev_onoff]{status}')
            
            # Give screen time to complete build
            time.sleep_ms(_SCREEN_BUILD_DELAY)
    
    def _dev_dimmer(btn):
        """Switch/Dimmer"""
        if btn == _BUTTON_DECREASE_ID:
            # device.data = device.datavalue - config.DIMMER_STEP
            device.datavalue = _set_new_value(device.datavalue, -1, config.DIMMER_STEP, config.DIMMER_LIMITS)
        elif btn == _BUTTON_INCREASE_ID:
            # device.data = device.datavalue + config.DIMMER_STEP
            device.datavalue = _set_new_value(device.datavalue, 1, config.DIMMER_STEP, config.DIMMER_LIMITS)
        elif btn == _BUTTON_SET_ID:
            _log_debug(f'[set_device_data]{btn}, data={device.data}, datavalue={device.datavalue}')
            # /json.htm?type=command&param=switchlight&idx=99&switchcmd=Set%20Level&level=6
            
            # ip, param, idx, args
            status = network.set_new_value(
                secrets.DOMOTICZ_IP,
                config.SWITCH_PARAM,
                device.idx,
                f'switchcmd=Set%20Level&level={device.datavalue}')
            _log_debug(f'[set_device_data dev_dimmer]{status}')
            
            # Give screen time to complete build
            time.sleep_ms(_SCREEN_BUILD_DELAY)
    
    def _dev_setpoint(btn):
        """Setpoint/SetPoint"""
        if btn == _BUTTON_DECREASE_ID:
            # device.datavalue = device.datavalue - config.SETPOINT_STEP
            device.datavalue = _set_new_value(device.datavalue, -1, config.SETPOINT_STEP, config.SETPOINT_LIMITS)
        elif btn == _BUTTON_INCREASE_ID:
            # device.datavalue = device.datavalue + config.SETPOINT_STEP
            device.datavalue = _set_new_value(device.datavalue, 1, config.SETPOINT_STEP, config.SETPOINT_LIMITS)
        elif btn == _BUTTON_SET_ID:
            _log_debug(f'[set_device_data]{btn}, data={device.data}, datavalue={device.datavalue}')
            
            # ip, param, idx, args
            status = network.set_new_value(
                secrets.DOMOTICZ_IP,
                config.SETPOINT_PARAM,
                device.idx,
                f'setpoint={device.datavalue}')
            _log_debug(f'[set_device_data dev_setpoint]{status}')
            
            # Give screen time to complete build
            time.sleep_ms(_SCREEN_BUILD_DELAY)

    # Add mor devices
    #def _dev_DEVICE_SUBTYPE(btn):
    
    # Select device by subtype
    _log_debug(f'[set_device_data] name={device.name}, subtype={device.subtype}, btn={btn}')
    if device.subtype == config.ONOFF_DEV: _dev_onoff(btn)
    if device.subtype == config.SETPOINT_DEV: _dev_setpoint(btn)
    if device.subtype == config.DIMMER_DEV: _dev_dimmer(btn)
    # Add more device subtypes
    # if device.subtype == config.DEVICE_SUBTYPE_DEV: _dev_DEVICE_SUBTYPE(btn)

    # Return update device data if changed by button
    return device

###########################################################
# CONTROL TOUCHED on a screen
###########################################################

def control_touched(x,y):
    """
    Check which control from the controls list is touched and
    return the control id.
    
    Args:
        x,y (int): Screen x,y pos touched.
        
    Return:
        control (int): ID of the control touched
    """
    # _log_debug(f'[control_touched] touch pos x={x}, y={y}')
    
    # Revert x to set 0 at the left
    x = cyd.display.width - x
    # Revert y to set 0 at the top
    y = cyd.display.height - y
    
    # Loop over the control to find which is touched
    # Requires that each control has properties x,y,w,h
    for control in controls:
        _log_debug(f'[control_touched] id={control.id}, x={control.x}, y={control.y}, w={control.w}, h={control.h}')
        id = control.id
        x1 = control.x
        y1 = control.y
        x2 = x1 + control.w
        y2 = y1 + control.h
        # _log_debug(f'control_touched: control pos={x1},{y1},{x2},{y2}')
        if x >= x1 and x <= x2 and y >= y1 and y <= y2:
            _log_debug(f'control_touched={id}')
            return id
    _log_debug(f'[control_touched] NONE')

def _draw_touch_indicator(x,y,r=4):
    """
    Draw a small touch indicator which is a coloured circle.
    
    Args:
        x,y (int): top position of the circle.
        r (int): Radius touch circle indicator
    """

    # Prevent circles from appearing off-screen.
    y = min(max(((cyd.display.height - 1) - y), (r+1)),(cyd.display.height-(r+1)))
    x = min(max(((cyd.display.width - 1) - x), (r+1)),(cyd.display.width-(r+1)))

    # Draw a filled circle
    cyd.display.fill_circle(x, y, r, config.TOUCH_INDICATOR_COLOR)

###########################################################
# CYD Helpers
###########################################################

def _cyd_reset():
    """
    Reset the device in case of an error.
    NOT USED but considering for double_tap (see main while loop).
    """
    cyd.display.clear()
    _message_label(0, cyd.height // 2, f'Device reset started...')
    time.sleep(2)
    cyd.display.cleanup()
    import machine
    machine.reset()

###########################################################
# MAIN
###########################################################

# Draw the base_screen
_base_screen(_TITLE)

# Show the version
_message_label(0, 30, f'{_VERSION}')

# Check if network connected
if not network.connected:
    _message_label(0, 100, f'[ERROR] Network connection failed.', fgcolor=RED)
    _message_label(0, 120, f'Reset the device to try again.')

# Update the menu items with the room plans if argument set to true.
if network.connected and config.UPDATE_MENUS:
    _menu_items_update(False)

# Infinite loop
while True:
    time.sleep(0.05)
    
    # Get touch position
    x, y = cyd.touches()
    
    # Check that there are new touch points (Default values are x = 0, y = 0)
    if x == 0 and y == 0:
        continue
    
    # Double tap to reset _cyd_reset() or exit using break which results in a shutdown.
    if cyd.double_tap(x,y):
        pass

    _log_debug(f'Touches: x={x}, y={y} (w={cyd.display.width}, h={cyd.display.height})')

    if config.TOUCH_INDICATOR:
        _draw_touch_indicator(x,y)
        
    # Check which control is touched
    control_id = control_touched(x,y)
    
    # Handle touch id    
    if control_id is not None:

        # Menu item touched
        if _is_menu_item(control_id):
            menu_selected = control_id
            item = _get_menu_item(control_id)
            _log_debug(f'[MENU touched]: {item}')
            _devices_screen(item)        

        # Device item touched (from the devices_screen).
        # The device control screen is build for a Domoticz device.
        # The device value can be changed on the device control screen.
        # The device control screen is a generic screen, but a dedicated
        # device screen, depending device type could be used as an option.
        # Like if device.subtype is dimmer, then use something like device slider screen.
        elif control_id > 0:
            device = _get_device_item(control_id)
            _log_debug(f'[DEVICE touched]: device {device.name}, {device.idx}, {device.subtype}')
            _device_control_screen(device)        

        # Device control touched (device_control_screen).
        # Buttons to change the device value but NOT update Domoticz.
        # The device control screen is shown again with the updated value.
        elif control_id in [_BUTTON_DECREASE_ID, _BUTTON_INCREASE_ID]:
            # print('device_control_screen button', control_id)
            device = _set_device_data(device, control_id)
            _log_debug(f'[BUTTON IN/DECREASE touched] data={device.data}, datavalue={device.datavalue}')
            _device_control_screen(device)

        # Device control touched (device_control_screen).
        # Button SET to update Domoticz with the new device value.
        # Afterwards the devices screen for the selected room plan device is shown.
        elif control_id == _BUTTON_SET_ID:
            # print('device_control_screen button', control_id)
            _set_device_data(device, control_id)
            _log_debug(f'[BUTTON SET_ID touched] data={device.data}, datavalue={device.datavalue}')
            _devices_screen(_get_menu_item(menu_selected))
            
        # Add more control_id's like _BUTTON_ON_ID
        
        # Idea: For _BUTTON_ON_ID change the data and update Domoticz immediate
        # The device limits with 0=Off, 1=On could be used, like
        # if device.subtype == config.ONOFF_DEV:
        #  device.datavalue = config.ONOFF_LIMITS[1]
        #  _set_device_data(device, _BUTTON_SET_ID)
        #  _devices_screen(_get_menu_item(menu_selected))

# Shutdown initiated by f.e. double tap
cyd.shutdown()

