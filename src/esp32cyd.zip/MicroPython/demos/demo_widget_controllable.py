# File: demo_widget_controllable.py
# Date: 20240211
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Widget LED indicator with a centered one character label.
# Example of making the widget ćontrollable = touchable.
# This can apply to every widget. Important to convert the widget coordinates to a rectangle.

# NOTE:
# Each controllable widget class must have properties used for touch position and object:
# self.id = id, self._x = x, self.y = y, self.w = w, self.h = h

# Import from the drivers the color and additional constants
from drivers.colors import *
from fonts.xglcd_font import XglcdFont
import time

class LEDLABEL(object):
    """
    LED indicator with a centered one character label.

    Args:
        display (Display): Display instance.
        id (int): Unique id of the widget.
        x (int): Center x position of the circle.
        y (int): Center y position of the circle.
        text (string): Single character displayed in LED centered.
        font (XglcdFont object): Font
        radius (int): Radius of the circle (default: 20).
        fgcolor (int): RGB565 text color (default: white).
        bdwidth (int): Width of the border (default: 2).
        bgcolor (int): RGB565 background color (default: black).
        bdcolor (int): RGB565 border color (default: None = no border)
    """

    def __init__(self,
                 display,
                 id,
                 x, y,
                 text,
                 font,
                 radius=20,
                 fgcolor=WHITE,
                 bgcolor=BLACK,
                 bdwidth=2,
                 bdcolor=None):
        
        # Set the properties
        self._display = display
        self.id = id

        # Keep the widget center pos
        self._x = x
        self._y = y
        self._radius = radius

        # Set the controllable range of the object as rectangle with top left pos
        # x,y=Top left, w+h=Radius*2
        self.x = x - radius
        self.y = y - radius
        self.w = radius * 2
        self.h = radius * 2
        print(x,self.x,y,self.y,radius,radius*2)

        # keep the arguments used for the function show abd the properties
        self._text = text[:1]
        self._font = font
        self._fgcolor = fgcolor
        self._bgcolor = bgcolor
        self._bdwidth = bdwidth
        self._bdcolor = bdcolor
        # Show the widget        
        self.show()
        
    def show(self):
        """Show the widget"""

        # Get the text properties
        fw = self._font.width
        fh = self._font.height
        tl = len(self._text) * fw
        tx = self._x - (tl // 2)
        ty = self._y - (fh // 2)
        
        # If the radius is -1, use the font height * 0.9 as radius
        if self._radius < 0:
            self._radius = int(fh * 0.7) 

        # Draw the border
        if self._bdcolor is not None:
            # Draw the outer circle
            cyd.display.fill_circle(self._x, self._y, self._radius, self._bdcolor)
            # Reduce the radius used for the inner circle
            self._radius = self._radius - self._bdwidth
                    
        # Draw a filled circle
        cyd.display.fill_circle(self._x, self._y, self._radius, self._bgcolor)

        # Draw the text
        self._display.draw_text(tx, ty,
                                self._text, self._font,
                                self._fgcolor,
                                background=self._bgcolor)


    def clear_widget(self):
        # Draw a filled circle in black
        cyd.display.fill_circle(self._x, self._y, self._radius, BLACK)


    @property
    def bgcolor(self):
        """Get background color"""
        return self._bgcolor
        
    @bgcolor.setter
    def bgcolor(self, value):
        """Set new background color"""
        clear_widget()
        self._bgcolor = value
        self.show()

###########################################################
# CONTROL HANDLING = widget touched
###########################################################

###########################################################
# CONTROL TOUCHED on a screen
###########################################################
def control_touched(x,y):
    """
    Check which control from the controls list is touched and
    return the control id.
    
    Args:
        x,y (int): Screen x,y pos touched.
        
    Return:
        control (int): ID of the control touched
    """
    # Revert x to set 0 at the left
    x = cyd.display.width - x
    # Revert y to set 0 at the top
    y = cyd.display.height - y
    print(f'[control_touched] POS x={x}, y={y}')
    
    # Loop over the control to find which is touched
    # Requires that each control has properties x,y,w,h
    for control in controls:
        print(f'[control_touched] >>> id={control.id}, x={control.x}, y={control.y}, w={control.w}, h={control.h}')
        id = control.id
        x1 = control.x
        y1 = control.y
        x2 = x1 + control.w
        y2 = y1 + control.h
        print(f'[control_touched] >>> id pos=x1={x1}, y1={y1}, x2={x2}, y2={y2}')
        if (x >= x1 and x <= x2) and (y >= y1 and y <= y2):
            print(f'[control_touched] FOUND control id={id}')
            return id
        print(f'[control_touched] control id=NONE')

def _draw_touch_indicator(x,y,r=4,c=RED):
    """
    Draw a small touch indicator which is a coloured circle.
    
    Args:
        x,y (int): top position of the circle.
        r (int): Radius touch circle indicator
    """

    # Prevent circles from appearing off-screen.
    _r = r
    _y = min(max(((cyd.display.height - 1) - y), (r+1)),(cyd.display.height-(r+1)))
    _x = min(max(((cyd.display.width - 1) - x), (r+1)),(cyd.display.width-(r+1)))

    # Draw a filled circle
    cyd.display.fill_circle(_x, _y, _r, c)

###########################################################
# MAIN
###########################################################
# For tests set _DEMO to true
_DEMO = True
if _DEMO:
    print(f'demo_widget')
    from time import sleep
    from cydr import CYD

    # CYD Instance
    cyd = CYD(rotation=270, width=340, height=240)

    # Font
    # Load fonts: path, font width, font height = ensure matches the font definition (see c code).
    font_big = XglcdFont('fonts/Unispace12x24.c', 12, 24)

    # Declare the controls array
    controls =[]

    # Draw LEDs and append to the controls list
    ledlabel1 = LEDLABEL(cyd.display,
                         123,
                         20,
                         20,
                         'R',
                         font_big,
                         radius=20,
                         fgcolor=WHITE, bgcolor=BLUE)
    controls.append(ledlabel1)

    ledlabel2 = LEDLABEL(cyd.display,987,
                         cyd.display.width - 40 - 1,
                         cyd.display.height - 20 - 1,
                         'L', font_big,
                         radius=20, fgcolor=WHITE, bgcolor=BLUE)
    controls.append(ledlabel2)

    # Infinite loop to check control touched
    while True:
        time.sleep(0.05)
        
        # Get touch position
        x, y = cyd.touches()
        
        # Check that there are new touch points (Default values are x = 0, y = 0)
        if x == 0 and y == 0:
            continue
        
        # Double tap to exit using break which results in a shutdown
        if cyd.double_tap(x,y):
            break

        _draw_touch_indicator(x,y,c=RED)
            
        # Check which control is touched
        control_id = control_touched(x,y)
        
        # Handle touch id    
        if control_id is not None:
            print('Found control with id=', control_id)

# Shutdown initiated by f.e. double tap
cyd.shutdown()
