# File: demo_widget_controllable
# Date: 20240210
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Demo for developing a widget.
# This example widget LED is a controllable widget.

# Controllable Widget
# Each controllable widget class must have properties used for touch position and object:
# self.id = id, self.x = x, self.y = y, self.w = w, self.h = h

# Import from the drivers the color and additional constants
from drivers.colors import *

class LED(object):
    """
    LED indicator which is a coloured indicator.
    Not controllable.

    Args:
        display (Display): Display instance.
        id (int): Unique id of the widget.
        x (int): Top left x position of the rect.
        y (int): Top left y position of the rect.
        w (int): Width of the rect.
        h (int): Width of the rect.
        bdwidth (int): Width of the border (default: 2).
        bgcolor (int): RGB565 background color (default: black).
        bdcolor (int): RGB565 border color (default: None = no border)
    """

    def __init__(self,
                 display,
                 id,
                 x, y,
                 w, h,
                 bgcolor=BLACK,
                 bdwidth=2,
                 bdcolor=None):
        
        # Set the properties
        self._display = display
        self.id = id
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.bgcolor = bgcolor
        self.bdwidth = bdwidth
        self.bdcolor = bdcolor
        # Show the widget        
        self.show()
        
    def show(self):
        """Show the widget"""
        
        # Draw the rectangle
        if self.bdcolor is not None:
            self._display.fill_rectangle(self.x, self.y, self.w, self.h, self.bdcolor)
            time.sleep_ms(20)
            self._display.fill_rectangle(self.x+2, self.y+2, self.w-4, self.h-4, self.bgcolor)
            self.x = self.x+2
            self.y = self.y+2
            self.w = self.w-4
            self.h = self.h-4
        else:
            self._display.fill_rectangle(self.x, self.y, self.w, self.h, self.bgcolor)

    def bgcolor(self, value):
        """Set new background color"""
        self.bgcolor = value
        self.show()
#
# Main
# For tests set _DEMO to true
_DEMO = True
if _DEMO:
    print(f'demo_widget')
    from time import sleep
    from cydr import CYD
    cyd = CYD(rotation=270, width=340, height=240)

    # Draw big LED - display, id, x, y, r, bgcolor, bdcolor
    led = LED(cyd.display, -1, 50, 50, 50, bgcolor=RED)

    # Draw LED with default radius and a border
    led = LED(cyd.display, -1, 50, 150, 20, bdwidth=2, bgcolor=YELLOW, bdcolor=BLUE)

    sleep(10)
    
    # Shutdown
    cyd.shutdown()

