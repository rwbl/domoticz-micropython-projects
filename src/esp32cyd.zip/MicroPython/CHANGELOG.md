# domoticz-micropython-projects - CHANGELOG ESP32CYD

## 20240213
* UPD: Project ESP32CYD - Improved network connectivity, widgets reworked with demo mode option.
* UPD: Project ESP32CYD - Touch handling sensitivity.
* NEW: Project ESP32CYD - Folder demos demo_domoticz, demo_widget_non_controllable, demo_widget_controllable, demo_widget_progressbar.
* NEW: Project ESP32CYD - Widgets ledlabel, progressbar.

## 20240210
* NEW: Project ESP32CYD - ESP32 Cheap Yellow Display 320x240 resolution first prototype.
  