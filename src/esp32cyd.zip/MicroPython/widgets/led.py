# File: led
# Date: 20240210
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# LED widget which is a coloured circle with optional border.
# This widget is not touchable. Set id to None.

# If a widget is touchable, then the widget class must have
# properties used for touch position and object:
# self.id = id, self.x = x, self.y = y, self.w = w, self.h = h

# Import from the drivers the color and additional constants
from drivers.colors import *

class LED(object):
    """
    LED widget which is a coloured circle with optional border.

    Args:
        display (Display): Display instance.
        id (int): Unique id of the widget.
        x (int): Center x position of the circle.
        y (int): Center y position of the circle.
        radius (int): Radius of the circle (default: 20).
        bgcolor (int): RGB565 background color (default: black).
        bdcolor (int): RGB565 border color (default: None = no border)
        bdwidth (int): Width of the border (default: 2).
    """

    def __init__(self,
                 display,
                 id,
                 x, y,
                 radius,
                 bgcolor=BLACK,
                 bdcolor=None,
                 bdwidth=2):
        
        # Set the properties
        self._display = display
        if id is not None:
            self.id = id
        self.x = x
        self.y = y
        self._radius = radius
        self._bgcolor = bgcolor
        self._bdcolor = bdcolor
        self._bdwidth = bdwidth
        # Show the widget
        self.show()
    
    def show(self):
        """Show the widget"""
        
        # Draw the border
        if self._bdcolor is not None:
            # Draw the outer circle
            cyd.display.fill_circle(self.x, self.y, self._radius, self._bdcolor)
            # Reduce the radius used for the inner circle
            self._radius = self._radius - self._bdwidth
                    
        # Draw a filled circle
        cyd.display.fill_circle(self.x, self.y, self._radius, self._bgcolor)

    @property
    def radius(self):
        return self._radius

    @radius.setter
    def radius(self, value):
        """Set new radius"""
        self._radius = value
        self.show()

    @property
    def bgcolor(self):
        return self._bgcolor

    @bgcolor.setter
    def bgcolor(self, value):
        """Set new background color"""
        self._bgcolor = value
        self.show()

    @property
    def bdcolor(self):
        return self._bdcolor

    @bdcolor.setter
    def bdcolor(self, value):
        """Set new border color"""
        self._bdcolor = value
        self.show()

    @property
    def bdwidth(self):
        return self._bdwidth

    @bdwidth.setter
    def bdwidth(self, value):
        """Set new border width"""
        if value < 0 or value > self._radius: value = 0
        self._bdwidth = value
        self.show()

###########################################################
# Main
###########################################################
# Set to true to run as demo / test
_DEMO = False
if _DEMO:
    print(f'demo_widget')
    from time import sleep
    from cydr import CYD
    
    # Create CYD instance
    cyd = CYD(rotation=270, width=340, height=240)

    # Draw big LED - display, id, x, y, r, bgcolor, bdcolor
    led = LED(cyd.display, -1, 50, 50, 50, bgcolor=RED, bdcolor=YELLOW, bdwidth=5)
    sleep(2)
    cyd.display.clear()

    led.radius = 40
    led.bdwidth = 2
    sleep(2)
    cyd.display.clear()

    led.bgcolor = WHITE
    sleep(2)
    cyd.display.clear()
    
    led.bdcolor = RED
    sleep(2)
    cyd.display.clear()

    # Shutdown
    cyd.shutdown()

