# File: devicecontrol.py
# Date: 20240203
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Device control widget to set the value of a Domoticz device.
# The display width and height are used to draw:
# [Button +][LabelValue][Button -]
# [Button Off][Button SET][Button On]
# Each of the controls must have an unique id used for the touch control

# Notes
# Each widget class must have properties used for touch position and object:
# self.id = id,self.x = x,self.y = y,self.w = w,self.h = h
# draw_text property rotate is not used.

# Import from the drivers the color and additional constants
from drivers.colors import *
import time

# Import the widgets used
from widgets.label import Label
from widgets.rectlabel import RectLabel
from widgets.button import Button

class DeviceControl(object):
    """Device Control widget
    Change the value of a device.


    Args:
        display (Display): Display instance.
        ids (list): Unique ids of the controls:
                    btn_increase,lbl_value, btn_decrease
                    [-100,-101,-102]
        device (tupel): Device attributes.
        font (XglcdFont object): Font
    """

    def __init__(self,
                 display,
                 btn_decrease_id,
                 btn_increase_id,
                 btn_set_id,
                 device,
                 present_value_prefix,
                 font):
        
        # Set the properties
        self._display = display
        self._btn_decrease_id = btn_decrease_id
        self._btn_increase_id = btn_increase_id
        self._btn_set_id = btn_set_id
        self._device = device
        self._font = font
        self._present_value_prefix = present_value_prefix
        self.controls = []
        #
        self.show()

    def show(self):
        """
        Show the controls.
        """
        
        print(f'[devicecontrol]data={self._device.data}, datavalue={self._device.datavalue}')
        
        # Fixed x,y pos for the controls
        # w=320, h=240 - 30 (for the caption) - 30 (for the menu items)
        w = self._display.width
        h = self._display.height - 60
        
        # Default button w & h
        btn_width = 70
        btn_height = 30

        # Label with value converted to string
        # Get text length in pixel
        tl = self._font.measure_text(str(self._device.datavalue))
        x = (w // 2) - (tl // 2)
        y = 50
        self.label_value = Label(self._display,
                                 -999,
                                 x, y,
                                 str(self._device.datavalue), self._font,
                                 fgcolor=WHITE)

        # Buttons Decrease (RED), Increase (GREEN), Set (BLUE)
        offset = 30

        x = offset
        y = h // 2
        btn_decrease = Button(self._display,
                              self._btn_decrease_id,
                              x, y, btn_width, btn_height,
                              '-', self._font,
                              bgcolor=RED, fgcolor=WHITE, bdcolor=None, justify=CENTER)
        self.controls.append(btn_decrease)

        x = w - btn_width - offset
        y = y
        btn_increase = Button(self._display,
                              self._btn_increase_id,
                              x, y, btn_width, btn_height,
                              '+', self._font,
                              bgcolor=GREEN, fgcolor=WHITE, bdcolor=None, justify=CENTER)
        self.controls.append(btn_increase)

        x = (w // 2) - (btn_width // 2)
        y = y + offset
        btn_set = Button(self._display,
                         self._btn_set_id,
                         x, y, btn_width, btn_height,
                         'SET', self._font,
                         bgcolor=BLUE, fgcolor=WHITE, bdcolor=None, justify=CENTER)
        self.controls.append(btn_set)

        # Show the device Data attribute (always a string)
        if self._present_value_prefix is not None:
            tl = self._font.measure_text(str(self._device.data))
            x = 10 # (w // 2) - (tl // 2)
            y = y + (btn_height * 2)
            self.label_value = Label(self._display,
                                     -999,
                                     x, y,
                                     f'{self._present_value_prefix}{self._device.data}', self._font,
                                     fgcolor=WHITE)

    def value(self, text):
        """Show the new text"""
        self.label_value = text
        self.show()
    