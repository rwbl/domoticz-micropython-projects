# File: ledlabel.py
# Date: 20240211
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Widget LED indicator with a centered one character label.
# Class LEDLabel
# Example of making the widget controllable = touchable.
# This can apply to every widget. Important to convert the widget coordinates to a rectangle.

# NOTE:
# Each controllable widget class must have properties used for touch position and object:
# self.id = id, self._x = x, self.y = y, self.w = w, self.h = h

# Import from the drivers the color and additional constants
from drivers.colors import *

class LEDLabel(object):
    """
    LED indicator with a centered one character label.

    Args:
        display (Display): Display instance.
        id (int): Unique id of the widget.
        x (int): Center x position of the circle.
        y (int): Center y position of the circle.
        text (string): Single character displayed in LED centered.
        font (XglcdFont object): Font
        radius (int): Radius of the circle (default: 20).
        fgcolor (int): RGB565 text color (default: white).
        bdwidth (int): Width of the border (default: 2).
        bgcolor (int): RGB565 background color (default: black).
        bdcolor (int): RGB565 border color (default: None = no border)
    """

    def __init__(self,
                 display,
                 id,
                 x, y,
                 text,
                 font,
                 radius=20,
                 fgcolor=WHITE,
                 bgcolor=BLACK,
                 bdwidth=2,
                 bdcolor=None):
        
        # Set the properties
        self._display = display
        self.id = id

        # Keep the widget center pos
        self._x = x
        self._y = y
        self._radius = radius

        # Set the controllable range of the object as rectangle with top left pos
        # x,y=Top left, w+h=Radius*2
        self.x = x - radius
        self.y = y - radius
        self.w = radius * 2
        self.h = radius * 2

        # keep the arguments used for the function show abd the properties
        self._text = text[:1]
        self._font = font
        self._fgcolor = fgcolor
        self._bgcolor = bgcolor
        self._bdwidth = bdwidth
        self._bdcolor = bdcolor
        # Show the widget        
        self.show()
        
    def show(self):
        """Show the widget"""

        # Get the text properties
        fw = self._font.width
        fh = self._font.height
        tl = len(self._text) * fw
        tx = self._x - (tl // 2)
        ty = self._y - (fh // 2)
        
        # If the radius is -1, use the font height * 0.9 as radius
        if self._radius < 0:
            self._radius = int(fh * 0.7) 

        # Draw the border
        if self._bdcolor is not None:
            # Draw the outer circle
            cyd.display.fill_circle(self._x, self._y, self._radius, self._bdcolor)
            # Reduce the radius used for the inner circle
            self._radius = self._radius - self._bdwidth
                    
        # Draw a filled circle
        cyd.display.fill_circle(self._x, self._y, self._radius, self._bgcolor)

        # Draw the text
        self._display.draw_text(tx, ty,
                                self._text,
                                self._font,
                                self._fgcolor,
                                background=self._bgcolor)

    def clear(self):
        """Draw a filled circle in black"""
        # clear_widget()
        if self._bdwidth is not None:
            self._radius = self._radius + self._bdwidth
        cyd.display.fill_circle(self._x, self._y, self._radius, BLACK)

    @property
    def text(self):
        return self._text

    @text.setter
    def text(self, value):
        """Set new text"""
        self._text = value
        self.show()

    @property
    def radius(self):
        return self._radius

    @radius.setter
    def radius(self, value):
        """Set new radius"""
        self._radius = value
        self.show()

    @property
    def bgcolor(self):
        return self._bgcolor

    @bgcolor.setter
    def bgcolor(self, value):
        """Set new background color"""
        self._bgcolor = value
        self.show()

    @property
    def bdcolor(self):
        return self._bdcolor

    @bdcolor.setter
    def bdcolor(self, value):
        """Set new border color"""
        self._bdcolor = value
        self.show()

    @property
    def bdwidth(self):
        return self._bdwidth

    @bdwidth.setter
    def bdwidth(self, value):
        """Set new border width"""
        if value < 0 or value > self._radius: value = 0
        self._bdwidth = value
        self.show()

###########################################################
# DEMO
###########################################################
# Set to true to run as demo / test
_DEMO = False
if _DEMO:
    print(f'demo_widget')
    from fonts.xglcd_font import XglcdFont
    from time import sleep
    from cydr import CYD

    # Create CYD instance
    cyd = CYD(rotation=270, width=340, height=240)

    # Font
    # Load fonts: path, font width, font height = ensure matches the font definition (see c code).
    font_big = XglcdFont('fonts/Unispace12x24.c', 12, 24)

    # Draw big LED - display, id, x, y, r, bgcolor, bdcolor
    ledlabel = LEDLabel(cyd.display, -1, 50, 50, 'L', font_big, radius=50, fgcolor=WHITE, bgcolor=RED)

    # Draw LED with default radius and a border
    ledlabel = LEDLabel(cyd.display, -1, 50, 200, 'X', font_big, radius=-1, fgcolor=RED, bdwidth=2, bgcolor=YELLOW, bdcolor=BLUE)
    sleep(2)

    # Draw LED with default radius and a border
    ledlabel.clear()
    ledlabel = LEDLabel(cyd.display,
                        -101,
                        cyd.display.width - 40,
                        cyd.display.height -20,
                        'X', font_big, radius=-1, fgcolor=RED, bdwidth=2, bgcolor=WHITE, bdcolor=None)
    sleep(2)

    # Draw LED with default radius and a border
    ledlabel.text = 'U'
    # ledlabel = LEDLABEL(cyd.display, -1, 50, 200, '', font_big, radius=-1, fgcolor=RED, bdwidth=2, bgcolor=BLUE, bdcolor=None)

    sleep(10)

    # Shutdown
    cyd.shutdown()


