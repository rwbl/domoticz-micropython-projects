# File: device.py
# Date: 20240207
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Device widget to display Domoticz device with attributes (case sensitive):
# Name, Data, LastUpdate, idx

# Notes
# Each widget class must have properties used for touch position and object:
# self.id = id,self.x = x,self.y = y,self.w = w,self.h = h
# draw_text property rotate is not used.

# TODO: For multiple lines, try to fit lines on a line instead each line has its own draw_text on x,y

# Import from the drivers the color and additional constants
from drivers.colors import *
import time

class Device(object):
    """
    Device widget.
    Display Domoticz device with attributes (case sensitive)
    Name, Data, LastUpdate


    Args:
        display (Display): Display instance.
        id (int): Unique id of the widget.
        x (int): Rectangle top x position.
        y (int): Rectangle top y position.
        w (int): Rectangle width.
        h (in): Rectangle height.
        device (dict): Device attributes (lowercase) name, data, valuedata ...
        font (XglcdFont object): Font
        fgcolor (int): RGB565 text color value.
        bgcolor (int): RGB565 background color (default: black).
        bdcolor (int): RGB565 border color (default: black).
    """

    def __init__(self,
                 display,
                 id,
                 x, y, 
                 device,
                 font,
                 w=100, h=80,
                 fgcolor=None,
                 bgcolor=BLACK,
                 bdcolor=None,
                 linecolor=None):
        
        # Set the properties
        self._display = display
        self.id = id
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        
        self.name = device['name']
        self.data = device['data']
        self.datavalue = device['datavalue']
        self.lastupdate = device['lastupdate']
        self.idx = device['idx']
        self.subtype = device['subtype']
        self.cancontrol = device['cancontrol']
        
        self.font = font
        self.fgcolor = fgcolor
        self.bgcolor = bgcolor
        self.bdcolor = bdcolor
        self.linecolor = linecolor
        #
        self.show()

    def show(self):
        """Show the widget"""

        # Draw the rectangle
        if self.bdcolor is not None:
            self._display.fill_rectangle(self.x, self.y, self.w, self.h, self.bdcolor)
            time.sleep_ms(20)
            self._display.fill_rectangle(self.x+2, self.y+2, self.w-4, self.h-4, self.bgcolor)
        else:
            self._display.fill_rectangle(self.x, self.y, self.w, self.h, self.bgcolor)
            
        # Font width, height
        fw = self.font.width
        fh = self.font.height

        offset = 4

        # Draw the 3 attributes left aligned
        
        # Name
        x = self.x + offset
        y = self.y + offset
        self.show_text(x,y,self.name)        

        # Horizontal line
        if self.linecolor is not None:
            self._display.draw_hline(self.x, y + (fh * 2) + 4, self.w, self.linecolor)

        # Data
        x = x
        y = self.y + (self.h // 2) - (fh // 2)
        # Set number of data lines to be displayed depending if attribute lastupdate is visible
        linecnt = 2 if self.lastupdate is not None else 3
        self.show_text(x, y, self.data, linecount=linecnt)

        # LastUpdate
        if self.lastupdate is not None:
            x = x
            y = self.y + self.h - (fh * 2) - offset - 2
            # Split date & time
            self.show_text(x, y, self.lastupdate)

    def value(self, text):
        """Show the new text"""
        self.text = text
        self.show()
    
    def _wrap(self, width, font, text):
        """
        Wrap text into N lines.
        
        Args:
            width (int): width (px) to fit text line
            font (font): Font used to display the text
            text (string): Text to display
        
        Return:
            lines list.
            
        Notes:
            Print statements commented out but want to keep for optimizing function.
            Line length calculated using len(line) * fw instead font.measure_text(line).
        """
        # Return n lines
        lines = []
        fw = font.width
        # Split the text using space
        textlines = text.split()
        # print(textlines)
        # Keep the length of the chars
        newlinelen = 0
        newline = ''
        # print('_wrap w/fw',width,fw)
        
        # Loop over the textlines split by space
        for line in textlines:

            # Add line length
            newlinelen += len(line) * fw # font.measure_text(line)
            # print('newlinelen/width/line',newlinelen,width,line,len(line))

            # Check if the newlinelen still fits in the width
            if newlinelen <= width:
                # Add the line to the linesum
                newline += line + ' '
                # print('linesum=newline',newline)
            
            else:
                # The newlinelen is > width > add to the newline
                lines.append(newline.rstrip())
                # print('lines.append',newline)
                newlinelen = len(line) * fw # font.measure_text(line)
                newline = line + ' '
                # print('lines.append newline',newline, newlinelen)
                
        lines.append(newline.rstrip())
        # print('line.append.lastline',newline)

        return lines
    
    def show_text(self, x, y, text, linecount=2):
        """
        Check if the text fits within width of the rectangle.
        If not, then split in 2 lines max. More lines are not displayed.
        
        Args:
            x (int), y(int): Position of the text (left aligned).
            text (string): Text to display.
            
        """
        
        if text is None:
            return
        
        # Font width, height
        fw = self.font.width
        fh = self.font.height
        
        # Get text length in pixel        
        tl = self.font.measure_text(text)
        
        # print(self.name, text, len(text), tl, self.w, self.font.width)
        
        # Check if text length first in width minus 2*4 pixels for border
        if tl > self.w - 8:
            # Two step approach - split first and check if there are 2 lines only
            lines = text.split()
            if len(lines) > 2:
                lines = self._wrap(self.w - 8, self.font, text)
            # print(lines, len(lines), linecount)
            
            # Limit to N lines
            lines = lines[:linecount]
            # Lines counter
            i = 0
            # First option = Each line has its own y position
            yy = y
            for line in lines:
                y = yy + (i * fh) + 2
                self._display.draw_text(x, y,
                                        line, self.font,
                                        self.fgcolor, background=self.bgcolor)
                i = i + 1                    
        else:
            self._display.draw_text(x, y,
                                    text, self.font,
                                    self.fgcolor, background=self.bgcolor)
        return x,y
    