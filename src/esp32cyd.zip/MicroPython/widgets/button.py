# File: button.py
# Date: 20240201
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Simple button using external font.

# Notes
# Each widget class must have properties used for touch position and object:
# self.id = id,self.x = x,self.y = y,self.w = w,self.h = h
# draw_text property rotate is not used.

# Import from the drivers the color and additional constants
from drivers.colors import *
import time

class Button(object):
    """Button with Label using external font

    Args:
        display (Display): Display instance.
        id (int): Unique id of the widget.
        x (int): Rectangle top x position.
        y (int): Rectangle top y position.
        w (int): Rectangle width.
        h (in): Rectangle height.
        text (string): Text to draw.
        font (XglcdFont object): Font
        fgcolor (int): RGB565 text color value.
        bgcolor (int): RGB565 background color (default: black).
        bdcolor (int): RGB565 border color (default: black).
        justify (int): Text justified left (0), center (1), right (2)
    """

    def __init__(self,
                 display,
                 id,
                 x, y, w, h,
                 text,
                 font,
                 fgcolor=None, bgcolor=BLACK, bdcolor=None,
                 justify=LEFT):
        
        # Set the properties
        self._display = display
        self.id = id
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.text = text
        self.font = font
        self.fgcolor = fgcolor
        self.bgcolor = bgcolor
        self.bdcolor = bdcolor
        self.justify = justify
        #
        self.show()

    def show(self):
        # Text width, height, length, max characters to fit in width
        tw = self.font.width
        th = self.font.height
        tl = self.font.measure_text(self.text)
        tlc = (tl // tw) + 1
        # print(tw, tl, tlc, self.w)

        # Check if the text fits in the rectangle
        if tl > self.w:
            # Adjust the width with 4 pixels extra
            self.w = tl + 4
        if th > self.h:
            # Adjust the width with 4 pixels extra
            self.h = th + 4
        # print(self.x,self.y,self.w,self.h,tw,th,tl)

        # Draw the rectangle
        if self.bdcolor is not None:
            self._display.fill_rectangle(self.x, self.y, self.w, self.h, self.bdcolor)
            time.sleep_ms(20)
            self._display.fill_rectangle(self.x+2, self.y+2, self.w-4, self.h-4, self.bgcolor)
            self.x = self.x+2
            self.y = self.y+2
            self.w = self.w-4
            self.h = self.h-4
        else:
            self._display.fill_rectangle(self.x, self.y, self.w, self.h, self.bgcolor)

        # Draw the text with adjusted x, y
        # Text x pos based on the justify
        if self.justify == LEFT:
            x = self.x
        if self.justify == CENTER:
            x = self.x + ( self.w // 2) - (tl // 2)
        if self.justify == RIGHT:
            x = self.x + self.w - tl
            
        # Text align vertical
        y = self.y + int(( (self.h - th) // 2))
        if y < 0:
            y = self.y

        # Draw the text (truncated)
        self._display.draw_text(x, y,
                                self.text[:tlc], self.font,
                                self.fgcolor, background=self.bgcolor)

    def value(self, text):
        """Show the new button text"""
        self.text = text
        self.show()
    