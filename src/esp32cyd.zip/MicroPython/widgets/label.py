# label.py
# Date: 20240201
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Widget Label using external font.

# Notes
# Each widget class must have properties used for touch position and object:
# self.id = id,self.x = x,self.y = y,self.w = w,self.h = h
# draw_text property rotate is not used.

# Import from the drivers the color and additional constants
from drivers.colors import *

class Label(object):
    """Label using external font

    Args:
        display (Display): Display instance.
        id (int): Unique id of the widget.
        x (int): Starting X position.
        y (int): Starting Y position.
        text (string): Text to draw.
        font (XglcdFont object): Font
        fgcolor (int): RGB565 text color value.
        bgcolor (int): RGB565 background color (default: black).
    """

    def __init__(self,
                 display,
                 id,
                 x, y,
                 text,
                 font,
                 fgcolor=None, bgcolor=BLACK):
        
        # Set the properties
        self._display = display
        self.id=id
        self.x = x
        self.y = y
        self.w = font.measure_text(text)
        self.h = font.height
        self.text = text
        self.font = font
        self.fgcolor = fgcolor
        #bgcolor can not be none
        if bgcolor is None:
            bgcolor = BLACK
        self.bgcolor = bgcolor
        #
        self.show()

    def show(self):
        """Draw the text at given position"""
        self._display.draw_text(self.x, self.y,
                                self.text, self.font,
                                self.fgcolor, background=self.bgcolor)

    def value(self, text, fgcolor, bgcolor):
        """Show the new text"""
        self.text = text
        if fgcolor is not None:
            self.fgcolor = fgcolor
        if bgcolor is not None:
            self.bgcolor = bgcolor
        self.show()
    