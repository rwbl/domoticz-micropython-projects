# File: rectlabel.py
# Date: 20240201
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Rectangle with Label using external font.

# Notes
# Each widget class must have properties used for touch position and object:
# self.id = id,self.x = x,self.y = y,self.w = w,self.h = h
# draw_text property rotate is not used.

# Import from the drivers the color and additional constants
from drivers.colors import *
import time

class RectLabel(object):
    """Rectangle with Label using external font

    Args:
        display (Display): Display instance.
        id (int): Unique id of the widget.
        x (int): Rectangle top x position.
        y (int): Rectangle top y position.
        w (int): Rectangle width.
        h (in): Rectangle height.
        text (string): Text to draw.
        font (XglcdFont object): Font
        fgcolor (int): RGB565 text color value.
        bgcolor (int): RGB565 background color (default: black).
        bdcolor (int): RGB565 border color (default: black).
        justify (int): Text justified left (0), center (1), right (2)
    """

    def __init__(self,
                 display,
                 id,
                 x, y, w, h,
                 text,
                 font,
                 fgcolor=WHITE,
                 bgcolor=BLACK,
                 bdcolor=None,
                 justify=LEFT):
        
        # Set the properties
        self._display = display
        self.id = id
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.text = text
        self.font = font
        self.fgcolor = fgcolor
        self.bgcolor = bgcolor
        self.bdcolor = bdcolor
        self.justify = justify
        #
        self.show()

    def show(self):
        """Show the widget"""
        
        # Text width, height & length
        tw = self.font.width
        th = self.font.height
        tl = self.font.measure_text(self.text)

        # Check if the text fits in the rectangle
        if tl > self.w:
            # Adjust the width with 4 pixels extra
            self.w = tl + 4
        if th > self.h:
            # Adjust the width with 4 pixels extra
            self.h = th + 4
        # print(self.x,self.y,self.w,self.h,tw,th,tl)

        # Draw the rectangle
        if self.bdcolor is not None:
            self._display.fill_rectangle(self.x, self.y, self.w, self.h, self.bdcolor)
            time.sleep_ms(20)
            self._display.fill_rectangle(self.x+2, self.y+2, self.w-4, self.h-4, self.bgcolor)
            self.x = self.x+2
            self.y = self.y+2
            self.w = self.w-4
            self.h = self.h-4
        else:
            self._display.fill_rectangle(self.x, self.y, self.w, self.h, self.bgcolor)

        # Draw the text with adjusted x, y
        # Text x pos based on the justify
        if self.justify == LEFT:
            x = self.x
        if self.justify == CENTER:
            x = self.x + ( self.w // 2) - (tl // 2)
        if self.justify == RIGHT:
            x = self.x + self.w - tl
            
        # Text align vertical
        y = self.y + int(( (self.h - th) // 2))
        if y < 0:
            y = self.y

        # Draw the text
        self._display.draw_text(x, y,
                                self.text, self.font,
                                self.fgcolor, background=self.bgcolor)

    def value(self, text):
        """Show the new text"""
        self.text = text
        self.show()

###########################################################
# DEMO
###########################################################
# Set to true to run as demo / test
_DEMO = False
if _DEMO:
    from fonts.xglcd_font import XglcdFont
    from time import sleep
    from cydr import CYD

    def set_background():
        sleep(2)
        cyd.display.clear()
        cyd.display.fill_rectangle(0, 0, cyd.display.width-1, cyd.display.height-1, RED)

    # Create CYD instance
    cyd = CYD(rotation=270, width=340, height=240)

    # Font
    # Load fonts: path, font width, font height = ensure matches the font definition (see c code).
    font_big = XglcdFont('fonts/Unispace12x24.c', 12, 24)
    sleep(1)
    
    # set_background()

    rectlabel = RectLabel(cyd.display,-1, 10, 10, 100, 40, "Hello World!", font_big, bgcolor=BLUE, bdcolor=YELLOW)
    sleep(2)

    # Shutdown
    cyd.shutdown()
