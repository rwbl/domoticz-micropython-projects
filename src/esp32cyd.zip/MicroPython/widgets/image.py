# File: image.py
# Date: 20240201
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Widget Image

# If a widget is touchable, then the widget class must have
# properties used for touch position and object:
# self.id = id, self.x = x, self.y = y, self.w = w, self.h = h

# TODO: NOT USED for now because of memory constrains.
# TODO: Image imports failing for some PNG formats. Cause unknown.

# Import from the drivers the color and additional constants
from drivers.colors import *

class Image(object):
    """
    Image drawing from an image file located in folder images.

    Args:
        display (Display): Display instance.
        id (int): Unique id of the widget.
        x (int): Image top x position.
        y (int): Image top y position.
        w (int): Image width.
        h (in): Image height.
        imagefile (string): path & filename of the image to display.
        fgcolor (int): RGB565 text color value.
        bgcolor (int): RGB565 background color (default: black).
        rotate (int): Rotation in degrees 0, 90, 180, 270
    """

    def __init__(self,
                 display,
                 id,
                 x, y, w, h,
                 imgfile,
                 fgcolor=None, bgcolor=BLACK,
                 rotate=0):
        
        # Set the properties
        self._display = display
        self.id = id
        self.x = x
        self.y = y
        self.w = w
        self.h = h

        self._display.draw_image(imgfile, x, y, w, h)

