# File: main.py
# Date: 20240213
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Autoload - Abort with CTRL+C in Thonny
# import demos.demo_domoticz
