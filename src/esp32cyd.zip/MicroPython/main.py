# File: booty.py
# Date: 20240208
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Start
# Abort with CTRL+C in Thonny
import demos.domoticz_little_board
