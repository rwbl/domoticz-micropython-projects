# File: server.py
# Date: 20240212
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Class to manage the ESP32 RESTful webserver.
# Ref: https://docs.micropython.org/en/latest/library/network.WLAN.html
# Commands set via HTTP GET requests with HTTP response JSON object.
# The Domoticz HTTP API commands are executed (see section Domoticz).

__name__ = "server"
__class__ = "Server"
__version__ = '20240209'
__author__ = "Robert W.B. Linn"

# Libraries
import network
import requests
# import socket
import time
# from machine import Pin
import json

"""
Class Server
"""
class Server:
    # Constants
    _CRLF = chr(13) + chr(10)
    _SPACE = chr(32)

    def log_debug(self, msg):
        """
        Log to the console if debug flag is true.

        Args:
            msg (string): Message to print
        """
        if self._debug:
            print(f'[DEBUG Server Instance] {msg}')

    def __init__(self, wifi_ssid, wifi_password, doconnect=False, debug=False):
        """
        Init the network with defaults.

        Args:
            wifi_ssid (string): SSID of the network to connect
            wifi_password (string): Passord of the network to connect
            doconnect (bool): Flag is a network connection should be made
            debug (bool): Flag to set the log for debugging purposes
        """
        self._debug = debug
        self._wifi_ssid = wifi_ssid
        self._wifi_password = wifi_password
        self.server = None
        self.ip = None
        self.connected = False
        
        # Connect
        if doconnect:
            # Connect to the network and get the server object
            self.server = self.connect()
            self.connected = True if self.server.isconnected() else False

    #WLAN Connection states
    #STAT_IDLE – no connection, no activities-1000
    #STAT_CONNECTING – Connecting-1001
    #STAT_WRONG_PASSWORD – Failed due to password error-202
    #STAT_NO_AP_FOUND – Failed, because there is no access point reply,201
    #STAT_GOT_IP – Connected-1010
    #STAT_ASSOC_FAIL – 203
    #STAT_BEACON_TIMEOUT – Timeout-200
    #STAT_HANDSHAKE_TIMEOUT – Handshake timeout-204

    def connect(self):
        """
        Connect to the network using the class SSID and password.
        Do not start listening like for connect().

        Args:
            None

        Return:
            wlan (object): WLAN object
        
        Example:
            # Create server object
            station = Server(secrets.WIFI_SSID, secrets.WIFI_PASSWORD, doconnect=True, debug=True)
            print(f'Network connected={network.connected}, ip={network.ip}')
            # Do something and then disconnect
            station.send_get_request(url)
            station.disconnect()
        """
        try:
            self.log_debug("[connect] WLAN create station instance...")
            network.WLAN(network.AP_IF).active(False)
            
            wlan = network.WLAN(network.STA_IF)

            # Already connected
            if wlan.isconnected():
                try:
                    self.log_debug("[connect] WLAN already connected")
                    if wlan.active() :
                        self.log_debug("[connect] WLAN disconnecting...")
                        wlan.disconnect()
                        wlan.active(False)
                        time.sleep_ms(150)
                except Exception as e:
                    print(f'[ERROR connect] {str(e)}')

            # Network connection
            self.log_debug(f'[connect] WLAN connecting to {self._wifi_ssid}...')
            wlan.active(True)
            
            # Additional config to improve network stability
            # WiFi Power Management disabled
            wlan.config(pm=wlan.PM_NONE)
            # Maximum transmit power in dBm (integer or float)
            wlan.config(txpower=18)
            
            # Connect to the router
            wlan.connect(self._wifi_ssid, self._wifi_password)

            # Wait till connected within 20 seconds
            for retry in range(200):
                connected = wlan.isconnected()
                if connected:
                    break
                time.sleep(0.1)
                # print('.', end='')
            if connected:
                status = wlan.ifconfig()
                self.ip = status[0]
                self.log_debug('[connect] WLAN connected with ip=' + status[0] )
                return wlan
            else:
                self.log_debug(f'[ERROR connect] WLAN failed connecting to {self._wifi_ssid}')
                print(f'[ERROR connect] WLAN failed connecting to {self._wifi_ssid}')
                # raise RuntimeError('[ERROR connect] Network connection failed!')
                return None
            
        except OSError as e:
            cl.close()
            raise RuntimeError('[ERROR connect] Network connection closed {e}.')

    def disconnect(self):
        """
        Disconnect from the network.

        Args:
            None
        """
        self.log_debug("[disconnect] WLAN disconnecting...")
        if self.connected:
            self.disconnect()
            self.log_debug("[disconnect] WLAN disconnected.")

    def send_get_request(self, url):
        """
        Network submit http get request to the domoticz server.

        Args:
            url (string): URL of the HTTP request
        
        Return:
            status (int): 0 = Error, 1 = OK
            content (string): HTTP response content sent by Domoticz engine
        
        Example:
            Update the Domoticz temp+hum device with IDX 15
            http://domoticz-ip:port/json.htm?type=command&param=udevice&idx=15&nvalue=0&svalue=16;55;1
        """
        status = 0
        content = ''
        self.log_debug(f'Send GET request url={url}')
        
        try:
            # URL encode space
            url = url.replace(self._SPACE, '%20')
            r = requests.get(url)
            content = json.loads(r.content)
            self.log_debug(f'Send GET request status={content['status']}')
            r.close()
            status = 1
            
        except OSError as e:
            print(f'[ERROR send_get_request OSError] {e}')
            # raise Exception(f'[ERROR send_get_request] Sending data {e}.')
            
        except ValueError as e:
            print(f'[ERROR send_get_request ValueError] {e}, {r.content.decode()}')
            # raise Exception(f'[ERROR send_get_request] {e}, {r.content.decode()}.')
        return status, content 

    def parse_get_request(self, request):
        """
        Parse the command from the HTTP GET Request.
        The first line of the request contains the command.
        The first line is split and the 2nd item holds the command + data.
        Example first line with the command:
        GET /led1/on HTTP/1.1
        The command is /led1/on.

        Args:
            request (string): HTTP GET request
        
        Return:
            command (string): Command, i.e. /led1/on
            status (int): 0 = Error, 1 = OK

        Example:
            # Parse the get data. In case of error, the status is 0.
            cmd, status = network.parse_get_request(request)
        """
        status = 0
        cmd = self._MESSAGE_CMD_UNKNOWN
        
        # Split the decoded request string into a list
        data = str(request.decode()).split(self._CRLF)
        
        # Check if there is data to get the first item
        if (len(data) > 0):
            # print(data[0])
            # Split the first item which is the command string into a list with 3 items
            cmds = data[0].split(self._SPACE)
            # Check length and get the 2nd item, i.e. /led1/on
            if len(cmds) == 3:
                cmd = cmds[1]
                status = 1
            else:
                print(f'[ERROR parse_get_request] HTTP GET number of command items invalid. Expect 3, got {len(cmds)}.')
        else:
            print(f'[ERROR parse_get_request] HTTP GET request not valid.')
        self.log_debug(f'[parse_get_request] HTTP Command={cmd}')
        
        # Return the command, i.e. /led1/on etc.
        return cmd, status

    # DOMOTICZ HTTP API Requests

    def get_server_time(self, ip):
        """
        Get the server time.

        Args:
            ip (string): IP address of the Domoticz server
            idx (int): idx of the roomplan

        Return:
            status (int): 0 = Error, 1 = OK
            servertime (string): Parsed from HTTP response, like
            {"ServerTime": "2021-01-13 23:10:13","status": "OK","title": "getServerTime"}

        Example:
            status, servertime = network.get_server_time('NNN.NNN.NNN.NNN')
        """
        url = f'http://{ip}/json.htm?type=command&param=getServerTime'
        status, response = self.send_get_request(url)
        if status == 1:
            return status, response['ServerTime']
        else:
            return status, None

    def get_plans(self, ip):
        """
        Get the roomplans ordered by name and used.

        Args:
            ip (string): IP address of the Domoticz server
            idx (int): idx of the roomplan

        Return:
            status (int): 0 = Error, 1 = OK
            result (JSON array): Parsed from HTTP response

        Example:
            status, servertime = network.get_plans('NNN.NNN.NNN.NNN')
        """
        url = f'http://{ip}/json.htm?type=command&param=getplans&order=name&used=true'
        # self.log_debug(url)
        status, response = self.send_get_request(url)

        # Check status
        if status == 1:
            return status, response['result']
        else:
            return status, None

    def get_plan_devices(self, ip, idx, preparser):
        """
        Get the devices for a roomplan.

        Args:
            ip (string): IP address of the Domoticz server
            idx (int): idx of the roomplan
            preparser (bool): Use the Node-RED PreParser

        Return:
            status (int): 0 = Error, 1 = OK
            result (JSON array): Parsed from HTTP response

        Example:
            status, devices = network.get_plan_devices('NNN.NNN.NNN.NNN', 123)
        """
        
        # Check the Node-RED Pre-Parser used to save memory
        if preparser:
            # Node-RED url using the same ip (but other port) as Domoticz because running on the same system
            url = f'http://{ip}/command?param=getdevices&plan={idx}'
            # Replace the Domoticz port 8080 with the Node-RED port 1880 (both use the defaults)
            url = url.replace(':8080', ':1880')
        else:
            # Domoticz HTTP API
            url = f'http://{ip}/json.htm?type=command&param=getdevices&plan={idx}'
        self.log_debug(url)
        
        # Send the HTTP request
        status, response = self.send_get_request(url)
        if status == 1:
            return status, response['result']
        else:
            return status, None

    def set_new_value(self, ip, param, idx, args):
        """
        Set a new value for a device.
        
        Args:
            ip (string): IP address of the Domoticz server
            param( string): Command parameter, like setsetpoint, switchlight
            idx (int): idx of the device
        
        Return:
            status (int): 0 = Error, 1 = OK
        """
        url = f'http://{ip}/json.htm?type=command&param={param}&idx={idx}&{args}'
        # self.log_debug(url)
        status, response = self.send_get_request(url)
        return status
