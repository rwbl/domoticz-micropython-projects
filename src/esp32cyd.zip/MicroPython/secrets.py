# File: secrets.py
# Date: 20240208
# Author: Robert W.B. Linn
# Secret settings which are network SSID, password and the IP of the Domotcz system.

# Example Import: import secrets.py
# Access configuration item: secrets.DOMOTICZ_IP
# To save memory use _ for vars used in the script only and const().

# Import the const package
from micropython import const

# Network - set SSID & Password
WIFI_SSID       = const('SSID')
WIFI_PASSWORD   = const('password')

# Domoticz
# Mode sets the server ip+port
# 0=test,1=production
_MODE = 0

# Domoticz IP + Port
if _MODE == 0:
    # Test system
    DOMOTICZ_IP = 'NNN.NNN.NNN.NNN:8080'
else:
    # Production system
    DOMOTICZ_IP = 'NNN.NNN.NNN.NNN:8080'
