# File: rectangle.py
# Date: 20240210
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Rectangle widget (controllable).

# If a widget is touchable, then the widget class must have
# properties used for touch position and object:
# self.id = id, self.x = x, self.y = y, self.w = w, self.h = h

# Import from the drivers the color and additional constants
from drivers.colors import *
import time

class RECTANGLE(object):
    """
    Rectangle.
    Not controllable.

    Args:
        display (Display): Display instance.
        id (int): Unique id of the widget.
        x (int): Top left x position of the rect.
        y (int): Top left y position of the rect.
        w (int): Width of the rect.
        h (int): Width of the rect.
        bgcolor (int): RGB565 background color (default: black).
        bdcolor (int): RGB565 border color (default: None = no border)
        bdwidth (int): Width of the border (default: 4).
    """

    def __init__(self,
                 display,
                 id,
                 x, y,
                 w, h,
                 bgcolor=BLACK,
                 bdcolor=None,
                 bdwidth=4):

        # Set the properties
        self._display = display
        self.id = id
        self.x = x
        self.y = y
        self._width = w
        self._height = h
        self._bgcolor = bgcolor
        self._bdcolor = bdcolor
        self._bdwidth = bdwidth
        # Show the widget        
        self.show()
        
    def show(self):
        """Show the widget"""
        
        # Draw the rectangle
        if self._bdcolor is not None:
            self._display.fill_rectangle(self.x, self.y, self._width, self._height, self._bdcolor)
            time.sleep_ms(20)
            offset = self._bdwidth // 2
            self.x = self.x+offset
            self.y = self.y+offset
            self._width = self._width-(offset*2)
            self._height = self._height-(offset*2)
            self._display.fill_rectangle(self.x, self.y, self._width, self._height, self._bgcolor)
        else:
            self._display.fill_rectangle(self.x, self.y, self._width, self._height, self._bgcolor)

    @property
    def width(self):
        return self._width

    @width.setter
    def width(self, value):
        """Set new width"""
        self._width = value
        self.show()

    @property
    def height(self):
        return self._height

    @height.setter
    def height(self, value):
        """Set new height"""
        self._height = value
        self.show()

    @property
    def bgcolor(self):
        return self._bgcolor

    @bgcolor.setter
    def bgcolor(self, value):
        """Set new background color"""
        self._bgcolor = value
        self.show()

    @property
    def bdcolor(self):
        return self._bdcolor

    @bdcolor.setter
    def bdcolor(self, value):
        """Set new border color"""
        self._bdcolor = value
        self.show()

    @property
    def bdwidth(self):
        return self._bdwidth

    @bdwidth.setter
    def bdwidth(self, value):
        """Set new border width"""
        if value < 0: value = 0
        self._bdwidth = value
        self.show()

###########################################################
# Main
###########################################################
# Set to true to run as demo / test
_DEMO = False
if _DEMO:
    print(f'demo_widget')
    from time import sleep
    from cydr import CYD

    def set_background():
        sleep(2)
        cyd.display.clear()
        cyd.display.fill_rectangle(0, 0, cyd.display.width-1, cyd.display.height-1, RED)

    # Create CYD instance
    cyd = CYD(rotation=270, width=340, height=240)
    
    set_background()
    
    # Draw rect - display, id, x, y, w, h, bgcolor, bdcolor, bdwidth
    rect = RECTANGLE(cyd.display, -1, 50, 50, 100, 50, bgcolor=RED, bdcolor=YELLOW, bdwidth=5)
    set_background()

    rect.bdwidth = 10
    set_background()

    rect.bgcolor = BLUE
    set_background()
    
    rect.bdcolor = RED
    set_background()

    # Shutdown
    cyd.shutdown()

