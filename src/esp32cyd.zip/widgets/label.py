# label.py
# Date: 20240201
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Widget Label using external font.

# Notes
# Each widget class must have properties used for touch position and object:
# self.id = id,self.x = x,self.y = y,self.w = w,self.h = h
# draw_text property rotate is not used.

# Import from the drivers the color and additional constants
from drivers.colors import *

class Label(object):
    """Label using external font

    Args:
        display (Display): Display instance.
        id (int): Unique id of the widget.
        x (int): Starting X position.
        y (int): Starting Y position.
        text (string): Text to draw.
        font (XglcdFont object): Font
        fgcolor (int): RGB565 text color value.
        bgcolor (int): RGB565 background color (default: black).
    """

    def __init__(self,
                 display,
                 id,
                 x, y,
                 text,
                 font,
                 fgcolor=WHITE, bgcolor=BLACK):
        
        # Set the properties
        self._display = display
        self.id = id
        self.x = x
        self.y = y
        self._font = font
        self._w = font.measure_text(text)
        self._h = font.height
        self._text = text
        self._fgcolor = fgcolor
        #bgcolor can not be none
        if bgcolor is None:
            bgcolor = BLACK
        self._bgcolor = bgcolor
        self._screen_build_delay = 1
        #
        self.show()

    def show(self):
        """Draw the text at given position"""
        self._display.draw_text(self.x, self.y,
                                self._text,
                                self._font,
                                self._fgcolor,
                                background=self._bgcolor)

    def value(self, value, fgcolor, bgcolor):
        """Show the new text"""
        self._text = value
        if fgcolor is not None:
            self._fgcolor = fgcolor
        if bgcolor is not None:
            self._bgcolor = bgcolor
        self.show()

    @property
    def text(self):
        return self._text
    
    @text.setter
    def text(self, value):
        self._text = value
        self.show()
        
    def clear(self):
        """Clear the text by filling with a rectangle with background black"""
        print("clear", self.x, self.y, self._w, self._h)
        self._display.fill_rectangle(self.x, self.y, self._w, self._h, BLACK)
        
###########################################################
# DEMO
###########################################################
# Set to true to run as demo / test
_DEMO = False
if _DEMO:
    print(f'demo_widget')
    from fonts.xglcd_font import XglcdFont
    from time import sleep
    from cydr import CYD
    
    # Create CYD instance
    cyd = CYD(rotation=270, width=340, height=240)

    # Font
    # Load fonts: path, font width, font height = ensure matches the font definition (see c code).
    font_big = XglcdFont('fonts/Unispace12x24.c', 12, 24)
    sleep(1)

    # Draw text
    lbl = Label(cyd.display, -1, 10, 10, "Hello World", font_big, fgcolor=WHITE)
    sleep(2)
    
    lbl.clear()
    lbl = Label(cyd.display, -1, 10, 10, "Hi", font_big, fgcolor=WHITE)
    sleep(2)

    # Shutdown
    cyd.shutdown()

