# domoticz-micropython-projects - TODO ESP32CYD
20240213

TODO: FIX Network at boot runtime error: Wifi Unknown Error 0x0101.
      Status: Reordered module loading. Network & make network connection has to go first!
TODO: FIX Network Errno 113 ECONNABORTED when requesting room plan detailed devices info (suspect memory issue, explore using urequests2.py).
      Status: Improved server get_request function. Since then less 113 errors... but still.
      Status: Developed Node-RED PreParser for the room plan request to resulting in smaller response (limited device attributes).
              Running with fewer errors, but still happening every now and then.
              Suspect also if less power supplied via USB, network issues occur. On Ubuntu device no issues, with Windows device issues.

TODO: UPD Memory usage is a BIG issue. Try to find ways to reduce memory usage. See also next.
TODO: UPD Review & implement https://docs.micropython.org/en/latest/reference/speed_python.html#maximising-micropython-speed.
TODO: UPD Simplify concept of set device data.
TODO: UPD Widgets enhance with property, getter, setter decorator.
TODO: UPD Improve error handling.
TODO: UPD Enhance the documentation, esp. how develop widgets.

TODO: NEW Widgets Slider, Blinds, InfoBox and other fancy stuff. Ensure to use property, getter, setter decorator.
TODO: NEW Widget with small images. Thinking about material icon intergration.
TODO: NEW Menu widgets Quick Access Buttons which are rounded buttons (circles with up-to 2 characters) instead labelrect (rectangle with centered label).
TODO: NEW Device control screen add two buttons to set min/off and max/on as defined in the config device limits.
TODO: NEW Consider to use double tap to see a log message or make a screenshot (framebuffer to PNG file).
TODO: NEW Widget LED with traffic light option.
TODO: NEW LED indicator at top right for WLAN connected (GREEN/RED).
      Status: Widget LED developed (see folder widgets), but not used yet.
TODO: NEW SD card for logging.
TODO: NEW Take screenshots and save to file using double tap.
TODO: NEW Automatic refresh option for the selected room plan, like every 60s (workaround: touch menu room plan).
TODO: NEW Consider other font (like system, courier new) for the devices screen widget.
TODO: NEW Define screen layout in JSON array containing the widgets, like [{"id":1,"text":"widget a","x":10,"y":10,"w":100,"h":50,"type":"rectangle"},...].
          Additional to the widgets, define connectors h/vlines.
		  The JSON widget entry must have mandatory keys - set value -1 if not used, like w and h for a label.
		  The id is the mandatory touch control ID.
TODO: NEW Settings screen and save to SD card.
TODO: NEW Remote control the screens, for example remote set a screen, remote update data, remote set alarm messages.

TODO: CHG Publish ESP32CYD as a dedicated github project HomeControlPanel.
