# File: colors.py
# Date: 20240210
# Authors: Robert W.B. Linn
# Licence: GNU

# Define the colors using 5-6-5 scheme
# Usage:
# from drivers.colors import *
# bgcolor=BLACK

# Import the 5-6-5 color scheme
from drivers.ili9341 import color565

# Define the colors in named order
BLACK       = color565(0, 0, 0)
BLUE        = color565(0, 0, 255)
CYAN        = color565(0, 255, 255)
DARKBLUE    = color565(0, 0, 90)
DARKGREEN   = color565(0, 80, 0)
GREEN       = color565(0, 255, 0)
GREY        = color565(100, 100, 100)
LIGHTBLUE   = color565(173,216,230)
LIGHTGREEN  = color565(0, 100, 0)
LIGHTRED    = color565(140, 0, 0)
LIGHTYELLOW = color565(255,255,224)
MAGENTA     = color565(255, 0, 255)
NAVYBLUE    = color565(0,0,128)
PURPLE      = color565(255, 0, 255)
RED         = color565(255, 0, 0)
WHITE       = color565(255, 255, 255)
YELLOW      = color565(255, 255, 0)

# Default font size
FONT_SIZE = 8

# Justify alignment
LEFT = 0
CENTER = 1
RIGHT = 2
