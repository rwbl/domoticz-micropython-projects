# File: config.py
# Date: 20240209
# Author: Robert W.B. Linn
# Global configuration constants.

# Import configuration: import config.py
# Access configuration item: config.TOUCH_INDICATOR
# To save memory use _ for vars used in the script only and const().

# Import the const package
from micropython import const
from drivers.colors import *

# Display resolution. Landscape mode (270 degrees rotation) is used.
# Do NOT change.
DISPLAY_WIDTH = const(320)
DISPLAY_HEIGHT = const(240)
DISPLAY_ROTATION = const(270)

# Show the touch indicator (coloured circle)
TOUCH_INDICATOR = True
TOUCH_INDICATOR_COLOR = RED

# Define the menu items holding the room plan names & idx at bottom of a screen.
# The x,y pos is calculated from the display width and the number of menu items.
# Touching a menu item loads the associated room plan devices.
# Menu item properties:
# id: Unique control id. Must be negative and start with -1000, followed by -1001 etc.
# text: Text which is set by the room plan name. Max text length depends on font width and menu item width.
# idx: Associated room plan idx (mandatory). Look up Domoticz gui or run http api room plan.
# fgcolor, bgcolor: text and background color (each menu item can have its own color setting).
menu_items = [
    {'id':-1000, 'text':'Plan A', 'idx':3, 'fgcolor':WHITE, 'bgcolor':RED},
    {'id':-1001, 'text':'Plan B', 'idx':4, 'fgcolor':RED, 'bgcolor':YELLOW},
    {'id':-1002, 'text':'Plan C', 'idx':5, 'fgcolor':WHITE, 'bgcolor':BLUE}
    # add more
]

# Update the menu_items from Domoticz via HTTP API request.
# The updated menu items are not stored permanent.
UPDATE_MENUS = False

# Devices screen using the Node-RED pre-parser to set the room plan devices.
# The pre-parser is used to save memory handling the HTTP API response.
# Depending on the number of room plan devices, the Domoticz response is large.
# The pre-parser returns devices with selective attributes and is therefor much smaller.
NODERED_PREPARSER = False

# Devices screen - Device widget colors.
DEVICE_FGCOLOR = BLACK # Text
DEVICE_BGCOLOR = WHITE # Background
DEVICE_BDCOLOR = None  # Border BLUE

# Set the number 1 to 6 of room plan devices to be displayed on the devices screen.
# Reduce if facing memory issues or use the Node-RED pre-parser.
MAX_PLAN_DEVICES = const(6)

# Flag to show the last update in the device widget (at bottom).
SHOW_LAST_UPDATE = const(False)

# Domoticz controlable devices
SWITCH_DEV = const('Switch')
ONOFF_DEV = const('On/Off')
DIMMER_DEV = const('Dimmer')
SETPOINT_DEV = const('SetPoint')
# ADD MORE like BLIND_DEV

# Define controlable devices for the devices screen enabling to set new value.
# See previous starting with the ONOFF devices.
CONTROLABLE_DEVICES = [ONOFF_DEV, DIMMER_DEV, SETPOINT_DEV]

# Domoticz HTTP API command param.
# Used in set_device_data triggered from the device control screen - must be lowercase.
SWITCH_PARAM = const('switchlight')
SETPOINT_PARAM = const('setsetpoint')

# Domoticz device attribute (case sensitive) used to set new value.
# Default is 'Data', change here for any other like dimmer.
DIMMER_ATTR = const('LevelInt')   #No conversion to int required
SETPOINT_ATTR = const('SetPoint') #Convert from string to float
# ADD MORE

# In/Decrease step for a device.
DIMMER_STEP = const(5)
SETPOINT_STEP = const(0.5) #Check also the Domoticz device widget settings

# Device Control Screen
# Min/Max values for a device. Use int or float.
ONOFF_LIMITS = (0, 1)
DIMMER_LIMITS = (0, 100)
SETPOINT_LIMITS = (5.0, 21.0)

# Device Control Screen
# Set the prefix for the present value at the screen bottom left.
# Use None to hide the present value
PRESENT_VALUE_PREFIX = const('Present:')
# PRESENT_VALUE_PREFIX = None
