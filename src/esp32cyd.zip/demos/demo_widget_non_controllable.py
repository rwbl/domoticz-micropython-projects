# File: demo_widget_non_controllable.py
# Date: 20240210
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# Demo for developing a widget.
# This example widget LED is a non controllable widget.

# Controllable Widget
# Each controllable widget class must have properties used for touch position and object:
# self.id = id, self.x = x, self.y = y, self.w = w, self.h = h

# Import from the drivers the color and additional constants
from drivers.colors import *

class LED(object):
    """
    LED indicator which is a coloured indicator.
    Not controllable.

    Args:
        display (Display): Display instance.
        id (int): Unique id of the widget.
        x (int): Center x position of the circle.
        y (int): Center y position of the circle.
        radius (int): Radius of the circle (default: 20).
        bdwidth (int): Width of the border (default: 2).
        bgcolor (int): RGB565 background color (default: black).
        bdcolor (int): RGB565 border color (default: None = no border)
    """

    def __init__(self,
                 display,
                 id,
                 x, y,
                 radius,
                 bdwidth=2,
                 bgcolor=BLACK,
                 bdcolor=None):
        
        # Set the properties
        self._display = display
        self.id = id
        self.x = x
        self.y = y
        self.radius = radius
        self.bdwidth = bdwidth
        
        # Draw the border
        if bdcolor is not None:
            # Draw the outer circle
            cyd.display.fill_circle(self.x, self.y, self.radius, bdcolor)
            # Reduce the radius used for the inner circle
            self.radius = self.radius - self.bdwidth
                    
        # Draw a filled circle
        cyd.display.fill_circle(self.x, self.y, self.radius, bgcolor)

#
# Main
# For tests set _DEMO to true
_DEMO = True
if _DEMO:
    print(f'demo_widget')
    from time import sleep
    from cydr import CYD
    cyd = CYD(rotation=270, width=340, height=240)

    # Draw big LED - display, id, x, y, r, bgcolor, bdcolor
    led = LED(cyd.display, -1, 50, 50, 50, bgcolor=RED)

    # Draw LED with default radius and a border
    led = LED(cyd.display, -1, 50, 150, 20, bdwidth=2, bgcolor=YELLOW, bdcolor=BLUE)

    sleep(5)
    
    # Shutdown
    cyd.shutdown()
