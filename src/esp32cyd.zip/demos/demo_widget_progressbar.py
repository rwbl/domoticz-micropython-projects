# File: demo_widget_progressbar.py
# Date: 20240211
# Author: Robert W.B. Linn
# Licence: GNU 3.0

# ProgressBar widget (non-controllable).
# The progressbar has min 0, max 100 and has horizontal direction.

# If a widget is touchable, then the widget class must have
# properties used for touch position and object:
# self.id = id, self.x = x, self.y = y, self.w = w, self.h = h

# Import from the drivers the color and additional constants
from drivers.colors import *
import time

class PROGRESSBAR(object):
    """
    ProgressBar widget (non-controllable) with min 0, max 100.

    Args:
        display (Display): Display instance.
        id (int): Unique id of the widget.
        x (int): Top left x position of the progressbar.
        y (int): Top left y position of the progressbar.
        w (int): Width of the progressbar.
        h (int): Width of the progressbar.
        p (int): Progress between 0-100%.
        bgcolor (int): RGB565 background color (default: black).
        pgcolor (int): RGB565 background color progress bar (default: green).
        bdcolor (int): RGB565 border color (default: white).
        bdwidth (int): Width of the border (default: 4).
    """

    def __init__(self,
                 display,
                 id,
                 x, y,
                 w, h,
                 p,
                 bgcolor=BLACK,
                 pbcolor=GREEN,
                 bdcolor=WHITE,
                 bdwidth=4):

        # Set the properties
        self._display = display
        self.id = id
        
        self.x = x
        self.y = y
        self._w = w
        self._h = h
        
        self._progress = p
        self._bgcolor = bgcolor
        self._pbcolor = pbcolor
        self._bdcolor = bdcolor
        self._bdwidth = bdwidth
        self._screen_build_delay = 1
        
        # Border rectangle x,y,w,h
        # See previous x, y, _w, _h
        
        # Progressbar rectangle x,y,w,h
        offset = self._bdwidth // 2
        self.pbx = self.x + offset
        self.pby = self.y + offset
        self.pbw = self._w -  (offset * 2)
        self.pbh = self._h - (offset * 2)

        # Show the widget        
        self.show()
        
    def show(self):
        """Show the widget"""

        # Clear the progressbar rectangle = black coloured rectangle
        self.clear()
        
        # Draw the rectangle showing the border
        self._display.fill_rectangle(self.x, self.y, self._w, self._h, self._bdcolor)
        time.sleep_ms(self._screen_build_delay)
        
        # Draw the rectangle showing the background = same as the progressbar but could have other color
        self.clear_progress()

        # Draw the progressbar
        self.show_progress(self._progress)

    def clear(self):
        """Clear the rectangle + progressbar by creating black rectangle"""
        self._display.fill_rectangle(self.x, self.y, self._w, self._h, BLACK)
        time.sleep_ms(self._screen_build_delay)

    def clear_progress(self):
        """Clear the progress by creating black rectangle but leave the border"""
        self._display.fill_rectangle(self.pbx, self.pby, self.pbw, self.pbh, BLACK)
        time.sleep_ms(self._screen_build_delay)

    def show_progress(self, n):
        """Show the progressbar"""
        # Clear the progress bar
        self.clear_progress()
        
        # Draw the progressbar
        if n < 0: n = 0
        if n > 100: n = 100
        pbw = int(self.pbw * (n / 100))
        self._display.fill_rectangle(self.pbx, self.pby, pbw, self.pbh, self._pbcolor)
        time.sleep_ms(self._screen_build_delay)

    @property
    def progress(self):
        return self._progress

    @property
    def width(self):
        return self._width

    @width.setter
    def width(self, value):
        """Set new width"""
        self._width = value
        self.show()

    @property
    def height(self):
        return self._height

    @height.setter
    def height(self, value):
        """Set new height"""
        self._height = value
        self.show()

    @property
    def pbcolor(self):
        return self._pbcolor

    @pbcolor.setter
    def pbcolor(self, value):
        """Set new progressbar color"""
        self._pbcolor = value
        self.show()

    @property
    def bgcolor(self):
        return self._bgcolor

    @bgcolor.setter
    def bgcolor(self, value):
        """Set new background color"""
        self._bgcolor = value
        self.show()

    @property
    def bdcolor(self):
        return self._bdcolor

    @bdcolor.setter
    def bdcolor(self, value):
        """Set new border color"""
        self._bdcolor = value
        self.show()

    @property
    def bdwidth(self):
        return self._bdwidth

    @bdwidth.setter
    def bdwidth(self, value):
        """Set new border width"""
        if value < 0: value = 0
        self._bdwidth = value
        self.show()

###########################################################
# Main
###########################################################
# Set to true to run as demo / test
_DEMO = True
if _DEMO:
    print(f'demo_widget')
    from time import sleep
    from cydr import CYD

    def set_background():
        sleep(2)
        cyd.display.clear()
        cyd.display.fill_rectangle(0, 0, cyd.display.width-1, cyd.display.height-1, RED)

    # Create CYD instance
    cyd = CYD(rotation=270, width=340, height=240)
    
    # set_background()
    
    # Draw rect - display, id, x, y, w, h, bgcolor, bdcolor, bdwidth
    progress = 25
    pb = PROGRESSBAR(cyd.display, -1, 50, 50, 100, 50, progress, pbcolor=RED)
    time.sleep(2)
    pb.clear_progress()
    time.sleep(2)
    
    # Draw progressbar min 0, max 100 (set 100+step), step 10
    pb.pbcolor = GREEN
    for n in range(0, 110, 10):
        # rect = PROGRESSBAR(cyd.display, -1, 50, 50, 100, 50, n)
        pb.show_progress(n)
        time.sleep(1)
        
    time.sleep(2)
    
    # Shutdown
    cyd.shutdown()
