# File: cydr.py
# Date: 20240207
# Changes: Robert W.B. Linn for DoLiBo project (tagged with RWBL:).

# Based on the MicroPython_CYD_ESP32-2432S028R library.
# Author: James Tobin (License: MIT, https://github.com/jtobinart/MicroPython_CYD_ESP32-2432S028R)

# CREDITS: Many thanks for providing this library.

######################################################
#   Pin Reference
######################################################
"""
Pins
     0   Digital   Boot Button
     1   Digital   Connector P1               - TX
     2   Digital   Display                    - TFT_RS / TFT_DC
     3   Digital   Connector P1               - RX
     4   Digital   RGB LED                    - Red
     5   Digital   SD Card                    - SS [VSPI]
     6   Digital   Unpopulated Pad U4: pin 6  - SCK / CLK
     7   Digital   Unpopulated Pad U4: pin 2  - SDO / SD0
     8   Digital   Unpopulated Pad U4: pin 5  - SDI / SD1
     9   Digital   Unpopulated Pad U4: pin 7  - SHD / SD2
    10   Digital   Unpopulated Pad U4: pin 3  - SWP / SD3
    11   Digital   Unpopulated Pad U4: pin 1  - SCS / CMD
    12   Digital   Display                    - TFT_SDO / TFT_MISO [HSPI]
    13   Digital   Display                    - TFT_SDI / TFT_MOSI [HSPI]
    14   Digital   Display                    - TFT_SCK [HSPI]
    15   Digital   Display                    - TFT_CS [HSPI]
    16   Digital   RGB LED                    - Green
    17   Digital   RGB LED                    - Blue
    18   Digital   SD Card                    - SCK [VSPI]
    19   Digital   SD Card                    - MISO [VSPI]
    21   Digital   Display & Connector P3     - TFT_BL (BackLight) / I2C SDA
    22   Digital   Connector P3 & CN1         - I2C SCL
    23   Digital   SD Card                    - MOSI [VSPI]
    25   Digital   Touch XPT2046              - CLK [Software SPI]
    26   Analog    Speaker                    - !!!Speaker ONLY! Connected to Amp!!!
    27   Digital   Connector CN1              - Can be used as a capacitive touch sensor pin.
    32   Digital   Touch XPT2046              - MOSI [Software SPI]
    33   Digital   Touch XPT2046              - CS [Software SPI]
    34   Analog    LDR Light Sensor           - !!!Input ONLY!!!
    35   Digital   P3 Connector               - !!!Input ONLY w/ NO pull-ups!!!
    36   Digital   Touch XPT2046              - IRQ !!!Input ONLY!!! 
    39   Digital   Touch XPT2046              - MISO !!!Input ONLY!!! [Software SPI]
   
"""

######################################################
#   Import
######################################################
from drivers.ili9341 import Display
from drivers.xpt2046 import Touch

from machine import Pin, SPI, ADC, PWM, SDCard, SoftSPI
import gc
import os
import time

# RWBL: Added colors
from drivers.colors import *

class CYD(object):
    """Cheap Yellow Display"""
    
    def __init__(self,
                 rgb_pmw=False,
                 sd_enabled = False,
                 width=240, height=320,
                 rotation = 0):
        '''
        Initialize CDYc

        Args:
            rgb_pmw (Default = False): Sets RGB LED to static mode. (on/off), if false
                                       Sets RGB LED to dynamic mode. (16.5+ million color combination), if true
                                       Warning: RGB LED never completely turns off in dynamic mode.
            sd_enabled (Default = False): Initializes SD Card reader, user still needs to run mount_sd() to access SD card.
            
        RWBL: Removed speaker to save memory
        '''
        # Display
        hspi = SPI(1, baudrate=40000000, sck=Pin(14), mosi=Pin(13))
        self.display = Display(hspi, dc=Pin(2), cs=Pin(15), rst=Pin(0), rotation=rotation, width=width, height=height)
        self._rotation = rotation
        self._width = width
        self.height = height
        self._x = 0
        self._y = 0
        
        # Backlight - 1 to turn on
        self.tft_bl = Pin(21, Pin.OUT)
        self.tft_bl.value(1)
        
        # Touch
        self.last_tap = (-1,-1)
        sspi = SoftSPI(baudrate=100000, sck=Pin(25), mosi=Pin(32), miso=Pin(39))
        self._touch = Touch(sspi, cs=Pin(33), int_pin=Pin(36), int_handler=self.touch_handler)
        
        # Boot Button
        self._button_boot = Pin(0, Pin.IN)
        
        # LDR: Light Sensor (Measures Darkness)
        self._ldr = ADC(34)
        
        # RGB LED
        self._rgb_pmw = rgb_pmw
        if self._rgb_pmw == False:
            self.RGBr = Pin(4, Pin.OUT, value=1)     # Red
            self.RGBg = Pin(16, Pin.OUT, value=1)    # Green
            self.RGBb = Pin(17, Pin.OUT, value=1)    # Blue
        else:
            self.RGBr = PWM(Pin(4), freq=200, duty=1023)     # Red
            self.RGBg = PWM(Pin(16), freq=200, duty=1023)    # Green
            self.RGBb = PWM(Pin(17), freq=200, duty=1023)    # Blue
            print("RGB PMW Ready")
            
        # SD Card
        self._sd_ready = False
        self._sd_mounted = False
        if sd_enabled == True:
            try:
                self.sd = SDCard(slot=2)
                self._sd_ready = True
                print("SD card ready to mount.")
            except:
                print("Failed to setup SD Card.") 
    
    ######################################################
    #   Touchscreen Press Event
    ###################################################### 
    def touch_handler(self, x, y):
        '''
        Interrupt Handler
        This function is called each time the screen is touched.
        
        RWBL: added rotation handling.
        '''
        if self._rotation == 0:
            # Portriat with power supply top
            # width=240, height=320
            # X needs to be flipped
            x = (self.display.width - 1) - x
        
        if self._rotation == 90:
            # Landscape with power supply left
            # width=320, height=240
            # Touch coordinates need to be swapped.
            x, y = y, x
        
        if self._rotation == 180:
            # Portriat with power supply bottom
            # width=240, height=320
            # Touch coordinates need to be swapped.
            # x, y = y, x
            # x = (self.display.width - 1) - x
            y = (self.display.height - 1) - y
        
        if self._rotation == 270:
            # Landscape with power supply right
            # width=320, height=240
            # Touch coordinates need to be swapped.
            x, y = y, x
            # x,y to be flipped
            x = (self.display.width - 1) - x
            y = (self.display.height - 1) - y

        self._x = x
        self._y = y

        #print("Touch:", x, y)
    
    def touches(self):
        '''
        Returns last stored touch data.
        
        Return:
            x: x coordinate of finger 1
            y: y coordinate of finger 1
        '''
        x = self._x
        y = self._y
        
        self._x = 0
        self._y = 0
        
        return x, y
    
    def double_tap(self, x, y, error_margin = 5):
        '''
        Returns whether or not a double tap was detected.
        
        Return:
            True: Double-tap detected.
            False: Single tap detected.
        '''    
        # Double tap to exit
        if self.last_tap[0] - error_margin <= x and self.last_tap[0] + error_margin >= x:
            if self.last_tap[1] - error_margin <= y and self.last_tap[1] + error_margin >= y:
                self.last_tap = (-1,-1)
                return True
        self.last_tap = (x,y)
        return False
        
    ######################################################
    #   RGB LED
    ###################################################### 
    def rgb(self, color):
        '''
        Set RGB LED color.
        
        Args:
            color: Array containing three int values (r,g,b).
                    if rgb_pmw == False, then static mode is activated.
                        r (0 or 1): Red brightness.
                        g (0 or 1): Green brightness.
                        b (0 or 1): Blue brightness.
                    if rgb_pmw == True, then dynamic mode is activated.
                        r (0-255): Red brightness.
                        g (0-255): Green brightness.
                        b (0-255): Blue brightness.
        '''
        r, g, b = color
        if self._rgb_pmw == False:
            self.RGBr.value(1 if min(max(r, 0),1) == 0 else 0)
            self.RGBg.value(1 if min(max(g, 0),1) == 0 else 0)
            self.RGBb.value(1 if min(max(b, 0),1) == 0 else 0)
        else:
            self.RGBr.duty(int(min(max(self._remap(r,0,255,1023,0), 0),1023)))
            self.RGBg.duty(int(min(max(self._remap(g,0,255,1023,0), 0),1023)))
            self.RGBb.duty(int(min(max(self._remap(b,0,255,1023,0), 0),1023)))
    
    def _remap(self, value, in_min, in_max, out_min, out_max):
        '''
        Internal function for remapping values from one scale to a second.
        '''
        in_span = in_max - in_min
        out_span = out_max - out_min
        scale = out_span / in_span
        return out_min + (value - in_min) * scale
    
    ######################################################
    #   Light Sensor
    ###################################################### 
    def light(self):
        '''
        Light Sensor (Measures darkness)
        
        Return: a value from 0.0 to 1.0
        '''
        return self._ldr.read_u16()/65535
    
    ######################################################
    #   Button
    ###################################################### 
    def button_boot(self):
        '''
        Gets the Boot button's current state
        '''
        return self._button_boot.value
    
    ######################################################
    #   Backlight
    ###################################################### 
    def backlight(self, val):
        '''
        Sets TFT Backlight Off/On
        
        Arg:
            val: 0 or 1 (0 = off/ 1 = on)
        '''
        self.tft_bl.value(min(max(val, 0),1))
    
    ######################################################
    #   SD Card
    ###################################################### 
    def mount_sd(self):
        '''
        Mounts SD Card
        '''
        try:
            if self._sd_ready == True:
                os.mount(self.sd, '/sd')  # mount
                self._sd_mounted = True
                print("SD card mounted. Do not remove!")
        except:
            print("Failed to mount SD card")
    
    def unmount_sd(self):
        '''
        Unmounts SD Card
        '''
        try:
            if self._sd_mounted == True:
                os.unmount('/sd')  # mount
                self._sd_mounted = False
                print("SD card unmounted. Safe to remove SD card!")
        except:
            print("Failed to unmount SD card")
    
    ######################################################
    #   Shutdown
    ###################################################### 
    def shutdown(self):
        '''
        Resets CYD and properly shuts down.
        '''
        self.display.fill_rectangle(0, 0, self.display.width-1, self.display.height-1, BLACK)
        self.display.draw_rectangle(2, 2, self.display.width-5, self.display.height-5, RED)
        self.display.draw_text8x8(self.display.width // 2 - 52, self.display.height // 2 - 4, "Shutting Down", WHITE, background=BLACK)
        time.sleep(2.0)
        self.unmount_sd()
        if self._rgb_pmw == False:
            self.RGBr.value(1)
            self.RGBg.value(1)
            self.RGBb.value(1)
        else:
            self.rgb(0,0,0)
        self.tft_bl.value(0)
        self.display.cleanup()
        print("========== Goodbye ==========")
    
