# domoticz-micropython-projects - INSTALL ESP32CYD

## ESP32CYD Installation 
If MicroPython has been setup on the ESP32CYD, then next steps else go over ESP32CYD Setup

* Extract the project archive esp32cyd.zip to a folder of choice on a development device.
* Copy the content of the folder MicroPython to the ESP32CYD.
* The files with extention .md can be deleted.
* Start Thonny
* Change secrets.py SSID, password, Domoticz IP.
* Change config.py to set the room plan menu items. Start with one or two room plans.
* Start from folder demos demo_domoticz.py.
* Lookup the Thonny shell log entries.

* If Node-RED used, then install the flow from folder Node-RED.
* Change config.py to set the NODERED_PREPARSER = True

## ESP32CYD Setup

**Info**
The ESP32CYD (ESP32-2432S028) is setup using a notebook running Microsoft Windows [Version 10.0.22631.3085] and tested on a notebook running Ubuntu 18.04 LTS.

### Install ESPTool
Open terminal and run
```
pip install esptool
```

Log Snippet
```
Collecting esptool
Downloading esptool-4.7.0.tar.gz (285 kB)
…
Successfully built esptool
Installing collected packages: reedsolo, pyserial, intelhex, bitarray, six, PyYAML, pycparser, bitstring, ecdsa, cffi, cryptography, esptool
Successfully installed PyYAML-6.0.1 bitarray-2.9.2 bitstring-4.1.4 cffi-1.16.0 cryptography-42.0.1 ecdsa-0.18.0 esptool-4.7.0 intelhex-2.3.0 pycparser-2.21 pyserial-3.5 reedsolo-1.7.0 six-1.16.0
```

### Install setuptools
Open terminal and run
```
pip install setuptools
```

Log Snippet
```
Requirement already satisfied: setuptools in c:\prog\python\lib\site-packages (68.0.0)
```

### Check ESPTool
Open terminal and run
```
python -m esptool
```

Log Snippet
```
esptool.py v4.7.0
usage: esptool [-h]
esptool.py v4.7.0 - Espressif chips ROM Bootloader Utility
```

### ESP32 Erase Flash
Connect the ESP32CYD to an USB port of the development device.

Open terminal and run
```
python -m esptool --chip esp32 erase_flash
```

Log Snippet
```
esptool.py v4.7.0
Found 1 serial ports
Serial port COM4
Connecting.....
Chip is ESP32-D0WD-V3 (revision v3.1)
Features: WiFi, BT, Dual Core, 240MHz, VRef calibration in efuse, Coding Scheme None
Crystal is 40MHz
MAC: e4:65:b8:20:a8:a4
Uploading stub...
Running stub...
Stub running...
Erasing flash (this may take a while)...
Chip erase completed successfully in 1.9s
Hard resetting via RTS pin...
```

### ESP32 Flash
Download firmware
```
https://micropython.org/download/ESP32_GENERIC/
```
The firmware ESP32_GENERIC-20240105-v1.22.1.bin is used to flash the ESP32.

Open terminal and run
```
python -m esptool --chip esp32 --port COM4 write_flash -z 0x1000 ESP32_GENERIC-20240105-v1.22.1.bin
```

Log Snippet
```
esptool.py v4.7.0
Serial port COM4
Connecting....
Chip is ESP32-D0WD-V3 (revision v3.1)
Features: WiFi, BT, Dual Core, 240MHz, VRef calibration in efuse, Coding Scheme None
Crystal is 40MHz
MAC: e4:65:b8:20:a8:a4
Uploading stub...
Running stub...
Stub running...
Configuring flash size...
Flash will be erased from 0x00001000 to 0x001a9fff...
Compressed 1737664 bytes to 1143562...
Wrote 1737664 bytes (1143562 compressed) at 0x00001000 in 100.4 seconds (effective 138.4 kbit/s)...
Hash of data verified.
Leaving...
Hard resetting via RTS pin...
```

### Start Thonny
Select menu Run > Configure interpreter…
Set MicroPython (ESP32) and auto detect the port. 

Log Snippet after first ESP32CYD Thonny connection
```
ets Jul 29 2019 12:21:46

rst:0x1 (POWERON_RESET),boot:0x13 (SPI_FAST_FLASH_BOOT)
configsip: 0, SPIWP:0xee
clk_drv:0x00,q_drv:0x00,d_drv:0x00,cs0_drv:0x00,hd_drv:0x00,wp_drv:0x00
mode:DIO, clock div:2
load:0x3fff0030,len:4728
load:0x40078000,len:14888
load:0x40080400,len:3368
entry 0x400805cc
MicroPython v1.22.1 on 2024-01-05; Generic ESP32 module with ESP32
Type "help()" for more information.
MicroPython v1.22.1 on 2024-01-05; Generic ESP32 module with ESP32

Type "help()" for more information.

>>>
```

## MicroPython
After successful flashing of the ESP32CYD and Thonny start, the folder structure has been built as outlined below.

### Folder Structure

Notes
On the development device, the default folder "… Source\MicroPython" is set to enable saving the files from the ESP32.
The MicroPython device is the ESP32 with interpreter MicroPython (ESP32) connected to USB Serial COM3.

**ESP32CYD Folders**
* demos - The demo scripts with an example on how to create a widget and the main script which is started at boot (main.py).
* drivers – Display driver (ILI9341) & touch controller (XPT2046) ) plus color settings.
* Folder fonts – Two fonts used ArcadePix9x11, (default), Unispace12x24 (big).
* Folder images – Not used.
* Folder web – Web server Domoticz connection, handle HTTP API GET requests.
* Folder widgets – Screen control elements which can be touchable, like button or device or display only like label, rectlabel, led.
boot.py – Not used.
config.py – Various configuration settings.
cydr.py – Library for display & touch control.
main.py – Auto start demo_domoticz script
secrets.py – network settings SSID, password, IP.

### Configuration
There are two configuration files in the root folder on the ESP32CYD.
The constants are documented, please lookup in the files what can be set.

Start with **secrets.py** for the network settings and the Domoticz system IP.

In **config.py** define the Domoticz room plans with text and IDs.
Recommend to start with 1 or 2 room plans:
menu_items = [
    {'id':-1000, 'text':'Plan A', 'idx':3, 'fgcolor':WHITE, 'bgcolor':RED},
    {'id':-1001, 'text':'Plan B', 'idx':4, 'fgcolor':RED, 'bgcolor':YELLOW}
    # add more
]

If Node-RED pre-parser is not used, set the flag to False:
```
NODERED_PREPARSER = False
```